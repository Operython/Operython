(async () => {
  const ALLOWED_STYLES = new Set([
    "background-color", "border-color", "color", "fill",
    "font-size", "font-weight", "opacity", "text-decoration"
  ]);

  function parseScript(text, assets = {}) {
    let name = "Script";
    const sites = [];
    const actions = [];

    for (const rawLine of text.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) continue;
      if (/^(LOGOTIPE|LOGO)\s*[:|]/i.test(line)) continue;

      const parts = line.split("|").map(p => p.trim());
      const cmd = parts[0].toUpperCase();

      if (cmd === "NOMBRE" && parts[1]) name = parts[1];
      else if (cmd === "SITIO" && parts[1]) sites.push(parts[1].toLowerCase());
      else if ((cmd === "OCULTAR" || cmd === "MOSTRAR") && parts[1]) {
        actions.push({ type: cmd, selector: parts[1] });
      } else if (cmd === "TEXTO" && parts.length === 3) {
        actions.push({ type: cmd, selector: parts[1], value: parts[2] });
      } else if (cmd === "REEMPLAZAR" && parts.length === 4) {
        actions.push({ type: cmd, selector: parts[1], search: parts[2], value: parts[3] });
      } else if (cmd === "TAMANO" && parts.length === 4) {
        actions.push({ type: cmd, selector: parts[1], width: parts[2], height: parts[3] });
      } else if (cmd === "IMAGEN" && (parts.length === 3 || parts.length === 4)) {
        const src = assets[parts[2]];
        if (src) {
          actions.push({
            type: cmd,
            selector: parts[1],
            src,
            alt: parts[3] || parts[2]
          });
        }
      } else if (cmd === "BOTON" && (parts.length === 5 || parts.length === 7)) {
        actions.push({
          type: "BOTON_ALTERNAR",
          selector: parts[1],
          targets: parts[2],
          show_label: parts[3],
          hide_label: parts[4],
          size_selector: parts[5] || null,
          collapsed_max_width: parts[6] || null
        });
      } else if (cmd === "ESTILO" && parts.length === 4) {
        const prop = parts[2].toLowerCase();
        if (ALLOWED_STYLES.has(prop) && !/[;{}]|url\s*\(|expression\s*\(/i.test(parts[3])) {
          actions.push({ type: cmd, selector: parts[1], property: prop, value: parts[3] });
        }
      } else if (cmd === "CLASE" && parts.length === 3) {
        actions.push({ type: cmd, selector: parts[1], value: parts[2] });
      } else if (cmd === "OSCURO" && parts[1]?.toUpperCase() === "UI") {
        actions.push({ type: "OSCURO_UI" });
      } else if (cmd === "BLOQUEAR_EXTERNOS") {
        actions.push({ type: "BLOQUEAR_EXTERNOS" });
      } else if (cmd === "YOUTUBE_SALTAR_ANUNCIOS") {
        actions.push({ type: "YOUTUBE_SALTAR_ANUNCIOS" });
      }
    }
    return { name, sites, actions };
  }

  function matchesHost(sites, hostname) {
    const host = hostname.toLowerCase();
    return sites.some(site =>
      site.startsWith("*.")
        ? host === site.slice(2) || host.endsWith("." + site.slice(2))
        : host === site
    );
  }

  const { scripts = [] } = await chrome.storage.local.get("scripts");
  const accionesActivas = [];

  for (const item of scripts) {
    if (!item.enabled) continue;
    const parsed = parseScript(item.text, item.assets || {});
    if (matchesHost(parsed.sites, location.hostname)) {
      parsed.actions.forEach((act, idx) => {
        if (act.type === "BOTON_ALTERNAR") {
          act.id = `op-chrome-btn-${item.name.replace(/\W+/g, "_")}-${idx}`;
          act.expanded = false;
        }
        accionesActivas.push(act);
      });
    }
  }

  if (!accionesActivas.length) return;

  if (accionesActivas.some(a => a.type === "BLOQUEAR_EXTERNOS")) {
    const bloquear = (e) => {
      let dest = "";
      if (e.type === "submit" && e.target instanceof HTMLFormElement) dest = e.target.action;
      else if (e.target instanceof Element) {
        const link = e.target.closest("a[href], area[href]");
        if (link) dest = link.href;
      }
      if (!dest) return;
      try {
        if (new URL(dest, location.href).origin !== location.origin) {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
      } catch {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    };
    document.addEventListener("click", bloquear, true);
    document.addEventListener("auxclick", bloquear, true);
    document.addEventListener("submit", bloquear, true);
  }

  if (accionesActivas.some(a => a.type === "YOUTUBE_SALTAR_ANUNCIOS")) {
    setInterval(() => {
      const player = document.querySelector("#movie_player");
      if (!player) return;
      const ad = player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting");
      const video = player.querySelector("video");
      if (ad) {
        if (video) video.muted = true;
        const skip = player.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button");
        if (skip && !skip.disabled) skip.click();
        else if (video && Number.isFinite(video.duration)) {
          try { video.currentTime = video.duration; } catch {}
        }
      }
    }, 300);
  }

  function aplicarOscuroUI() {
    const excluded = "canvas, svg, img, video, iframe, picture, .blocklyBlock, [class*='stage_stage'], [class*='stage-wrapper']";
    for (const root of [document.documentElement, document.body]) {
      if (!root) continue;
      root.style.setProperty("background-image", "none", "important");
      root.style.setProperty("background-color", "#17191f", "important");
    }
    const elements = document.body ? document.body.querySelectorAll("*") : [];
    for (let i = 0; i < Math.min(elements.length, 6000); i++) {
      const el = elements[i];
      if (!el || el.matches(excluded) || el.closest(excluded)) continue;
      if (el.matches("button, input, select, textarea, [role='button']")) {
        el.style.setProperty("background-image", "none", "important");
        el.style.setProperty("background-color", "#30343f", "important");
        el.style.setProperty("color", "#f1f3f8", "important");
        continue;
      }
      const bg = getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
      if (!bg || bg.length < 3) continue;
      const [r, g, b] = bg.map(Number);
      const light = Math.min(r, g, b) > 185;
      const scratchPurple = r >= 90 && b >= 150 && b - r > 40 && b - g > 55;
      if (light || scratchPurple) {
        el.style.setProperty("background-image", "none", "important");
        el.style.setProperty("background-color", "#20232b", "important");
        el.style.setProperty("color", "#f1f3f8", "important");
      }
    }
  }

  function aplicarAcciones() {
    for (const act of accionesActivas) {
      if (act.type === "OSCURO_UI") {
        aplicarOscuroUI();
        continue;
      }
      if (["BLOQUEAR_EXTERNOS", "YOUTUBE_SALTAR_ANUNCIOS"].includes(act.type)) continue;

      let els = [];
      try { els = document.querySelectorAll(act.selector); } catch { continue; }

      if (act.type === "BOTON_ALTERNAR") {
        const anchor = els[0];
        if (anchor && anchor.parentNode) {
          let btn = document.getElementById(act.id);
          if (!btn) {
            btn = document.createElement("button");
            btn.id = act.id;
            btn.type = "button";
            btn.style.cssText = "display:inline-flex;align-items:center;margin:6px;padding:6px 12px;border:0;border-radius:14px;background:#272727;color:#f1f1f1;font:500 12px Arial,sans-serif;cursor:pointer;z-index:9999;";
            btn.onclick = () => {
              act.expanded = !act.expanded;
              aplicarAcciones();
            };
            anchor.parentNode.insertBefore(btn, anchor);
          }
          btn.textContent = act.expanded ? act.hide_label : act.show_label;
          try {
            document.querySelectorAll(act.targets).forEach(t => { t.hidden = !act.expanded; });
            if (act.size_selector && act.collapsed_max_width) {
              document.querySelectorAll(act.size_selector).forEach(t => {
                t.style.maxWidth = act.expanded ? "" : act.collapsed_max_width;
              });
            }
          } catch {}
        }
        continue;
      }

      els.forEach(el => {
        if (act.type === "OCULTAR") el.hidden = true;
        else if (act.type === "MOSTRAR") el.hidden = false;
        else if (act.type === "TEXTO" && el.textContent !== act.value) el.textContent = act.value;
        else if (act.type === "REEMPLAZAR" && el.textContent.includes(act.search)) {
          el.textContent = el.textContent.split(act.search).join(act.value);
        } else if (act.type === "TAMANO") {
          el.style.width = act.width;
          el.style.height = act.height;
        } else if (act.type === "IMAGEN") {
          if (el.tagName === "IMG") {
            if (el.src !== act.src) {
              el.src = act.src;
              el.alt = act.alt;
              el.style.maxWidth = "100%";
              el.style.maxHeight = "100%";
              el.style.objectFit = "contain";
            }
          } else if (!el.firstElementChild || el.firstElementChild.tagName !== "IMG" || el.firstElementChild.src !== act.src) {
            const img = document.createElement("img");
            img.src = act.src;
            img.alt = act.alt;
            img.style.maxWidth = "100%";
            img.style.maxHeight = "100%";
            img.style.objectFit = "contain";
            el.replaceChildren(img);
          }
        } else if (act.type === "ESTILO") {
          el.style.setProperty(act.property, act.value, "important");
        } else if (act.type === "CLASE") {
          el.classList.add(act.value);
        }
      });
    }
  }

  aplicarAcciones();
  const observer = new MutationObserver(aplicarAcciones);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
