const btnImportar = document.getElementById("btnImportar");
const listaEl = document.getElementById("lista");
const estadoEl = document.getElementById("estado");

btnImportar.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("importar.html") });
  window.close();
});

function coincideSitio(sites, urlStr) {
  try {
    const url = new URL(urlStr);
    if (url.protocol !== "http:" && url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase();
    return sites.some(site =>
      site.startsWith("*.")
        ? host === site.slice(2) || host.endsWith("." + site.slice(2))
        : host === site
    );
  } catch {
    return false;
  }
}

async function recargarPestanasAfectadas(sites) {
  const tabs = await chrome.tabs.query({});
  let recargadas = 0;
  for (const tab of tabs) {
    if (tab.id && tab.url && coincideSitio(sites, tab.url)) {
      await chrome.tabs.reload(tab.id);
      recargadas++;
    }
  }
  return recargadas;
}

async function cargarLista() {
  const { scripts = [] } = await chrome.storage.local.get("scripts");
  listaEl.innerHTML = "";
  if (!scripts.length) {
    listaEl.innerHTML = '<div style="font-size:12px;color:#646b8c;text-align:center;padding:12px;">No hay scripts guardados.</div>';
    return;
  }

  scripts.forEach((script, index) => {
    const item = document.createElement("div");
    item.className = "item";

    if (script.logoDataUrl) {
      const imgLogo = document.createElement("img");
      imgLogo.className = "logo-script";
      imgLogo.src = script.logoDataUrl;
      item.appendChild(imgLogo);
    }

    const info = document.createElement("div");
    info.className = "info";
    info.innerHTML = `
      <div class="nombre">${script.enabled ? "✅" : "⏸️"} ${script.name}</div>
      <div class="sitios">${script.sites.join(", ")}</div>
    `;

    const acciones = document.createElement("div");
    acciones.className = "acciones";

    const btnToggle = document.createElement("button");
    btnToggle.className = "btn-mini";
    btnToggle.textContent = script.enabled ? "Pausar" : "Activar";
    btnToggle.onclick = async () => {
      scripts[index].enabled = !scripts[index].enabled;
      await chrome.storage.local.set({ scripts });
      const n = await recargarPestanasAfectadas(script.sites);
      estadoEl.textContent = `«${script.name}» ${scripts[index].enabled ? "activado" : "pausado"} (${n} pestaña(s) recargada(s)).`;
      cargarLista();
    };

    const btnDel = document.createElement("button");
    btnDel.className = "btn-mini btn-del";
    btnDel.textContent = "🗑️";
    btnDel.onclick = async () => {
      const sitiosAfectados = script.sites;
      const nombreEliminado = script.name;
      scripts.splice(index, 1);
      await chrome.storage.local.set({ scripts });
      const n = await recargarPestanasAfectadas(sitiosAfectados);
      estadoEl.textContent = `«${nombreEliminado}» eliminado (${n} pestaña(s) recargada(s)).`;
      cargarLista();
    };

    acciones.append(btnToggle, btnDel);
    item.append(info, acciones);
    listaEl.appendChild(item);
  });
}

cargarLista();
