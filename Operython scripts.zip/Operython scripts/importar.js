const msgEl = document.getElementById("msg");
const btnReintentar = document.getElementById("btnReintentar");

function parsearScriptInfo(texto) {
  let nombre = "";
  const sitios = [];
  let acciones = 0;
  let logoEnabled = false;
  let logoFile = null;
  const imagenesNecesarias = new Set();

  for (const raw of texto.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;

    const logoToggle = line.match(/^LOGOTIPE\s*(?::|\|)\s*(enabled|disabled)$/i);
    if (logoToggle) {
      logoEnabled = logoToggle[1].toLowerCase() === "enabled";
      continue;
    }
    const logoDecl = line.match(/^LOGO\s*(?::|\|)\s*(.+)$/i);
    if (logoDecl) {
      logoFile = logoDecl[1].trim();
      continue;
    }

    const parts = line.split("|").map(p => p.trim());
    const cmd = parts[0].toUpperCase();
    if (cmd === "NOMBRE" && parts[1]) {
      nombre = parts[1].slice(0, 80);
    } else if (cmd === "SITIO" && parts[1]) {
      sitios.push(parts[1].toLowerCase());
    } else if (cmd === "IMAGEN" && (parts.length === 3 || parts.length === 4) && parts[2]) {
      imagenesNecesarias.add(parts[2]);
      acciones++;
    } else if (cmd !== "DESCRIPCION") {
      acciones++;
    }
  }

  if (!nombre || !sitios.length || !acciones) return null;
  return { nombre, sitios, logoEnabled, logoFile, imagenesNecesarias: [...imagenesNecesarias] };
}

function archivoADataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error(`No se pudo leer ${file.name}`));
    reader.readAsDataURL(file);
  });
}

async function recolectarArchivos(dirHandle, prefijo = "") {
  const lista = [];
  for await (const [nombre, handle] of dirHandle.entries()) {
    const rutaRelativa = prefijo ? `${prefijo}/${nombre}` : nombre;
    if (handle.kind === "file") {
      const file = await handle.getFile();
      Object.defineProperty(file, "_relPath", { value: rutaRelativa });
      lista.push(file);
    } else if (handle.kind === "directory") {
      lista.push(...await recolectarArchivos(handle, rutaRelativa));
    }
  }
  return lista;
}

function buscarArchivoRelativo(archivos, carpetaBase, referencia) {
  const refNorm = referencia.replace(/\\/g, "/").toLowerCase();
  const baseName = refNorm.split("/").pop();
  const mismaCarpeta = archivos.filter(f => f._relPath.toLowerCase().startsWith(carpetaBase));
  return (
    mismaCarpeta.find(f => f._relPath.toLowerCase().endsWith(refNorm)) ||
    mismaCarpeta.find(f => f.name.toLowerCase() === baseName) ||
    archivos.find(f => f.name.toLowerCase() === baseName) ||
    null
  );
}

function coincideSitio(sites, urlStr) {
  try {
    const url = new URL(urlStr);
    if (url.protocol !== "http:" && url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase();
    return sites.some(site =>
      site.startsWith("*.")
        ? host === site.slice(2) || host.endsWith("." + site.slice(2))
        : host === site
    );
  } catch {
    return false;
  }
}

async function recargarPestanasAfectadas(sites) {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id && tab.url && coincideSitio(sites, tab.url)) {
      await chrome.tabs.reload(tab.id);
    }
  }
}

async function iniciarImportacion() {
  btnReintentar.style.display = "none";
  msgEl.textContent = "Selecciona la carpeta del script (o la carpeta scripts_web completa)...";
  try {
    const dirHandle = await window.showDirectoryPicker();
    const archivos = await recolectarArchivos(dirHandle);
    const txtFiles = archivos.filter(f => f.name.toLowerCase().endsWith(".txt"));

    if (!txtFiles.length) {
      throw new Error("No se encontró ningún archivo .txt dentro de esa carpeta.");
    }

    const { scripts = [] } = await chrome.storage.local.get("scripts");
    const sitiosParaRecargar = new Set();
    let importados = 0;

    for (const txtFile of txtFiles) {
      const text = await txtFile.text();
      const info = parsearScriptInfo(text);
      if (!info) continue;

      const idxBarra = txtFile._relPath.lastIndexOf("/");
      const carpetaBase = idxBarra >= 0 ? txtFile._relPath.slice(0, idxBarra + 1).toLowerCase() : "";

      let logoDataUrl = null;
      if (info.logoEnabled) {
        const candidatosLogo = info.logoFile
          ? [info.logoFile]
          : ["logo.png", "logo.jpg", "logo.jpeg", "logo.svg"];
        for (const cand of candidatosLogo) {
          const encontrado = buscarArchivoRelativo(archivos, carpetaBase, cand);
          if (encontrado) {
            logoDataUrl = await archivoADataURL(encontrado);
            break;
          }
        }
      }

      const assets = {};
      for (const ref of info.imagenesNecesarias) {
        const encontrado = buscarArchivoRelativo(archivos, carpetaBase, ref);
        if (encontrado) {
          assets[ref] = await archivoADataURL(encontrado);
        }
      }

      const existente = scripts.findIndex(s => s.name.toLowerCase() === info.nombre.toLowerCase());
      const nuevo = {
        name: info.nombre,
        sites: info.sitios,
        text,
        enabled: existente >= 0 ? scripts[existente].enabled : true,
        logoDataUrl,
        assets
      };

      if (existente >= 0) scripts[existente] = nuevo;
      else scripts.push(nuevo);

      info.sitios.forEach(s => sitiosParaRecargar.add(s));
      importados++;
    }

    if (!importados) {
      throw new Error("Ningún .txt tenía formato válido de script de Operython.");
    }

    await chrome.storage.local.set({ scripts });
    await recargarPestanasAfectadas([...sitiosParaRecargar]);

    msgEl.textContent = `✅ ${importados} script(s) importado(s). Cerrando...`;
    setTimeout(() => window.close(), 300);
  } catch (err) {
    if (err.name === "AbortError") {
      window.close();
      return;
    }
    msgEl.textContent = `Error: ${err.message}`;
    btnReintentar.textContent = "Elegir carpeta";
    btnReintentar.style.display = "inline-block";
  }
}

btnReintentar.addEventListener("click", iniciarImportacion);
window.addEventListener("DOMContentLoaded", iniciarImportacion);
