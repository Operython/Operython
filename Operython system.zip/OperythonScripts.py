import base64
import hashlib
import json
import os
import re
import shutil
from pathlib import Path
from xml.etree import ElementTree
from urllib.parse import urlsplit


ROOT = Path(__file__).resolve().parent
SCRIPTS_DIR = ROOT / "scripts_web"
ASSETS_DIR = SCRIPTS_DIR / "assets"
CONFIG_FILE = ROOT / "config_maestra_operython.json"
LEGACY_STATE_FILE = ROOT / "scripts_web_estado.json"
STATE_CONFIG_KEY = "scripts_web_estado"
FEATURE_STATE_CONFIG_KEY = "scripts_web_funciones"
MAX_SCRIPT_SIZE = 64_000
MAX_ACTIONS = 40
MAX_ASSET_SIZE = 4 * 1024 * 1024
MAX_TOTAL_ASSETS_SIZE = 12 * 1024 * 1024
IMAGE_MIME_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".svg": "image/svg+xml",
}
ALLOWED_STYLES = {
    "background-color",
    "border-color",
    "color",
    "fill",
    "font-size",
    "font-weight",
    "opacity",
    "text-decoration",
}


class ScriptError(ValueError):
    pass


def parse_script(text):
    if len(text.encode("utf-8")) > MAX_SCRIPT_SIZE:
        raise ScriptError("El script supera el límite de 64 KB.")

    name = None
    description = None
    description_declared = False
    sites = []
    actions = []
    logo_enabled = False
    logo_declared = False
    logo_file = None
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        logo_match = re.fullmatch(r"LOGOTIPE\s*(?::|\|)\s*(enabled|disabled)", line, re.I)
        if logo_match:
            if logo_declared:
                raise ScriptError(f"Línea {line_number}: Logotipe solo puede aparecer una vez.")
            logo_enabled = logo_match.group(1).lower() == "enabled"
            logo_declared = True
            continue
        logo_file_match = re.fullmatch(r"LOGO\s*(?::|\|)\s*(.+)", line, re.I)
        if logo_file_match:
            if logo_file is not None:
                raise ScriptError(f"Línea {line_number}: Logo solo puede aparecer una vez.")
            try:
                logo_file = _validate_asset_reference(logo_file_match.group(1).strip())
            except ScriptError as error:
                raise ScriptError(f"Línea {line_number}: {error}.") from error
            continue
        parts = [part.strip() for part in line.split("|")]
        command = parts[0].upper()
        try:
            if command == "NOMBRE" and len(parts) == 2 and parts[1]:
                name = parts[1][:80]
            elif command == "DESCRIPCION" and len(parts) == 2 and parts[1]:
                if description_declared:
                    raise ScriptError("DESCRIPCION solo puede aparecer una vez")
                if len(parts[1]) > 500:
                    raise ScriptError("la descripción no puede superar 500 caracteres")
                description = parts[1]
                description_declared = True
            elif command == "SITIO" and len(parts) == 2:
                site = parts[1].lower()
                domain = site[2:] if site.startswith("*.") else site
                labels = domain.split(".")
                if (
                    not domain
                    or any(
                        not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
                        for label in labels
                    )
                ):
                    raise ScriptError("dominio no válido")
                sites.append(site)
            elif command in {"OCULTAR", "MOSTRAR"} and len(parts) == 2:
                selector = _required(parts[1], "selector")
                actions.append({"type": command, "selector": selector})
            elif command == "TEXTO" and len(parts) == 3:
                selector = _required(parts[1], "selector")
                actions.append(
                    {"type": command, "selector": selector, "value": parts[2]}
                )
            elif command == "REEMPLAZAR" and len(parts) == 4:
                selector = _required(parts[1], "selector")
                original = _required(parts[2], "texto que se busca")
                if len(original) > 500 or len(parts[3]) > 500:
                    raise ScriptError("el texto no puede superar 500 caracteres")
                actions.append(
                    {
                        "type": command,
                        "selector": selector,
                        "search": original,
                        "value": parts[3],
                    }
                )
            elif command == "TAMANO" and len(parts) == 4:
                selector = _required(parts[1], "selector")
                width = _validate_dimension(parts[2], "ancho")
                height = _validate_dimension(parts[3], "alto")
                actions.append(
                    {
                        "type": command,
                        "selector": selector,
                        "width": width,
                        "height": height,
                    }
                )
            elif command == "IMAGEN" and len(parts) in {3, 4}:
                selector = _required(parts[1], "selector")
                asset = _validate_asset_reference(parts[2])
                alt = parts[3] if len(parts) == 4 else Path(asset).name
                if len(alt) > 300:
                    raise ScriptError("el texto alternativo es demasiado largo")
                actions.append(
                    {
                        "type": command,
                        "selector": selector,
                        "asset": asset,
                        "alt": alt,
                    }
                )
            elif command == "BOTON" and len(parts) in {5, 7}:
                selector = _required(parts[1], "selector del lugar del botón")
                targets = _required(parts[2], "selectores que se alternan")
                show_label = _required(parts[3], "texto para mostrar")
                hide_label = _required(parts[4], "texto para ocultar")
                if len(targets) > 500:
                    raise ScriptError("los selectores que se alternan son demasiado largos")
                if len(show_label) > 40 or len(hide_label) > 40:
                    raise ScriptError("el texto del botón no puede superar 40 caracteres")
                action = {
                    "type": "BOTON_ALTERNAR",
                    "selector": selector,
                    "targets": targets,
                    "show_label": show_label,
                    "hide_label": hide_label,
                }
                if len(parts) == 7:
                    action["size_selector"] = _required(
                        parts[5], "selector de tamaño"
                    )
                    action["collapsed_max_width"] = _validate_dimension(
                        parts[6], "ancho máximo al ocultar"
                    )
                    if action["collapsed_max_width"] == "auto":
                        raise ScriptError("el ancho máximo debe ser una medida fija")
                actions.append(action)
            elif command == "ESTILO" and len(parts) == 4:
                selector = _required(parts[1], "selector")
                prop = parts[2].lower()
                value = _required(parts[3], "valor")
                if prop not in ALLOWED_STYLES:
                    raise ScriptError(
                        "propiedad no permitida; consulta la lista del editor"
                    )
                if len(value) > 200 or re.search(r"[;{}]|url\s*\(|expression\s*\(", value, re.I):
                    raise ScriptError("valor de estilo no permitido")
                actions.append(
                    {
                        "type": command,
                        "selector": selector,
                        "property": prop,
                        "value": value,
                    }
                )
            elif command == "CLASE" and len(parts) == 3:
                selector = _required(parts[1], "selector")
                class_name = _required(parts[2], "clase")
                if not re.fullmatch(r"[-_a-zA-Z0-9]{1,64}", class_name):
                    raise ScriptError("nombre de clase no válido")
                actions.append(
                    {"type": command, "selector": selector, "value": class_name}
                )
            elif command == "OSCURO" and len(parts) == 2 and parts[1].upper() == "UI":
                actions.append({"type": "OSCURO_UI"})
            elif command == "BLOQUEAR_EXTERNOS" and len(parts) == 1:
                actions.append({"type": "BLOQUEAR_EXTERNOS"})
            elif command == "YOUTUBE_SALTAR_ANUNCIOS" and len(parts) == 1:
                actions.append({"type": "YOUTUBE_SALTAR_ANUNCIOS"})
            else:
                raise ScriptError("instrucción o cantidad de valores desconocida")
        except ScriptError as error:
            raise ScriptError(f"Línea {line_number}: {error}.") from error

        if len(actions) > MAX_ACTIONS:
            raise ScriptError(f"El script supera el límite de {MAX_ACTIONS} acciones.")

    if not name:
        raise ScriptError("Agrega un nombre con: NOMBRE | Mi script")
    if not sites:
        raise ScriptError("Agrega al menos un dominio con: SITIO | ejemplo.com")
    if not actions:
        raise ScriptError("Agrega al menos una instrucción.")
    return {
        "name": name,
        "description": description,
        "sites": list(dict.fromkeys(sites)),
        "actions": actions,
        "logo_enabled": logo_enabled,
        "logo_file": logo_file,
    }


def _validate_dimension(value, label):
    value = _required(value, label).lower()
    if not re.fullmatch(
        r"(?:auto|0|[1-9]\d{0,4}(?:\.\d{1,2})?(?:px|%|rem|em|vw|vh))",
        value,
    ):
        raise ScriptError(f"{label} no válido; usa px, %, rem, em, vw, vh o auto")
    return value


def _validate_asset_reference(reference):
    reference = _required(reference, "archivo de imagen")
    if (
        "\\" in reference
        or ":" in reference
        or reference.startswith("/")
        or re.search(r"[\x00-\x1f]", reference)
    ):
        raise ScriptError("la ruta de la imagen debe ser relativa a assets")
    parts = reference.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ScriptError("la ruta de la imagen no puede salir de assets")
    if Path(reference).suffix.lower() not in IMAGE_MIME_TYPES:
        raise ScriptError("la imagen debe ser PNG, JPG, JPEG o SVG")
    return reference


def _required(value, label):
    if not value:
        raise ScriptError(f"falta {label}")
    if len(value) > 300:
        raise ScriptError(f"{label} demasiado largo")
    return value


def script_matches_url(script, url):
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    for site in script["sites"]:
        if site.startswith("*."):
            if host == site[2:] or host.endswith("." + site[2:]):
                return True
        elif host == site:
            return True
    return False


def adblock_page_key(url):
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return ""
    scheme = parsed.scheme.lower()
    hostname = parsed.hostname.lower()
    if ":" in hostname and not hostname.startswith("["):
        hostname = f"[{hostname}]"
    try:
        port = parsed.port
    except ValueError:
        return ""
    if port and port != (443 if scheme == "https" else 80):
        hostname = f"{hostname}:{port}"
    return f"{scheme}://{hostname}"


def should_block_external_navigation(source_url, destination_url):
    source = urlsplit(source_url)
    destination = urlsplit(destination_url)
    if source.scheme not in {"http", "https"} or not source.hostname:
        return False
    if destination.scheme in {"http", "https"} and destination.hostname:
        source_port = source.port or (443 if source.scheme.lower() == "https" else 80)
        destination_port = destination.port or (
            443 if destination.scheme.lower() == "https" else 80
        )
    else:
        source_port = destination_port = None
    if (
        source.scheme.lower(),
        source.hostname.lower(),
        source_port,
    ) == (
        destination.scheme.lower(),
        (destination.hostname or "").lower(),
        destination_port,
    ):
        return False

    state = read_script_state()
    for path in list_scripts():
        if not state.get(script_state_key(path), True):
            continue
        try:
            script = parse_script(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError) as error:
            raise ScriptError(
                f"No se pudo comprobar el bloqueo de navegación en «{path.name}»: {error}"
            ) from error
        if not script_matches_url(script, source_url):
            continue
        if any(action["type"] == "BLOQUEAR_EXTERNOS" for action in script["actions"]):
            return True
    return False


def script_package_name(name):
    package_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    if not package_name:
        raise ScriptError("El nombre del script no sirve para crear una carpeta.")
    if package_name.split(".", 1)[0].upper() in {
        "CON", "PRN", "AUX", "NUL",
        *(f"COM{index}" for index in range(1, 10)),
        *(f"LPT{index}" for index in range(1, 10)),
    }:
        package_name = f"_{package_name}"
    return package_name[:80].rstrip(" .")


def create_script_package_path(script):
    package_name = script_package_name(script["name"])
    package_dir = SCRIPTS_DIR / package_name
    if package_dir.is_dir() and not any(package_dir.glob("*.txt")):
        return package_dir / "script.txt"
    suffix = 2
    while package_dir.exists():
        package_dir = SCRIPTS_DIR / f"{package_name} ({suffix})"
        suffix += 1
    return package_dir / "script.txt"


def script_state_key(script_path):
    path = Path(script_path)
    try:
        relative = path.resolve().relative_to(SCRIPTS_DIR.resolve())
    except ValueError:
        return path.name
    if relative.parent == Path("."):
        return path.name
    return relative.as_posix()


def describe_script_action(action):
    action_type = action["type"]
    if action_type == "BOTON_ALTERNAR":
        return (
            f"Agrega un botón «{action['show_label']} / "
            f"{action['hide_label']}» para mostrar u ocultar contenido."
        )
    descriptions = {
        "OCULTAR": "Oculta elementos de la página.",
        "MOSTRAR": "Muestra elementos de la página.",
        "TEXTO": "Cambia el texto de elementos de la página.",
        "REEMPLAZAR": "Reemplaza texto en la página.",
        "TAMANO": "Ajusta el tamaño de elementos de la página.",
        "IMAGEN": "Reemplaza elementos por una imagen.",
        "ESTILO": "Modifica la apariencia de elementos de la página.",
        "CLASE": "Aplica una clase visual a elementos de la página.",
        "OSCURO_UI": "Oscurece los fondos claros de la página.",
        "BLOQUEAR_EXTERNOS": (
            "Bloquea enlaces y formularios que salen del sitio actual."
        ),
        "YOUTUBE_SALTAR_ANUNCIOS": (
            "Oculta y silencia anuncios de YouTube e intenta saltarlos."
        ),
    }
    return descriptions.get(action_type, "Aplica un ajuste a la página.")


def script_function_key(action, occurrence=0):
    serialized = json.dumps(
        action, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()[:20]
    return f"{digest}:{occurrence}"


def script_functions(script):
    occurrences = {}
    functions = []
    for action in script["actions"]:
        serialized = json.dumps(
            action, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
        digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()[:20]
        occurrence = occurrences.get(digest, 0)
        occurrences[digest] = occurrence + 1
        functions.append(
            (script_function_key(action, occurrence), describe_script_action(action))
        )
    return functions


def is_script_enabled(state, script_path):
    return bool(state.get(script_state_key(script_path), True))


def _script_paths():
    SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
    paths = list(SCRIPTS_DIR.glob("*.txt"))
    for package_dir in SCRIPTS_DIR.iterdir():
        if (
            not package_dir.is_dir()
            or package_dir.is_symlink()
            or package_dir.resolve() == ASSETS_DIR.resolve()
        ):
            continue
        package_files = sorted(
            (
                path for path in package_dir.glob("*.txt")
                if path.is_file() and not path.is_symlink()
            ),
            key=lambda path: path.name.lower(),
        )
        if package_files:
            paths.extend(package_files)
            (package_dir / "assets").mkdir(parents=True, exist_ok=True)
    return sorted(paths, key=lambda path: script_state_key(path).lower())


def _resolved_asset_path(script_path, reference):
    reference = _validate_asset_reference(reference)
    if script_path is None:
        raise ScriptError("guarda el script para resolver sus imágenes en assets")
    script_path = Path(script_path)
    package_assets = script_path.parent / "assets"
    asset_root = SCRIPTS_DIR.resolve()
    candidates = [
        package_assets / Path(reference),
        ASSETS_DIR / script_path.stem / Path(reference),
        asset_root / Path(reference),
    ]
    for candidate in candidates:
        resolved = candidate.resolve()
        try:
            resolved.relative_to(asset_root)
        except ValueError:
            continue
        if resolved.is_file():
            return resolved
    raise ScriptError(f"No se encontró «{reference}» en la carpeta assets del script.")


def resolve_logo_asset(script_path, logo_file=None):
    if script_path is None:
        return None
    if logo_file:
        try:
            return _resolved_asset_path(script_path, logo_file)
        except ScriptError:
            return None
    for extension in IMAGE_MIME_TYPES:
        reference = f"logo{extension}"
        try:
            return _resolved_asset_path(script_path, reference)
        except ScriptError:
            continue
    return None


def validate_script_assets(script, script_path):
    total_size = 0
    paths = []
    for action in script["actions"]:
        if action["type"] == "IMAGEN":
            paths.append(_resolved_asset_path(script_path, action["asset"]))
    if script.get("logo_enabled"):
        logo = resolve_logo_asset(script_path, script.get("logo_file"))
        if logo is None:
            filename = script.get("logo_file") or (
                "logo.png, logo.jpg, logo.jpeg o logo.svg"
            )
            raise ScriptError(f"Logotipe está enabled, pero falta {filename} en assets.")
        paths.append(logo)
    for path in set(paths):
        try:
            size = path.stat().st_size
        except OSError as error:
            raise ScriptError(f"No se pudo leer el recurso «{path.name}»: {error}") from error
        if size > MAX_ASSET_SIZE:
            raise ScriptError(f"El recurso «{path.name}» supera el límite de 4 MB.")
        total_size += size
        if path.suffix.lower() == ".svg":
            _image_data_uri(path)
    if total_size > MAX_TOTAL_ASSETS_SIZE:
        raise ScriptError("Los recursos del script superan el límite total de 12 MB.")


def _find_source_asset(script_path, reference):
    reference = _validate_asset_reference(reference)
    source_path = Path(script_path)
    source_assets = source_path.parent / "assets"
    reference_path = Path(reference)
    candidates = [
        (source_assets / reference_path, source_assets),
        (source_path.parent / reference_path, source_path.parent),
        (ROOT / reference_path, ROOT),
    ]
    for candidate, allowed_root in candidates:
        if candidate.is_symlink():
            continue
        resolved = candidate.resolve()
        try:
            resolved.relative_to(allowed_root.resolve())
        except ValueError:
            continue
        if resolved.is_file():
            return resolved

    reference_parts = tuple(part.casefold() for part in reference_path.parts)
    matches = []
    excluded_dirs = {"__pycache__", "op_env", ".git"}
    for current_root, directories, filenames in os.walk(ROOT, followlinks=False):
        current_path = Path(current_root)
        directories[:] = [
            name for name in directories
            if name.casefold() not in excluded_dirs
            and not (current_path / name).is_symlink()
        ]
        for filename in filenames:
            candidate = current_path / filename
            if filename.casefold() != reference_parts[-1]:
                continue
            relative_parts = tuple(
                part.casefold() for part in candidate.relative_to(ROOT).parts
            )
            if relative_parts[-len(reference_parts):] == reference_parts:
                matches.append(candidate)

    if matches:
        matches.sort(
            key=lambda path: (
                0 if "assets" in {part.casefold() for part in path.parts} else 1,
                len(path.relative_to(ROOT).parts),
                str(path).casefold(),
            )
        )
        return matches[0].resolve()
    raise ScriptError(
        f"No se encontró «{reference}» junto al script ni dentro de {ROOT.name}."
    )


def import_script_assets(
    source_path, destination_path, script, replace_existing=False
):
    source_path = Path(source_path)
    destination_path = Path(destination_path)
    destination_package = destination_path.parent.resolve()
    try:
        destination_package.relative_to(SCRIPTS_DIR.resolve())
    except ValueError as error:
        raise ScriptError("La carpeta del paquete debe estar dentro de scripts_web.") from error
    (destination_package / "assets").mkdir(parents=True, exist_ok=True)
    try:
        source_path.resolve().relative_to(SCRIPTS_DIR.resolve())
        source_is_managed = True
    except ValueError:
        source_is_managed = False

    references = {
        action["asset"]
        for action in script["actions"]
        if action["type"] == "IMAGEN"
    }
    if script.get("logo_enabled"):
        if source_is_managed:
            logo = resolve_logo_asset(source_path, script.get("logo_file"))
            if logo is not None:
                references.add(script.get("logo_file") or logo.name)
            else:
                filename = script.get("logo_file") or (
                    "logo.png, logo.jpg, logo.jpeg o logo.svg"
                )
                raise ScriptError(f"Logotipe está enabled, pero falta {filename} en assets.")
        else:
            logo_references = (
                [script["logo_file"]]
                if script.get("logo_file")
                else [f"logo{extension}" for extension in IMAGE_MIME_TYPES]
            )
            for logo_reference in logo_references:
                try:
                    _find_source_asset(source_path, logo_reference)
                except ScriptError:
                    continue
                references.add(logo_reference)
                break
            else:
                filename = script.get("logo_file") or (
                    "logo.png, logo.jpg, logo.jpeg o logo.svg"
                )
                raise ScriptError(
                    f"Logotipe está enabled, pero falta {filename} en la carpeta assets."
                )

    files_to_copy = {}
    for reference in references:
        if source_is_managed:
            source_file = _resolved_asset_path(source_path, reference)
        else:
            source_file = _find_source_asset(source_path, reference)
        files_to_copy[Path(reference)] = source_file

    total_size = 0
    for source_file in set(files_to_copy.values()):
        size = source_file.stat().st_size
        if size > MAX_ASSET_SIZE:
            raise ScriptError(f"El recurso «{source_file.name}» supera el límite de 4 MB.")
        total_size += size
        if total_size > MAX_TOTAL_ASSETS_SIZE:
            raise ScriptError("Los recursos del script superan el límite total de 12 MB.")
        if source_file.suffix.lower() == ".svg":
            _image_data_uri(source_file)

    destination_root = (destination_path.parent / "assets").resolve()
    asset_root = SCRIPTS_DIR.resolve()
    try:
        destination_root.relative_to(asset_root)
    except ValueError as error:
        raise ScriptError("La carpeta de destino de recursos no es válida.") from error
    destinations = {}
    for relative_path, source_file in files_to_copy.items():
        destination_file = (destination_root / relative_path).resolve()
        try:
            destination_file.relative_to(destination_root)
        except ValueError as error:
            raise ScriptError("La ruta de un recurso no es válida.") from error
        if (
            destination_file.exists()
            and not replace_existing
            and destination_file.read_bytes() != source_file.read_bytes()
        ):
            raise ScriptError(
                f"Ya existe un recurso diferente con el nombre «{relative_path}» "
                "para este script."
            )
        destinations[relative_path] = (destination_file, source_file)

    try:
        for destination_file, source_file in destinations.values():
            destination_file.parent.mkdir(parents=True, exist_ok=True)
            if replace_existing or not destination_file.exists():
                destination_file.write_bytes(source_file.read_bytes())
    except OSError as error:
        raise ScriptError(f"No se pudieron copiar los recursos del script: {error}") from error


def remove_script_package(script_path):
    path = Path(script_path).resolve()
    root = SCRIPTS_DIR.resolve()
    try:
        relative = path.relative_to(root)
    except ValueError as error:
        raise ScriptError("El script seleccionado no está dentro de scripts_web.") from error
    if len(relative.parts) > 1:
        package_dir = root / relative.parts[0]
        if package_dir.is_symlink() or package_dir.parent != root:
            raise ScriptError("La carpeta del paquete seleccionado no es válida.")
        other_scripts = [
            item for item in package_dir.glob("*.txt")
            if item.resolve() != path and item.is_file()
        ]
        if other_scripts:
            path.unlink()
        else:
            shutil.rmtree(package_dir)
    else:
        path.unlink()


def sanitize_svg(content, filename="SVG"):
    if len(content) > MAX_ASSET_SIZE:
        raise ScriptError(f"El SVG «{filename}» supera el límite de 4 MB.")
    try:
        root = ElementTree.fromstring(content)
    except ElementTree.ParseError as error:
        raise ScriptError(f"El SVG «{filename}» no es válido.") from error
    if root.tag.rsplit("}", 1)[-1].lower() != "svg":
        raise ScriptError(f"El archivo «{filename}» no contiene un SVG.")
    for parent in root.iter():
        for child in list(parent):
            if child.tag.rsplit("}", 1)[-1].lower() in {"script", "foreignobject"}:
                parent.remove(child)
        for attribute in list(parent.attrib):
            name = attribute.rsplit("}", 1)[-1].lower()
            value = parent.attrib[attribute]
            if (
                name.startswith("on")
                or name in {"href", "src"} and not value.startswith("#")
                or re.search(r"url\s*\(|@import", value, re.I)
            ):
                del parent.attrib[attribute]
        if parent.tag.rsplit("}", 1)[-1].lower() == "style" and re.search(
            r"url\s*\(|@import", parent.text or "", re.I
        ):
            parent.text = ""
    return ElementTree.tostring(root, encoding="utf-8")


def read_sanitized_svg(path):
    try:
        content = Path(path).read_bytes()
    except OSError as error:
        raise ScriptError(f"No se pudo leer el SVG «{Path(path).name}»: {error}") from error
    if Path(path).suffix.lower() != ".svg":
        raise ScriptError("El logo no es un archivo SVG.")
    return sanitize_svg(content, Path(path).name)


def _image_data_uri(path):
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ScriptError(f"No se pudo leer la imagen «{path.name}»: {error}") from error
    if len(content) > MAX_ASSET_SIZE:
        raise ScriptError(f"La imagen «{path.name}» supera el límite de 4 MB.")
    extension = path.suffix.lower()
    if extension == ".svg":
        content = sanitize_svg(content, path.name)
    mime_type = IMAGE_MIME_TYPES.get(extension)
    if not mime_type:
        raise ScriptError(f"Formato de imagen no permitido: {extension}")
    return f"data:{mime_type};base64,{base64.b64encode(content).decode('ascii')}"


def build_javascript(script, script_path=None, adblock_enabled=True):
    actions = [dict(action) for action in script["actions"]]
    total_size = 0
    image_ids = {}
    images = {}
    for action in actions:
        if action["type"] == "BOTON_ALTERNAR":
            group_name = action.pop("_group_name", script["name"])
            group = hashlib.sha256(
                (group_name + "\0" + action["targets"]).encode("utf-8")
            ).hexdigest()[:16]
            action["group"] = group
            action["button_prefix"] = (
                "operython-toggle-"
                + hashlib.sha256(
                    (group + "\0" + action["selector"]).encode("utf-8")
                ).hexdigest()[:16]
            )
        if action["type"] != "IMAGEN":
            continue
        asset_script_path = action.pop("_script_path", script_path)
        path = _resolved_asset_path(asset_script_path, action.pop("asset"))
        key = str(path)
        if key not in image_ids:
            try:
                size = path.stat().st_size
            except OSError as error:
                raise ScriptError(
                    f"No se pudo leer la imagen «{path.name}»: {error}"
                ) from error
            total_size += size
            if total_size > MAX_TOTAL_ASSETS_SIZE:
                raise ScriptError("Las imágenes del script superan el límite total de 12 MB.")
            image_ids[key] = len(image_ids)
            images[image_ids[key]] = _image_data_uri(path)
        action["image_id"] = image_ids[key]
    actions = json.dumps(actions, ensure_ascii=True)
    images = json.dumps(images, ensure_ascii=True)
    adblock_enabled_json = json.dumps(bool(adblock_enabled))
    return f"""(() => {{
  const actions = {actions};
  const images = {images};
  const generalAdBlockEnabled = {adblock_enabled_json};
  const adBlockStateKey = "__operythonGeneralAdBlockState";
  const adBlockState = window[adBlockStateKey] || {{
    blocked: new Map(), enabled: false
  }};
  if (!(adBlockState.blocked instanceof Map)) adBlockState.blocked = new Map();
  window[adBlockStateKey] = adBlockState;
  const youtubeAdSkipEnabled = actions.some(
    action => action.type === "YOUTUBE_SALTAR_ANUNCIOS"
  );
  const youtubeAdSkipStateKey = "__operythonYouTubeAdSkipState";
  const previousYouTubeAdSkip = window[youtubeAdSkipStateKey];
  if (previousYouTubeAdSkip) {{
    previousYouTubeAdSkip.observer.disconnect();
    clearInterval(previousYouTubeAdSkip.interval);
    previousYouTubeAdSkip.restore();
    delete window[youtubeAdSkipStateKey];
  }}
  if (youtubeAdSkipEnabled) {{
    const playerStates = new Map();
    const restorePlayer = (player, original) => {{
      if (!player.isConnected) return;
      if (original.visibility)
        player.style.setProperty(
          "visibility", original.visibility, original.visibilityPriority
        );
      else player.style.removeProperty("visibility");
      if (original.video && original.video.isConnected)
        original.video.muted = original.muted;
    }};
    const restoreAllPlayers = () => {{
      for (const [player, original] of playerStates)
        restorePlayer(player, original);
      playerStates.clear();
    }};
    const handleYouTubeAd = () => {{
      const player = document.querySelector("#movie_player");
      if (!player) {{
        restoreAllPlayers();
        return;
      }}
      const adIsPlaying = player.classList.contains("ad-showing") ||
        player.classList.contains("ad-interrupting");
      const original = playerStates.get(player);
      if (!adIsPlaying) {{
        if (original) {{
          restorePlayer(player, original);
          playerStates.delete(player);
        }}
        return;
      }}
      if (!original) {{
        const video = player.querySelector("video");
        playerStates.set(player, {{
          visibility: player.style.getPropertyValue("visibility"),
          visibilityPriority: player.style.getPropertyPriority("visibility"),
          video,
          muted: video ? video.muted : false
        }});
      }}
      player.style.setProperty("visibility", "hidden", "important");
      const video = player.querySelector("video");
      if (video) video.muted = true;
      const skipButton = player.querySelector(
        ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, " +
        ".ytp-skip-ad-button"
      );
      if (
        skipButton &&
        !skipButton.disabled &&
        skipButton.getClientRects().length > 0
      ) skipButton.click();
      else if (video && Number.isFinite(video.duration) && video.seekable.length) {{
        try {{
          video.currentTime = video.seekable.end(video.seekable.length - 1);
        }} catch (error) {{
          // Some ad streams do not allow seeking.
        }}
      }}
    }};
    const observer = new MutationObserver(handleYouTubeAd);
    observer.observe(document.documentElement, {{
      childList: true, subtree: true, attributes: true,
      attributeFilter: ["class"]
    }});
    const interval = setInterval(handleYouTubeAd, 250);
    const state = {{
      observer,
      interval,
      restore: restoreAllPlayers
    }};
    window[youtubeAdSkipStateKey] = state;
    handleYouTubeAd();
  }}
  const adEventExceptionPattern =
    /\\b(event|events|evento|eventos|festival|festivales|concert|concerts|concierto|conciertos|conference|conferencia|conferencias|webinar|webinars|meetup|meetups|feria|ferias|exposición|exposicion)\\b/i;
  const adLabelPattern =
    /^(ad|ads|advertisement|advertising|sponsored|promoted|publicidad|anuncio|anuncios|patrocinado|patrocinada|contenido patrocinado|promocionado|anzeige|werbung|publicité|annonce|pubblicità|reklama)$/i;
  const explicitAdSelector = [
    "ins.adsbygoogle", "[data-ad]", "[data-ad-slot]", "[data-ad-client]",
    "[id^='google_ads']", "[id^='div-gpt-ad']",
    "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
    "iframe[src*='adservice.google.']", "iframe[src*='adnxs.com']"
  ].join(",");
  const adIdentityPattern =
    /(^|[-_\\s])(ad|ads|advert|advertisement|advertising|sponsor|sponsored|promoted)([-_\\s]|$)/i;
  const adCandidateSelector =
    "article, li, [role='article'], [data-testid], [class], [id]";
  const protectedMediaSelector =
    "video, .video-stream, .html5-video-player, #movie_player, ytd-player, " +
    ".ytp-ad-player-overlay";
  const isProtectedMediaElement = element => {{
    if (!(element instanceof HTMLElement)) return false;
    return element.matches(protectedMediaSelector) ||
      Boolean(element.closest(protectedMediaSelector)) ||
      Boolean(element.querySelector(protectedMediaSelector));
  }};
  const hideAdElement = element => {{
    if (
      !(element instanceof HTMLElement) ||
      element.hidden ||
      isProtectedMediaElement(element)
    ) return;
    const text = (element.innerText || element.textContent || "").slice(0, 1600);
    if (adEventExceptionPattern.test(text)) return;
    if (!adBlockState.blocked.has(element))
      adBlockState.blocked.set(element, {{
        hidden: element.hidden,
        label: (text || element.getAttribute("aria-label") || element.id ||
          element.className || element.tagName).trim().slice(0, 180)
      }});
    element.hidden = true;
    element.setAttribute("data-operython-ad-hidden", "true");
  }};
  const restoreBlockedAds = () => {{
    for (const [element, original] of adBlockState.blocked) {{
      if (!element.isConnected) continue;
      element.hidden = original.hidden;
      element.removeAttribute("data-operython-ad-hidden");
    }}
    adBlockState.blocked.clear();
  }};
  const getBlockedAdReport = () => {{
    const items = [];
    for (const [element, original] of adBlockState.blocked) {{
      if (!element.isConnected) {{
        adBlockState.blocked.delete(element);
        continue;
      }}
      if (items.length < 100) {{
        const identity = element.id ? "#" + element.id :
          (typeof element.className === "string" && element.className.trim()
            ? "." + element.className.trim().split(/\\s+/).slice(0, 2).join(".")
            : element.tagName.toLowerCase());
        items.push(identity + (original.label ? " — " + original.label : ""));
      }}
    }}
    return {{enabled: adBlockState.enabled, count: adBlockState.blocked.size, items}};
  }};
  window.__operythonAdBlockReport = getBlockedAdReport;
  const applyGeneralAdBlock = () => {{
    if (!document.documentElement) return;
    for (const [element, original] of adBlockState.blocked) {{
      if (!isProtectedMediaElement(element)) continue;
      element.hidden = original.hidden;
      element.removeAttribute("data-operython-ad-hidden");
      adBlockState.blocked.delete(element);
    }}
    let explicitAds = [];
    try {{
      explicitAds = document.querySelectorAll(explicitAdSelector);
    }} catch (error) {{}}
    for (const element of Array.from(explicitAds).slice(0, 1000))
      hideAdElement(element);

    for (const element of Array.from(
      document.querySelectorAll(adCandidateSelector)
    ).slice(0, 12000)) {{
      if (!(element instanceof HTMLElement) || element.hidden) continue;
      const identity = [
        element.id,
        typeof element.className === "string" ? element.className : "",
        element.getAttribute("data-testid") || "",
        element.getAttribute("aria-label") || ""
      ].join(" ");
      if (!adIdentityPattern.test(identity)) continue;
      hideAdElement(element);
    }}

    for (const label of Array.from(document.querySelectorAll(
      "[aria-label], [data-testid], span, small, strong"
    )).slice(0, 12000)) {{
      const text = (
        label.getAttribute("aria-label") ||
        label.getAttribute("data-testid") ||
        label.textContent ||
        ""
      ).trim();
      if (!adLabelPattern.test(text)) continue;
      let candidate = label;
      let fallback = null;
      for (let depth = 0; depth < 5 && candidate.parentElement; depth++) {{
        candidate = candidate.parentElement;
        fallback = candidate;
        if (candidate.matches(
          "article, li, [role='article'], [class*='card'], [data-testid*='card']"
        )) {{
          fallback = candidate;
          break;
        }}
      }}
      if (fallback) hideAdElement(fallback);
    }}
  }};
  if (window.__operythonGeneralAdObserver)
    window.__operythonGeneralAdObserver.disconnect();
  adBlockState.enabled = generalAdBlockEnabled;
  if (generalAdBlockEnabled) {{
    applyGeneralAdBlock();
    window.__operythonGeneralAdObserver = new MutationObserver(() => {{
      if (window.__operythonGeneralAdTimer) return;
      window.__operythonGeneralAdTimer = setTimeout(() => {{
        window.__operythonGeneralAdTimer = 0;
        applyGeneralAdBlock();
      }}, 250);
    }});
    window.__operythonGeneralAdObserver.observe(document.documentElement, {{
      childList: true, subtree: true
    }});
  }} else {{
    if (window.__operythonGeneralAdTimer)
      clearTimeout(window.__operythonGeneralAdTimer);
    window.__operythonGeneralAdTimer = 0;
    restoreBlockedAds();
    window.__operythonGeneralAdObserver = null;
  }}
  const externalNavigationGuardKey = "__operythonExternalNavigationGuard";
  const oldExternalNavigationGuard = window[externalNavigationGuardKey];
  if (oldExternalNavigationGuard) {{
    document.removeEventListener("click", oldExternalNavigationGuard.handleEvent, true);
    document.removeEventListener("auxclick", oldExternalNavigationGuard.handleEvent, true);
    document.removeEventListener("submit", oldExternalNavigationGuard.handleEvent, true);
    if (window.open === oldExternalNavigationGuard.openWrapper)
      window.open = oldExternalNavigationGuard.originalOpen;
    delete window[externalNavigationGuardKey];
  }}
  if (actions.some(action => action.type === "BLOQUEAR_EXTERNOS")) {{
    const handleExternalNavigation = event => {{
      let destination = "";
      if (event.type === "submit") {{
        const form = event.target;
        if (form instanceof HTMLFormElement) destination = form.action;
      }} else if (event.target instanceof Element) {{
        const link = event.target.closest("a[href], area[href]");
        if (link) destination = link.href;
      }}
      if (!destination) return;
      try {{
        if (new URL(destination, location.href).origin !== location.origin) {{
          event.preventDefault();
          event.stopImmediatePropagation();
        }}
      }} catch (error) {{
        event.preventDefault();
        event.stopImmediatePropagation();
      }}
    }};
    const originalOpen = window.open;
    const openWrapper = function(url, ...args) {{
      try {{
        if (url && new URL(url, location.href).origin !== location.origin)
          return null;
      }} catch (error) {{
        return null;
      }}
      return originalOpen.call(this, url, ...args);
    }};
    document.addEventListener("click", handleExternalNavigation, true);
    document.addEventListener("auxclick", handleExternalNavigation, true);
    document.addEventListener("submit", handleExternalNavigation, true);
    window.open = openWrapper;
    window[externalNavigationGuardKey] = {{
      handleEvent: handleExternalNavigation, originalOpen, openWrapper
    }};
  }}
  window.__operythonToggleStates = window.__operythonToggleStates || {{}};
  const activeToggleGroups = new Set(
    actions.filter(action => action.type === "BOTON_ALTERNAR")
      .map(action => action.group)
  );
  for (const [group, state] of Object.entries(window.__operythonToggleStates)) {{
    if (activeToggleGroups.has(group)) continue;
    if (state && state.targets instanceof Map) {{
      for (const [target, hidden] of state.targets)
        target.hidden = hidden;
      for (const [target, original] of state.sizes) {{
        if (original.value) target.style.setProperty("max-width", original.value, original.priority);
        else target.style.removeProperty("max-width");
      }}
    }}
    if (state && state.buttons instanceof Set)
      for (const button of state.buttons) button.remove();
    for (const button of document.querySelectorAll(
      "button[id^='operython-toggle-" + group + "-']"
    )) button.remove();
    delete window.__operythonToggleStates[group];
  }}
  for (const group of activeToggleGroups) {{
    let state = window.__operythonToggleStates[group];
    if (!state || !(state.targets instanceof Map)) {{
      state = window.__operythonToggleStates[group] = {{
        expanded: Boolean(state), targets: new Map(), sizes: new Map(), buttons: new Set()
      }};
    }}
    state.currentButtons = new Set();
  }}
  const syncToggleGroups = () => {{
    for (const action of actions) {{
      if (action.type !== "BOTON_ALTERNAR") continue;
      const state = window.__operythonToggleStates[action.group];
      const expanded = state.expanded;
      let targets;
      let anchors;
      let sizeTargets = [];
      try {{
        targets = document.querySelectorAll(action.targets);
        anchors = document.querySelectorAll(action.selector);
        if (action.size_selector)
          sizeTargets = document.querySelectorAll(action.size_selector);
      }} catch (error) {{
        continue;
      }}
      for (const target of targets) {{
        if (!state.targets.has(target))
          state.targets.set(target, target.hidden);
        target.hidden = !expanded;
      }}
      if (action.size_selector && action.collapsed_max_width) {{
        for (const target of sizeTargets) {{
          if (!state.sizes.has(target))
            state.sizes.set(target, {{
              value: target.style.getPropertyValue("max-width"),
              priority: target.style.getPropertyPriority("max-width")
            }});
          if (expanded) {{
            const original = state.sizes.get(target);
            if (original.value)
              target.style.setProperty("max-width", original.value, original.priority);
            else target.style.removeProperty("max-width");
          }} else {{
            target.style.setProperty("max-width", action.collapsed_max_width);
          }}
        }}
      }}
      for (let index = 0; index < Math.min(anchors.length, 20); index++) {{
        const button = document.getElementById(action.button_prefix + "-" + index);
        if (!button) continue;
        state.currentButtons.add(button);
        const label = expanded ? action.hide_label : action.show_label;
        if (button.textContent !== label) button.textContent = label;
        button.setAttribute("aria-expanded", String(expanded));
      }}
    }}
  }};
  const darkenLightUi = () => {{
    const excluded = "canvas, svg, img, video, iframe, picture, .blocklyBlock, [class*='stage_stage'], [class*='stage-wrapper']";
    for (const root of [document.documentElement, document.body]) {{
      if (!root) continue;
      root.style.setProperty("background-image", "none", "important");
      root.style.setProperty("background-color", "#17191f", "important");
    }}
    const elements = [document.documentElement, document.body,
      ...document.body.querySelectorAll("*")];
    for (let index = 0; index < Math.min(elements.length, 8000); index++) {{
      const element = elements[index];
      if (!element || element.matches(excluded) || element.closest(excluded)) continue;
      const control = element.matches(
        "button, input, select, textarea, [role='button'], [class*='button']"
      );
      if (control) {{
        element.style.setProperty("background-image", "none", "important");
        element.style.setProperty("background-color", "#30343f", "important");
        element.style.setProperty("color", "#f1f3f8", "important");
        continue;
      }}
      const background = getComputedStyle(element).backgroundColor;
      const channels = background.match(/[\\d.]+/g);
      if (!channels || channels.length < 3) continue;
      const [red, green, blue] = channels.map(Number);
      const light = Math.min(red, green, blue) > 185;
      const scratchPurple = red >= 90 && blue >= 150 && blue - red > 40 &&
        blue - green > 55;
      if (!light && !scratchPurple) continue;
      element.style.setProperty("background-image", "none", "important");
      element.style.setProperty("background-color", "#20232b", "important");
      const foreground = getComputedStyle(element).color.match(/[\\d.]+/g);
      if (foreground && foreground.length >= 3) {{
        const [textRed, textGreen, textBlue] = foreground.map(Number);
        if ((textRed * 299 + textGreen * 587 + textBlue * 114) / 1000 < 150)
          element.style.setProperty("color", "#f1f3f8", "important");
      }}
    }}
  }};
  const apply = () => {{
    for (const action of actions) {{
      if (action.type === "OSCURO_UI") {{
        darkenLightUi();
        continue;
      }}
      if (action.type === "YOUTUBE_SALTAR_ANUNCIOS") continue;
      if (action.type === "BLOQUEAR_EXTERNOS") continue;
      let elements;
      try {{ elements = document.querySelectorAll(action.selector); }}
      catch (error) {{ continue; }}
      for (let index = 0; index < Math.min(elements.length, 500); index++) {{
        const element = elements[index];
        if (action.type === "BOTON_ALTERNAR") {{
          if (index >= 20 || !element.parentNode) continue;
          const buttonId = action.button_prefix + "-" + index;
          let button = document.getElementById(buttonId);
          if (!button) {{
            button = document.createElement("button");
            button.id = buttonId;
            button.type = "button";
            button.setAttribute("data-operython-toggle-group", action.group);
            button.style.cssText =
              "display:inline-flex;width:fit-content;max-width:100%;" +
              "min-width:0;box-sizing:border-box;white-space:nowrap;" +
              "align-items:center;justify-content:center;" +
              "margin:10px 0;padding:8px 16px;border:0;" +
              "border-radius:18px;background:#272727;color:#f1f1f1;" +
              "font:500 14px Arial,sans-serif;cursor:pointer";
            button.addEventListener("click", () => {{
              const state = window.__operythonToggleStates[action.group];
              state.expanded = !state.expanded;
              syncToggleGroups();
            }});
          }}
          if (
            button.parentNode !== element.parentNode ||
            element.previousElementSibling !== button
          ) element.parentNode.insertBefore(button, element);
          window.__operythonToggleStates[action.group].currentButtons.add(button);
          continue;
        }}
        else if (action.type === "OCULTAR") {{
          if (action.count_as_ad) hideAdElement(element);
          else if (!isProtectedMediaElement(element)) element.hidden = true;
        }}
        else if (action.type === "MOSTRAR") element.hidden = false;
        else if (action.type === "TEXTO" && element.textContent !== action.value)
          element.textContent = action.value;
        else if (action.type === "REEMPLAZAR" && element.textContent.includes(action.search)) {{
          const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
          let textNode;
          while ((textNode = walker.nextNode()))
            textNode.nodeValue = textNode.nodeValue.split(action.search).join(action.value);
        }}
        else if (action.type === "TAMANO") {{
          element.style.setProperty("width", action.width);
          element.style.setProperty("height", action.height);
        }}
        else if (action.type === "IMAGEN") {{
          if (element.tagName === "IMG") {{
            if (element.src === images[action.image_id]) continue;
            element.src = images[action.image_id];
            element.alt = action.alt;
            element.style.maxWidth = "100%";
            element.style.maxHeight = "100%";
            element.style.objectFit = "contain";
            continue;
          }}
          if (element.firstElementChild &&
              element.firstElementChild.tagName === "IMG" &&
              element.firstElementChild.src === images[action.image_id]) continue;
          const image = document.createElement("img");
          image.src = images[action.image_id];
          image.alt = action.alt;
          image.style.maxWidth = "100%";
          image.style.maxHeight = "100%";
          image.style.objectFit = "contain";
          if (/^(AREA|BASE|BR|COL|EMBED|HR|INPUT|LINK|META|PARAM|SOURCE|TRACK|WBR)$/.test(element.tagName))
            element.replaceWith(image);
          else element.replaceChildren(image);
        }}
        else if (action.type === "ESTILO")
          element.style.setProperty(action.property, action.value);
        else if (action.type === "CLASE")
          element.classList.add(action.value);
      }}
    }}
    for (const group of activeToggleGroups) {{
      const state = window.__operythonToggleStates[group];
      for (const button of state.buttons)
        if (!state.currentButtons.has(button)) button.remove();
      state.buttons = state.currentButtons;
    }}
    syncToggleGroups();
  }};
  if (window.__operythonScriptObserver)
    window.__operythonScriptObserver.disconnect();
  apply();
  window.__operythonScriptObserver = new MutationObserver(apply);
  window.__operythonScriptObserver.observe(document.documentElement, {{
    childList: true, subtree: true
  }});
  if (actions.some(action => action.type === "OSCURO_UI")) {{
    if (window.__operythonDarkUiObserver)
      window.__operythonDarkUiObserver.disconnect();
  }}
  if (actions.some(action => action.type === "OSCURO_UI"))
    window.__operythonDarkUiObserver = new MutationObserver(() => {{
    if (window.__operythonDarkUiFrame) return;
    window.__operythonDarkUiFrame = requestAnimationFrame(() => {{
      window.__operythonDarkUiFrame = 0;
      darkenLightUi();
    }});
    }});
  if (window.__operythonDarkUiObserver) {{
    window.__operythonDarkUiObserver.disconnect();
    window.__operythonDarkUiObserver.observe(document.documentElement, {{
    childList: true, subtree: true
    }});
  }}
}})();"""


def list_scripts():
    try:
        return _script_paths()
    except OSError as error:
        raise ScriptError(f"No se pudo leer la carpeta de scripts: {error}") from error


def read_script_state():
    try:
        config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        config = {}
    except (OSError, json.JSONDecodeError) as error:
        raise ScriptError(f"No se pudo leer la configuración maestra: {error}") from error
    if not isinstance(config, dict):
        raise ScriptError("La configuración maestra tiene un formato no válido.")

    data = config.get(STATE_CONFIG_KEY)
    if data is None and LEGACY_STATE_FILE.exists():
        try:
            data = json.loads(LEGACY_STATE_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise ScriptError(f"No se pudo migrar el estado de scripts: {error}") from error
        if not isinstance(data, dict):
            raise ScriptError("El estado anterior de scripts tiene un formato no válido.")
        state = {str(name): bool(enabled) for name, enabled in data.items()}
        write_script_state(state)
        try:
            LEGACY_STATE_FILE.unlink()
        except OSError as error:
            raise ScriptError(
                f"El estado se guardó en la configuración maestra, pero no se pudo "
                f"quitar el archivo anterior: {error}"
            ) from error
        return state

    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ScriptError("El estado de scripts en la configuración maestra no es válido.")
    return {str(name): bool(enabled) for name, enabled in data.items()}


def write_script_state(state):
    try:
        try:
            config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except FileNotFoundError:
            config = {}
        if not isinstance(config, dict):
            raise ScriptError("La configuración maestra tiene un formato no válido.")
        config[STATE_CONFIG_KEY] = {
            str(name): bool(enabled) for name, enabled in state.items()
        }
        CONFIG_FILE.write_text(
            json.dumps(config, ensure_ascii=False, indent=4), encoding="utf-8"
        )
    except ScriptError:
        raise
    except (OSError, json.JSONDecodeError) as error:
        raise ScriptError(
            f"No se pudo guardar el estado de scripts en la configuración maestra: {error}"
        ) from error


def read_script_function_state():
    try:
        config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        config = {}
    except (OSError, json.JSONDecodeError) as error:
        raise ScriptError(
            f"No se pudo leer la configuración maestra: {error}"
        ) from error
    if not isinstance(config, dict):
        raise ScriptError("La configuración maestra tiene un formato no válido.")
    data = config.get(FEATURE_STATE_CONFIG_KEY, {})
    if not isinstance(data, dict):
        raise ScriptError("La configuración de funciones de scripts no es válida.")
    state = {}
    for script_key, functions in data.items():
        if not isinstance(functions, dict) or any(
            not isinstance(enabled, bool) for enabled in functions.values()
        ):
            raise ScriptError("La configuración de funciones de scripts no es válida.")
        state[str(script_key)] = {
            str(function_key): enabled
            for function_key, enabled in functions.items()
        }
    return state


def write_script_function_state(state):
    try:
        try:
            config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except FileNotFoundError:
            config = {}
        if not isinstance(config, dict):
            raise ScriptError("La configuración maestra tiene un formato no válido.")
        clean_state = {}
        for script_key, functions in state.items():
            if not isinstance(functions, dict) or any(
                not isinstance(enabled, bool) for enabled in functions.values()
            ):
                raise ScriptError(
                    "La configuración de funciones de scripts no es válida."
                )
            clean_state[str(script_key)] = {
                str(function_key): enabled
                for function_key, enabled in functions.items()
            }
        config[FEATURE_STATE_CONFIG_KEY] = clean_state
        CONFIG_FILE.write_text(
            json.dumps(config, ensure_ascii=False, indent=4), encoding="utf-8"
        )
    except ScriptError:
        raise
    except (OSError, json.JSONDecodeError) as error:
        raise ScriptError(
            f"No se pudo guardar la configuración de funciones de scripts: {error}"
        ) from error


def load_enabled_scripts():
    state = read_script_state()
    loaded = []
    errors = []
    for path in list_scripts():
        state_key = script_state_key(path)
        if not state.get(state_key, True):
            continue
        try:
            script = parse_script(path.read_text(encoding="utf-8"))
            validate_script_assets(script, path)
        except (OSError, UnicodeDecodeError, ScriptError) as error:
            errors.append(f"{script_state_key(path)}: {error}")
            continue
        loaded.append((path, script))
    return loaded, errors
