import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

from OperythonScripts import (
    SCRIPTS_DIR,
    ScriptError,
    create_script_package_path,
    parse_script,
    validate_script_assets,
)


PLANTILLA = """# Cada línea es una instrucción. No se permite código Python o JavaScript libre.
NOMBRE | Mi ajuste
DESCRIPCION | Explica brevemente qué cambia este script en la página.
SITIO | scratch.mit.edu
Logotipe: disabled

# Acciones disponibles:
# OCULTAR | selector CSS
# MOSTRAR | selector CSS
# TEXTO | selector CSS | texto nuevo
# REEMPLAZAR | selector CSS | texto actual | texto nuevo
# TAMANO | selector CSS | ancho | alto
# IMAGEN | selector CSS | archivo.png | texto alternativo
# BOTON | selector CSS | elementos a alternar | Ver más | Ver menos
# BOTON | selector | elementos | Ver más | Ver menos | selector tamaño | ancho máximo oculto
# ESTILO | selector CSS | propiedad permitida | valor
# CLASE | selector CSS | nombre-de-clase
# OSCURO | UI
# BLOQUEAR_EXTERNOS
# YOUTUBE_SALTAR_ANUNCIOS

OCULTAR | .selector-de-ejemplo
"""

AYUDA = """<b>Lenguaje de scripts de Operython</b><br>
Cada línea lleva valores separados por <code>|</code>. Las líneas vacías y con
<code>#</code> se ignoran.<br><br>
<code>NOMBRE | Texto</code> — nombre para la lista.<br>
<code>DESCRIPCION | Texto</code> — explica con palabras sencillas qué hace el script.<br>
<code>SITIO | scratch.mit.edu</code> — dominio exacto autorizado. Puedes repetirlo.<br>
<code>SITIO | *.scratch.mit.edu</code> — dominio y subdominios.<br>
<code>Logotipe: enabled</code> — muestra un logo junto al script en Operython.
Puedes indicar el archivo con <code>Logo: Scratch.png</code> o usar por defecto
<code>logo.png</code>, <code>logo.jpg</code>, <code>logo.jpeg</code> o
<code>logo.svg</code> en la carpeta de recursos.<br>
<code>Logotipe: disabled</code> — no muestra logo (valor predeterminado).<br>
<code>OCULTAR | selector CSS</code> — oculta elementos coincidentes.<br>
<code>MOSTRAR | selector CSS</code> — vuelve a mostrar elementos.<br>
<code>TEXTO | selector CSS | texto</code> — cambia el texto de elementos coincidentes.<br>
<code>REEMPLAZAR | selector CSS | texto actual | texto nuevo</code> — reemplaza
coincidencias sin borrar enlaces ni otros elementos internos.<br>
<code>TAMANO | selector CSS | 240px | 120px</code> — ajusta ancho y alto.
También acepta <code>%</code>, <code>rem</code>, <code>em</code>, <code>vw</code>,
<code>vh</code> y <code>auto</code>.<br>
<code>IMAGEN | selector CSS | logo.png | descripción</code> — reemplaza el
contenido del elemento por una imagen.<br>
<code>BOTON | selector CSS | elementos | Ver más | Ver menos</code> — agrega un
botón antes del elemento; alterna la visibilidad de los selectores indicados,
que pueden separarse con comas. Opcionalmente agrega
<code>| selector de tamaño | ancho máximo al ocultar</code> para limitar el
ancho de otro elemento mientras están ocultos.<br>
<code>ESTILO | selector CSS | propiedad | valor</code> — cambia un estilo visual.<br>
<code>CLASE | selector CSS | nombre-clase</code> — agrega una clase CSS.<br><br>
<code>YOUTUBE_SALTAR_ANUNCIOS</code> — en YouTube oculta y silencia el
reproductor mientras detecta un anuncio y pulsa el botón para saltarlo cuando
está disponible; restaura el reproductor y el volumen al empezar el video.<br>
<code>BLOQUEAR_EXTERNOS</code> — bloquea enlaces, formularios y redirecciones
a otros sitios; permite navegar dentro del mismo origen.<br><br>
Cada script se guarda en una carpeta propia dentro de <code>scripts_web</code>,
con el archivo <code>script.txt</code> y su subcarpeta <code>assets</code>.
Guarda allí las imágenes y usa solo su ruta relativa, por ejemplo
<code>logo.png</code>. Se aceptan PNG, JPG y SVG; límite de 4 MB por archivo
y 12 MB por script. También puedes descomprimir una carpeta de script con esta
estructura directamente dentro de <code>scripts_web</code>. Al importar un
TXT, Operython lo guarda como <code>script.txt</code> en una carpeta propia y
copia a su <code>assets</code> únicamente los recursos declarados por el script.
Busca esos archivos junto al TXT, en su carpeta <code>assets</code> o dentro de
la carpeta de Operython. No hace falta importar archivos ZIP.<br><br>
<code>OSCURO | UI</code> — oscurece fondos claros y morados de la interfaz,
incluidos menús que se abren después. Evita imágenes, SVG, bloques y el escenario.<br><br>
Propiedades permitidas: <code>color</code>, <code>background-color</code>,
<code>border-color</code>, <code>fill</code> (para gráficos SVG),
<code>font-size</code>, <code>font-weight</code>,
<code>opacity</code> y <code>text-decoration</code>.<br><br>
No admite JavaScript/Python arbitrario, clics, formularios ni acceso a red.
Se ejecuta únicamente en los sitios declarados, tras confirmar que confías
en el script. Puede cambiar la apariencia o el texto de esas páginas.
Operython también oculta anuncios identificados como tales en las páginas
visitadas; conserva los anuncios cuyo contenido menciona eventos."""


class EditorScripts(QMainWindow):
    def __init__(self, path=None):
        super().__init__()
        self.path = Path(path) if path else None
        self.setWindowTitle("Editor de scripts web de Operython")
        self.resize(900, 680)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        self.lbl_path = QLabel()
        self.lbl_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.lbl_path)

        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText(PLANTILLA)
        self.editor.setPlainText(PLANTILLA)
        layout.addWidget(self.editor, 3)

        self.lbl_help = QLabel(AYUDA)
        self.lbl_help.setWordWrap(True)
        self.lbl_help.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(self.lbl_help, 2)

        buttons = QHBoxLayout()
        self.btn_open = QPushButton("Abrir TXT")
        self.btn_open.clicked.connect(self.open_script)
        buttons.addWidget(self.btn_open)
        self.btn_save = QPushButton("Guardar")
        self.btn_save.clicked.connect(self.save_script)
        buttons.addWidget(self.btn_save)
        self.btn_validate = QPushButton("Validar")
        self.btn_validate.clicked.connect(self.validate_script)
        buttons.addWidget(self.btn_validate)
        layout.addLayout(buttons)

        self.load_path()

    def load_path(self):
        if not self.path:
            self.lbl_path.setText("Nuevo script (todavía no guardado)")
            return
        try:
            self.editor.setPlainText(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError) as error:
            QMessageBox.warning(self, "No se pudo abrir", str(error))
            self.path = None
            return
        self.lbl_path.setText(str(self.path))

    def open_script(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Abrir script", str(SCRIPTS_DIR), "Scripts de Operython (*.txt)"
        )
        if path:
            self.path = Path(path)
            self.load_path()

    def validate_script(self):
        try:
            script = parse_script(self.editor.toPlainText())
            validate_script_assets(script, self.path)
        except ScriptError as error:
            QMessageBox.warning(self, "Script no válido", str(error))
            return False
        QMessageBox.information(
            self,
            "Script válido",
            f"Nombre: {script['name']}\n"
            f"Sitios: {', '.join(script['sites'])}\n"
            f"Acciones: {len(script['actions'])}",
        )
        return True

    def save_script(self):
        try:
            script = parse_script(self.editor.toPlainText())
        except ScriptError as error:
            QMessageBox.warning(self, "Script no válido", str(error))
            return
        if not self.path:
            try:
                self.path = create_script_package_path(script)
            except ScriptError as error:
                QMessageBox.warning(self, "Nombre de script no válido", str(error))
                return
        if self.path.suffix.lower() != ".txt":
            QMessageBox.warning(self, "Extensión no válida", "Los scripts deben guardarse como .txt.")
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            (self.path.parent / "assets").mkdir(parents=True, exist_ok=True)
            validate_script_assets(script, self.path)
            self.path.write_text(self.editor.toPlainText(), encoding="utf-8")
        except ScriptError as error:
            QMessageBox.warning(self, "Recursos no válidos", str(error))
            return
        except OSError as error:
            QMessageBox.warning(self, "No se pudo guardar", str(error))
            return
        self.lbl_path.setText(f"{self.path} — {script['name']}")
        QMessageBox.information(
            self,
            "Guardado",
            "Script guardado en su carpeta, junto a assets. "
            "También puedes copiar esa carpeta a otra instalación de Operython.",
        )


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = EditorScripts(sys.argv[1] if len(sys.argv) > 1 else None)
    window.show()
    sys.exit(app.exec())
