@echo off
title Operython GX
set "RUTA_ENV=%USERPROFILE%\Documents\Operython system\op_env"
set "RUTA_PROYECTO=%USERPROFILE%\Documents\Operython system"
set "ARCHIVO_PY=%USERPROFILE%\Documents\Operython system\Operython_gx.py"
set "PYTHON_ENV=%RUTA_ENV%\Scripts\python.exe"

echo ====================================================
echo  VERIFICANDO ENTORNO UNIVERSAL DE OPERYTHON GX
echo ====================================================

:: 1. Limpieza preventiva solo de instancias previas de Operython GX
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -eq 'python.exe' -or $_.Name -eq 'pythonw.exe') -and $_.CommandLine -like '*Operython_gx.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

:: 2. Buscamos el comando de Python correcto de la PC actual
set "PY_CMD="
python --version >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD (
    py --version >nul 2>&1 && set "PY_CMD=py"
)

if not defined PY_CMD (
    echo [X] ERROR: No se encontro ninguna instalacion de Python en esta PC.
    pause
    exit /b 1
)

:: 3. Verificamos que la carpeta del proyecto exista en Documentos
if not exist "%RUTA_PROYECTO%" mkdir "%RUTA_PROYECTO%"

:: 4. Verificamos o creamos el entorno virtual de forma correcta
if not exist "%PYTHON_ENV%" (
    echo [!] Creando entorno seguro en Documentos...
    "%PY_CMD%" -m venv "%RUTA_ENV%"
    
    if not exist "%PYTHON_ENV%" (
        echo [X] Fallo critico: No se pudo crear el entorno virtual.
        pause
        exit /b 1
    )
)

:: 5. Comprobamos los modulos desde el Python de op_env
"%PYTHON_ENV%" -c "from PySide6.QtCore import QUrl; from PySide6.QtGui import QIcon; from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput; from PySide6.QtWidgets import QApplication; from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineDownloadRequest; from PySide6.QtWebEngineWidgets import QWebEngineView" >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Componentes faltantes en op_env. Instalando PySide6 en ese entorno...
    "%PYTHON_ENV%" -m pip install --upgrade --force-reinstall --no-cache-dir PySide6
    if errorlevel 1 (
        echo [X] Error al instalar PySide6 en op_env. Revisa la conexion a internet.
        pause
        exit /b 1
    )
)

"%PYTHON_ENV%" -c "from PySide6.QtCore import QUrl; from PySide6.QtGui import QIcon; from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput; from PySide6.QtWidgets import QApplication; from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineDownloadRequest; from PySide6.QtWebEngineWidgets import QWebEngineView" >nul 2>&1
if errorlevel 1 (
    echo [X] PySide6 se instalo en op_env, pero siguen faltando modulos necesarios.
    echo     Revisa la instalacion de ese entorno y vuelve a intentarlo.
    pause
    exit /b 1
)

:: 6. WebView2 queda disponible como respaldo para videos incompatibles con Qt.
set "WEBVIEW2_SETUP=%TEMP%\OperythonWebView2Setup.exe"
set "WEBVIEW2_SDK=%RUTA_PROYECTO%\webview2_sdk"
set "WEBVIEW2_CORE_DLL=%WEBVIEW2_SDK%\package\lib\net462\Microsoft.Web.WebView2.Core.dll"
set "WEBVIEW2_WINFORMS_DLL=%WEBVIEW2_SDK%\package\lib\net462\Microsoft.Web.WebView2.WinForms.dll"
set "WEBVIEW2_LOADER_DLL=%WEBVIEW2_SDK%\package\runtimes\win-x64\native\WebView2Loader.dll"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$keys=@('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKCU:\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'); foreach($key in $keys){ try { $version=(Get-ItemProperty -LiteralPath $key -Name pv -ErrorAction Stop).pv; if($version -and $version -ne '0.0.0.0'){ exit 0 } } catch {} }; exit 1" >nul 2>&1
if errorlevel 1 (
    echo [!] Falta WebView2 Runtime. Descargando el instalador oficial de Microsoft...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri 'https://microsoft.com' -OutFile '%WEBVIEW2_SETUP%'; if(!(Test-Path -LiteralPath '%WEBVIEW2_SETUP%')){ exit 1 }"
    if errorlevel 1 (
        echo [X] No se pudo descargar WebView2 Runtime. Revisa la conexion a internet.
        pause
        exit /b 1
    )
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$process=Start-Process -FilePath '%WEBVIEW2_SETUP%' -ArgumentList '/silent','/install' -Wait -PassThru; if($process.ExitCode -notin @(0,1641,3010)){ exit $process.ExitCode }"
    if errorlevel 1 (
        echo [X] No se pudo instalar WebView2 Runtime.
        del /q "%WEBVIEW2_SETUP%" >nul 2>&1
        pause
        exit /b 1
    )
    del /q "%WEBVIEW2_SETUP%" >nul 2>&1
)

"%PYTHON_ENV%" -c "import pythonnet" >nul 2>&1
if errorlevel 1 (
    echo [!] Instalando el puente Python para WebView2...
    "%PYTHON_ENV%" -m pip install pythonnet==3.0.5
    if errorlevel 1 (
        echo [X] No se pudo instalar pythonnet para WebView2.
        pause
        exit /b 1
    )
)

if not exist "%WEBVIEW2_CORE_DLL%" (
    goto descargar_sdk_webview2
)
if not exist "%WEBVIEW2_WINFORMS_DLL%" (
    goto descargar_sdk_webview2
)
if not exist "%WEBVIEW2_LOADER_DLL%" (
    goto descargar_sdk_webview2
)
goto sdk_webview2_verificado

:descargar_sdk_webview2
    echo [!] Descargando el SDK oficial de WebView2...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root='%WEBVIEW2_SDK%'; New-Item -ItemType Directory -Force -Path $root | Out-Null; $archive=Join-Path $root 'package.zip'; Invoke-WebRequest -UseBasicParsing -Uri 'https://nuget.org' -OutFile $archive; Expand-Archive -LiteralPath $archive -DestinationPath (Join-Path $root 'package') -Force; Remove-Item -LiteralPath $archive"
    if errorlevel 1 (
        echo [X] No se pudo descargar el SDK de WebView2.
        pause
        exit /b 1
    )

if not exist "%WEBVIEW2_CORE_DLL%" (
    echo [X] La instalacion del SDK de WebView2 quedo incompleta.
    pause
    exit /b 1
)
if not exist "%WEBVIEW2_WINFORMS_DLL%" (
    echo [X] La instalacion del SDK de WebView2 quedo incompleta.
    pause
    exit /b 1
)
if not exist "%WEBVIEW2_LOADER_DLL%" (
    echo [X] La instalacion del SDK de WebView2 quedo incompleta.
    pause
    exit /b 1
)

:sdk_webview2_verificado
if not exist "%ARCHIVO_PY%" (
    echo [X] ERROR: No se encontro Operython_gx.py en "%RUTA_PROYECTO%".
    pause
    exit /b 1
)

echo [+] Entorno verificado con exito. Lanzando navegador visible...
echo ====================================================

:: 7. Lanzamiento directo protegido para rutas con espacios
"%PYTHON_ENV%" "%ARCHIVO_PY%"

echo.
echo [!] El navegador se ha cerrado.
pause
