import sys
import json
import os
import subprocess
from pathlib import Path
from urllib.parse import quote, urlsplit
import OperythonScripts as scripts_web
os.environ["QT_QUICK_BACKEND"] = "software"
RUTA_SISTEMA = Path.home() / "Documents" / "Operython system"
CONFIG_MAESTRA = RUTA_SISTEMA / "config_maestra_operython.json"
INDICES_COLOR = {
    "#00ff66": 0,
    "#ff1e4a": 1,
    "#00f0ff": 2,
    "#9d00ff": 3,
    "#ffcc00": 4,
    "#333333": 5,
    "#1a1a1a": 6,
    "#4a4a4a": 7,
    "#8b5a2b": 8,
}
PALETAS_COLOR = {
    0: ("#00ff66", "#33ff85", "#040d06", "#06140a", "#092111", "#0d2e18"),
    1: ("#ff1e4a", "#ff3c61", "#07080d", "#0b0c16", "#0d0f1a", "#121526"),
    2: ("#00f0ff", "#33f3ff", "#040c0d", "#061314", "#091f21", "#0d2b2f"),
    3: ("#9d00ff", "#b133ff", "#0a040d", "#0f0614", "#180921", "#210d2f"),
    4: ("#ffcc00", "#ffdd33", "#0d0a00", "#140f00", "#c1c800", "#2e2100"),
    5: ("#333333", "#444444", "#050507", "#0a0a0f", "#0f0f14", "#14141c"),
    6: ("#1a1a1a", "#2b2b2b", "#f5f6fa", "#e3e4f0", "#d1d2e6", "#c0c1db"),
    7: ("#4a4a4a", "#5a5a4a", "#dbdbdb", "#c8c8c8", "#b5b5b5", "#a2a2a2"),
    8: ("#8b5a2b", "#a06d3b", "#140b05", "#1c1109", "#29190e", "#362114"),
}


def cargar_modo_webgl():
    try:
        with CONFIG_MAESTRA.open("r", encoding="utf-8") as config_file:
            data = json.load(config_file)
    except FileNotFoundError:
        return "gpu"
    except (OSError, json.JSONDecodeError) as error:
        print(f"No se pudo leer el modo WebGL guardado; se usará GPU: {error}")
        return "gpu"
    mode = data.get("webgl_mode", "gpu") if isinstance(data, dict) else "gpu"
    if mode not in {"gpu", "swiftshader"}:
        print(f"Modo WebGL no reconocido ({mode!r}); se usará GPU.")
        return "gpu"
    return mode


MODO_WEBGL = cargar_modo_webgl()


def configurar_swiftshader_qtwebengine():
    if MODO_WEBGL != "swiftshader":
        return
    flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").split()
    for flag in (
        "--use-gl=angle",
        "--use-angle=swiftshader-webgl",
        "--enable-unsafe-swiftshader",
        "--enable-webgl",
    ):
        if flag not in flags:
            flags.append(flag)
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = " ".join(flags)


configurar_swiftshader_qtwebengine()

from PySide6.QtCore import (
    QObject,
    QUrl,
    Qt,
    QSize,
    QEvent,
    QPoint,
    QTimer,
    Signal,
    Slot,
)
from PySide6.QtGui import (
    QMouseEvent,
    QIcon,
    QKeySequence,
    QShortcut,
    QPainter,
    QPixmap,
    QWindow,
)
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                               QHBoxLayout, QLineEdit, QPushButton, QTabWidget, QToolBar,
                               QStackedWidget, QLabel, QComboBox, QFormLayout, QSplitter,
                               QListWidget, QListWidgetItem, QFileDialog, QInputDialog, QSpacerItem, QSizePolicy,
                               QSlider, QMessageBox, QDialog, QDialogButtonBox)
from PySide6.QtWebEngineCore import (
    QWebEngineProfile,
    QWebEnginePage,
)
from PySide6.QtWebEngineWidgets import QWebEngineView
RUTA_SISTEMA = Path.home() / "Documents" / "Operython system"
RUTA_SISTEMA.mkdir(parents=True, exist_ok=True)

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest


SDK_ROOT = Path(__file__).resolve().parent / "webview2_sdk" / "package"
USER_DATA_ROOT = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Operython GX" / "WebView2"
_NATIVE_DLL_DIRECTORY = None
_WEBVIEW2_TYPES = None
_WEBVIEW2_SURFACE_QUEUE = []
_WEBVIEW2_SURFACE_ACTIVE = None


def _encolar_superficie_webview2(superficie):
    _WEBVIEW2_SURFACE_QUEUE.append(superficie)
    _iniciar_siguiente_webview2()


def _iniciar_siguiente_webview2():
    global _WEBVIEW2_SURFACE_ACTIVE
    if _WEBVIEW2_SURFACE_ACTIVE is not None:
        return
    while _WEBVIEW2_SURFACE_QUEUE:
        superficie = _WEBVIEW2_SURFACE_QUEUE.pop(0)
        if superficie._webview2_closed:
            continue
        _WEBVIEW2_SURFACE_ACTIVE = superficie
        superficie._inicializar_webview2()
        return


def _finalizar_inicializacion_webview2(superficie, _success):
    global _WEBVIEW2_SURFACE_ACTIVE
    if _WEBVIEW2_SURFACE_ACTIVE is not superficie:
        return
    _WEBVIEW2_SURFACE_ACTIVE = None
    QTimer.singleShot(100, _iniciar_siguiente_webview2)


def _load_webview2_types():
    global _NATIVE_DLL_DIRECTORY, _WEBVIEW2_TYPES
    if _WEBVIEW2_TYPES is not None:
        return _WEBVIEW2_TYPES

    core_dll = next(
        (
            path
            for path in SDK_ROOT.rglob("Microsoft.Web.WebView2.Core.dll")
            if path.parent.name == "net462"
        ),
        None,
    )
    winforms_dll = next(
        (
            path
            for path in SDK_ROOT.rglob("Microsoft.Web.WebView2.WinForms.dll")
            if path.parent.name == "net462"
        ),
        None,
    )
    native_loader = SDK_ROOT / "runtimes" / "win-x64" / "native" / "WebView2Loader.dll"
    if not core_dll or not winforms_dll or not native_loader:
        raise RuntimeError(
            "Faltan los componentes SDK de WebView2. Cierra Operython y vuelve "
            "a iniciarlo desde Operython.bat para completar la instalación."
        )

    import pythonnet

    if pythonnet.get_runtime_info() is None:
        pythonnet.load("netfx")
    import clr

    _NATIVE_DLL_DIRECTORY = os.add_dll_directory(str(native_loader.parent))
    clr.AddReference("System.Windows.Forms")
    clr.AddReference(str(core_dll))
    clr.AddReference(str(winforms_dll))

    from Microsoft.Web.WebView2.WinForms import (
        CoreWebView2CreationProperties,
        WebView2,
    )
    _WEBVIEW2_TYPES = WebView2, CoreWebView2CreationProperties
    return _WEBVIEW2_TYPES


class WebView2Session(QObject):
    initialization_finished = Signal(bool)
    new_window_requested = Signal(str)
    console_message_received = Signal(str)
    navigation_started = Signal(str)
    url_changed = Signal(str)
    title_changed = Signal(str)
    load_finished = Signal(bool)
    error_occurred = Signal(str)
    script_completed = Signal(int, str)
    script_failed = Signal(int, str)

    def __init__(
        self, parent_widget, initial_url="about:blank", initial_html=None,
        navegador=None,
    ):
        super().__init__(parent_widget)
        WebView2, CoreWebView2CreationProperties = _load_webview2_types()

        from System.Windows.Forms import DockStyle

        self._navigator = navegador or parent_widget.window()
        self._initial_url = initial_url
        self._initial_html = initial_html
        self._virtual_url = ""
        self._ready = False
        self._initialization_completed = False
        self._initialization_succeeded = False
        self._initial_navigation_started = False
        self._reload_pending = False
        self._muted = False
        self._zoom = 1.0
        self._callbacks = {}
        self._next_callback_id = 0
        self._pending_scripts = []
        self._delegates = []
        self._browser = WebView2()
        self._browser.Dock = DockStyle.Fill
        properties = CoreWebView2CreationProperties()
        properties.UserDataFolder = str(USER_DATA_ROOT)
        if MODO_WEBGL == "swiftshader":
            properties.AdditionalBrowserArguments = (
                "--use-angle=swiftshader-webgl --enable-unsafe-swiftshader"
            )
        else:
            properties.AdditionalBrowserArguments = (
                "--use-gl=angle --disable-gpu-compositing"
            )
        self._browser.CreationProperties = properties
        USER_DATA_ROOT.mkdir(parents=True, exist_ok=True)

        self.script_completed.connect(self._finish_script)
        self.script_failed.connect(self._fail_script)
        self._browser.CoreWebView2InitializationCompleted += (
            self._on_initialization_completed
        )
        self._browser.CreateControl()
        self._browser.EnsureCoreWebView2Async()

        handle = int(self._browser.Handle.ToInt64())
        native_window = QWindow.fromWinId(handle)
        self.widget = QWidget.createWindowContainer(native_window, parent_widget)
        self.widget.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.widget.setGeometry(parent_widget.rect())
        self.widget.show()

    @property
    def url(self):
        if self._virtual_url:
            return self._virtual_url
        core = self._core()
        if core:
            return str(core.Source)
        return self._initial_url

    @property
    def title(self):
        core = self._core()
        return str(core.DocumentTitle) if core else ""

    @property
    def is_ready(self):
        return self._core() is not None

    def _core(self):
        return self._browser.CoreWebView2 if self._ready else None

    def _on_initialization_completed(self, _sender, event):
        if not event.IsSuccess:
            error = event.InitializationException
            self.error_occurred.emit(
                str(error) if error else "No se pudo iniciar WebView2."
            )
            self._initialization_completed = True
            self.initialization_finished.emit(False)
            return

        self._ready = True
        try:
            core = self._browser.CoreWebView2
            core.IsMuted = self._muted
            self._browser.ZoomFactor = self._zoom
            core.SourceChanged += self._on_source_changed
            core.DocumentTitleChanged += self._on_title_changed
            core.NavigationCompleted += self._on_navigation_completed
            core.NewWindowRequested += self._on_new_window_requested
            core.WebMessageReceived += self._on_web_message_received
            core.DownloadStarting += self._on_download_starting
            core.NavigationStarting += self._on_navigation_starting
            for script, callback_id in self._pending_scripts:
                self._execute_script(script, callback_id)
            self._pending_scripts.clear()
        except Exception as error:
            self.error_occurred.emit(
                f"No se pudo preparar el controlador WebView2: {error}"
            )
            self._initialization_completed = True
            self.initialization_finished.emit(False)
            return
        self._initialization_completed = True
        self._initialization_succeeded = True
        self.initialization_finished.emit(True)
        if not getattr(self._navigator, "_legacy_cookies_loaded", True):
            self._navigator.legacy_cookies_ready.connect(
                self._start_initial_navigation, Qt.ConnectionType.SingleShotConnection
            )
        else:
            self._start_initial_navigation()

    def _start_initial_navigation(self):
        core = self._core()
        if core is None:
            return
        if not getattr(self._navigator, "_legacy_cookies_imported", False):
            marker = USER_DATA_ROOT / "qt_cookies_imported"
            import_failed = False
            for data in getattr(self._navigator, "_legacy_cookies", ()):
                try:
                    cookie = core.CookieManager.CreateCookie(
                        data["name"], data["value"], data["domain"], data["path"]
                    )
                    cookie.IsHttpOnly = data["http_only"]
                    cookie.IsSecure = data["secure"]
                    if data["expires"]:
                        from System import DateTimeOffset

                        cookie.Expires = DateTimeOffset.FromUnixTimeSeconds(
                            data["expires"]
                        ).UtcDateTime
                    core.CookieManager.AddOrUpdateCookie(cookie)
                except Exception as error:
                    import_failed = True
                    print(f"No se pudo importar una cookie a WebView2: {error}")
            self._navigator._legacy_cookies_imported = True
            if not import_failed:
                try:
                    marker.write_text("ok", encoding="ascii")
                except OSError as error:
                    self.error_occurred.emit(
                        f"No se pudo guardar el estado de importación de cookies: {error}"
                    )
        if self._initial_html is not None:
            self._virtual_url = "https://operython/"
            self._initial_navigation_started = True
            core.NavigateToString(self._initial_html)
        else:
            self._initial_navigation_started = True
            core.Navigate(self._initial_url)
        self.url_changed.emit(self.url)

    def _on_source_changed(self, _sender, _event):
        self.url_changed.emit(self.url)

    def _on_title_changed(self, _sender, _event):
        self.title_changed.emit(self.title)

    def _on_navigation_completed(self, _sender, event):
        self.load_finished.emit(bool(event.IsSuccess))
        if self._reload_pending and self._initial_navigation_started:
            self._reload_pending = False
            core = self._core()
            if core is not None:
                core.Reload()

    def _on_navigation_starting(self, _sender, event):
        if not event.IsMainFrame:
            return
        source_url = self.url
        target_url = str(event.Uri)
        self.navigation_started.emit(target_url)
        if self._virtual_url and target_url != "about:blank":
            self._virtual_url = ""
        try:
            if scripts_web.should_block_external_navigation(source_url, target_url):
                event.Cancel = True
                print(
                    "Se bloqueó una navegación externa de Y2mate: "
                    f"{target_url}"
                )
        except scripts_web.ScriptError as error:
            print(f"No se pudo comprobar una redirección externa: {error}")

    def _on_new_window_requested(self, _sender, event):
        target_url = str(event.Uri)
        event.Handled = True
        try:
            if scripts_web.should_block_external_navigation(self.url, target_url):
                print(
                    "Se bloqueó una navegación externa de Y2mate: "
                    f"{target_url}"
                )
                return
        except scripts_web.ScriptError as error:
            print(f"No se pudo comprobar una redirección externa: {error}")
        self.new_window_requested.emit(target_url)

    def _on_web_message_received(self, _sender, event):
        self.console_message_received.emit(str(event.TryGetWebMessageAsString()))

    def _on_download_starting(self, _sender, event):
        self._navigator.procesar_solicitud_descarga(event)

    def navigate(self, url):
        self._virtual_url = ""
        self._initial_url = str(url)
        self._initial_html = None
        core = self._core()
        if core:
            core.Navigate(str(url))

    def set_html(self, html, url="https://operython/"):
        self._virtual_url = url
        self._initial_html = html
        self._initial_url = ""
        core = self._core()
        if core:
            core.NavigateToString(html)

    def back(self):
        core = self._core()
        if core and core.CanGoBack:
            core.GoBack()

    def forward(self):
        core = self._core()
        if core and core.CanGoForward:
            core.GoForward()

    def reload(self):
        core = self._core()
        if core:
            core.Reload()
        else:
            self._reload_pending = True

    def stop(self):
        core = self._core()
        if core:
            core.Stop()

    def set_muted(self, muted):
        self._muted = bool(muted)
        core = self._core()
        if core:
            core.IsMuted = self._muted

    def is_muted(self):
        core = self._core()
        return bool(core.IsMuted) if core else self._muted

    def set_zoom(self, zoom):
        self._zoom = float(zoom)
        if self._core():
            self._browser.ZoomFactor = self._zoom

    def zoom(self):
        if self._core():
            return float(self._browser.ZoomFactor)
        return self._zoom

    def execute_script(self, script, callback=None):
        callback_id = -1
        if callback is not None:
            callback_id = self._next_callback_id
            self._next_callback_id += 1
            self._callbacks[callback_id] = callback
        if self._core():
            self._execute_script(script, callback_id)
        else:
            self._pending_scripts.append((script, callback_id))

    def _execute_script(self, script, callback_id):
        from System import Action

        task = self._browser.CoreWebView2.ExecuteScriptAsync(script)
        if callback_id < 0:
            return

        def finish():
            try:
                self.script_completed.emit(
                    callback_id, str(task.GetAwaiter().GetResult())
                )
            except Exception as error:
                self.script_failed.emit(callback_id, str(error))
            finally:
                self._delegates.remove(delegate)

        delegate = Action(finish)
        self._delegates.append(delegate)
        task.GetAwaiter().OnCompleted(delegate)

    @Slot(int, str)
    def _finish_script(self, callback_id, result):
        callback = self._callbacks.pop(callback_id, None)
        if callback is not None:
            try:
                value = json.loads(result)
            except json.JSONDecodeError as error:
                self.error_occurred.emit(
                    f"WebView2 devolvió una respuesta JavaScript no válida: {error}"
                )
                return
            callback(value)

    @Slot(int, str)
    def _fail_script(self, callback_id, message):
        self._callbacks.pop(callback_id, None)
        self.error_occurred.emit(
            f"No se pudo ejecutar una función de la página en WebView2: {message}"
        )

    def close(self):
        self.stop()
        self.widget.hide()
        self.widget.setParent(None)
        self.widget.deleteLater()
        self._browser.Dispose()


ESTILO_OPERA_GX = """
    QMainWindow { 
        background-color: var(--theme-bg, #07080d); 
    }
    
    /* BARRA DE HERRAMIENTAS PRINCIPAL (TOP NAVIGATION) */
    QToolBar { 
        background-color: var(--theme-bg-bar, #0b0c16); 
        border-bottom: 1px solid #1a1d33; 
        padding: 6px 12px; 
        spacing: 8px; 
    }
    
    /* CONTENEDOR CENTRAL DE PESTAÑAS */
    QTabWidget::pane { 
        border: none; 
        background-color: var(--theme-bg, #07080d); 
    }
    
    /* BARRA DE PESTAÑAS */
    QTabBar {
        background-color: var(--theme-bg, #07080d);
        qproperty-drawBase: 0;
    }
    QTabBar::tab { 
        background: var(--theme-bg-btn, #0d0f1a); 
        color: #a3a9c2; 
        padding: 10px 20px; 
        border-top-left-radius: 8px; 
        border-top-right-radius: 8px;
        border: 1px solid #16192e;
        border-bottom: none;
        font-family: 'Segoe UI', -apple-system, sans-serif; 
        font-size: 12px; 
        font-weight: 500;
        margin-right: 4px;
        min-width: 120px;
    }
    QTabBar::tab:hover {
        background: var(--theme-bg-btn-hover, #121526);
        color: #ffffff;
    }
    QTabBar::tab:selected { 
        background: #16192e; 
        border-top: 2px solid var(--theme-color, #ff1e4a);
        color: var(--theme-color, #ff1e4a);
        font-weight: bold; 
    }
    
    /* BARRA DE DIRECCIONES NAVEGABLE */
    QLineEdit { 
        background-color: var(--theme-bg-btn-hover, #121526); 
        color: #ffffff; 
        border: 1px solid #222744; 
        padding: 8px 16px; 
        border-radius: 6px; 
        font-size: 13px; 
        font-family: 'Segoe UI', sans-serif;
    }
    QLineEdit:hover {
        border: 1px solid #333b66;
        background-color: #15192d;
    }
    QLineEdit:focus { 
        border: 1px solid var(--theme-color, #ff1e4a); 
        background-color: #181d35; 
    }
    
    /* BOTONES DE CONTROL DE NAVEGACIÓN GENERALES */
    QToolBar QPushButton { 
        background-color: var(--theme-bg-btn-hover, #121526); 
        color: #a3a9c2; 
        border: 1px solid #222744;
        padding: 4px 14px; 
        border-radius: 6px; 
        font-weight: bold; 
        font-family: 'Segoe UI', sans-serif;
        font-size: 13px;
    }
    QToolBar QPushButton:hover { 
        background-color: var(--theme-color, #ff1e4a); 
        color: #ffffff; 
        border: 1px solid var(--theme-color, #ff1e4a); 
    }
    
    /* CORRECCIÓN ESTRICTA PARA LOS SÍMBOLOS MAS Y MENOS DEL ZOOM */
    QPushButton[objectName="btn_zoom_toolbar"] {
        font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif;
        font-size: 11px;
        padding: 0px;
    }
    
    /* 🔴 BOTÓN "+" CIRCULAR CORREGIDO (No se vuelve cuadrado ni se tapa) */
    QPushButton[objectName="btn_nueva_tab_original"] {
        background-color: var(--theme-bg, #07080d);
        color: #a3a9c2;
        border: 1px solid #16192e;
        border-radius: 13px;
        font-weight: bold;
        font-size: 14px;
    }
    QPushButton[objectName="btn_nueva_tab_original"]:hover {
        background-color: var(--theme-bg-btn-hover, #121526);
        color: var(--theme-color, #ff1e4a);
        border: 1px solid var(--theme-color, #ff1e4a);
    }
    
    /* ENFOQUE ESPECIAL PARA EL BOTÓN "IR" */
    #btn_ir {
        background-color: var(--theme-color, #ff1e4a);
        color: #ffffff;
        border: 1px solid var(--theme-color, #ff1e4a);
    }
    #btn_ir:hover {
        background-color: var(--theme-hover, #ff3c61);
        border: 1px solid var(--theme-hover, #ff3c61);
    }
    
    /* BARRA LATERAL FLOTANTE AUTO-EXPANSIBLE */
    QWidget[objectName="barra_lateral"] {
        background-color: var(--theme-bg-bar, #0b0c16);
        border-right: 1px solid #1a1d33;
    }
    
    QPushButton[objectName="btn_lateral"] {
        background-color: transparent;
        border: 1px solid transparent;
        color: #646b8c;
        border-radius: 6px;
    }
    QPushButton[objectName="btn_lateral"]:hover {
        background-color: var(--theme-bg-btn-hover, #121526);
        color: var(--theme-color, #ff1e4a);
    }
    QPushButton[objectName="btn_lateral"]:checked {
        background-color: #16192e;
        color: var(--theme-color, #ff1e4a);
        border-left: 2px solid var(--theme-color, #ff1e4a);
    }
    
    /* BOTONES RÁPIDOS PERSONALIZABLES INFERIORES N1, N2, N3 */
    QPushButton[objectName="btn_rapido_personalizado"] {
        background-color: var(--theme-bg-btn-hover, #121526);
        color: #8e94b1;
        border: 1px solid #222744;
        font-size: 12px;
        font-weight: bold;
        border-radius: 6px;
    }
    QPushButton[objectName="btn_rapido_personalizado"]:hover {
        border: 1px solid var(--theme-color, #ff1e4a);
        color: var(--theme-color, #ff1e4a);
        background-color: #16192e;
    }
    
    /* CONTENEDOR DE PANELES LATERALES DESPLEGABLES */
    #panel_desplegable {
        background-color: var(--theme-bg-bar, #0b0c16);
    }
    #titulo_panel {
        color: #ffffff;
        font-family: 'Segoe UI', sans-serif;
        font-size: 16px;
        font-weight: bold;
        padding: 15px 10px 5px 10px;
        border-bottom: 1px solid #1a1d33;
    }
    #label_ajustes {
        color: #a3a9c2;
        font-family: 'Segoe UI', sans-serif;
        font-size: 12px;
    }
    QComboBox {
        background-color: var(--theme-bg-btn-hover, #121526);
        color: #ffffff;
        border: 1px solid #222744;
        padding: 5px;
        border-radius: 4px;
    }
    
    /* LISTAS NATIVAS PREMIUM (HISTORIAL Y DESCARGAS) */
    QListWidget {
        background-color: var(--theme-bg-bar, #0b0c16);
        border: none;
        color: #e3e6ed;
        font-family: 'Segoe UI', sans-serif;
        font-size: 12px;
        padding: 10px;
    }
    QListWidget::item {
        background-color: var(--theme-bg-btn-hover, #121526);
        border: 1px solid #222744;
        border-radius: 6px;
        padding: 8px;
        margin-bottom: 6px;
    }
    QListWidget::item:hover {
        border: 1px solid var(--theme-color, #ff1e4a);
        background-color: var(--theme-bg-btn-hover, #121526);
    }
    
    /* RE-ESTILIZADO DEL DIVISOR ARRASTRABLE (SPLITTER) */
    QSplitter::handle {
        background-color: #1a1d33;
    }
    QSplitter::handle:horizontal {
        width: 4px;
    }
    QSplitter::handle:horizontal:hover {
        background-color: var(--theme-color, #ff1e4a);
    }
"""


def crear_icono_script(ruta):
    ruta = Path(ruta)
    if ruta.suffix.lower() != ".svg":
        return QIcon(str(ruta))
    renderer = QSvgRenderer(QByteArray(scripts_web.read_sanitized_svg(ruta)))
    if not renderer.isValid():
        raise scripts_web.ScriptError(f"No se pudo mostrar el logo SVG «{ruta.name}».")
    size = renderer.defaultSize()
    if not size.isValid() or size.isEmpty():
        size = QSize(32, 32)
    size.scale(64, 64, Qt.AspectRatioMode.KeepAspectRatio)
    pixmap = QPixmap(size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    return QIcon(pixmap)


class BotonPersonalizadoMouse(QPushButton):
    """Clase especializada para capturar clicks izquierdos y derechos de manera aislada"""
    def __init__(self, texto, id_boton, callback_izq, callback_der, parent=None):
        super().__init__(parent)
        self.id_boton = id_boton
        self.callback_izq = callback_izq
        self.callback_der = callback_der
        self.texto_base = texto
        self.setObjectName("btn_rapido_personalizado")
        self.setFixedSize(44, 32)
        self.setText(texto)
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.RightButton:
            self.callback_der(self.id_boton)
        elif event.button() == Qt.MouseButton.LeftButton:
            self.callback_izq(self.id_boton)
        super().mousePressEvent(event)
class BarraLateralHover(QWidget):
    """Contenedor especializado para la barra lateral que detecta entrada/salida del mouse para expandirse sobre el contenido"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.navegador = parent
        self.setObjectName("barra_lateral")
        self.setMouseTracking(True)
    def enterEvent(self, event):
        if self.navegador:
            self.navegador.expandir_barra_lateral_hover()
        super().enterEvent(event)
    def leaveEvent(self, event):
        if self.navegador:
            self.navegador.retraer_barra_lateral_hover()
        super().leaveEvent(event)


class OperythonWebEnginePage(QWebEnginePage):
    console_message_received = Signal(str)

    def __init__(self, profile=None, parent=None, visor=None):
        if profile is None:
            super().__init__(parent)
        else:
            super().__init__(profile, parent)
        self._visor = visor

    def javaScriptConsoleMessage(self, level, message, line_number, source_id):
        prefix = "__OPERYTHON__"
        if message.startswith(prefix):
            self.console_message_received.emit(message[len(prefix):])
            return
        super().javaScriptConsoleMessage(level, message, line_number, source_id)

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        if is_main_frame and self._visor is not None:
            if not self._visor._aceptar_navegacion_qt(url):
                return False
        return super().acceptNavigationRequest(url, navigation_type, is_main_frame)


class VisorDePestana(QWidget):
    urlChanged = Signal(QUrl)
    titleChanged = Signal(str)
    loadFinished = Signal(bool)
    consoleMessageReceived = Signal(str)
    webview2Error = Signal(str)
    newWindowRequested = Signal(str)

    _MEDIA_FALLBACK_PROBE = r"""JSON.stringify((() => {
        const video = document.createElement('video');
        const h264 = video.canPlayType('video/mp4; codecs="avc1.42E01E"') !== '';
        const mseH264 = !!(window.MediaSource &&
            MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E"'));
        const videos = Array.from(document.querySelectorAll('video'));
        const text = (document.body?.innerText || '').slice(0, 50000);
        const offline = /\b(offline|isn't live|is not live|not currently live|currently offline|stream is offline|fuera de linea|fuera de línea|no esta en directo|no está en directo|no esta en vivo|no está en vivo|no esta transmitiendo|no está transmitiendo)\b/i.test(text);
        const playerError = /#?4000\b|playback error|error while playing|media source.*error|cannot play (this|the) video|unable to play/i.test(text);
        const mediaError = videos.some(item =>
            item.error && (item.error.code === 3 || item.error.code === 4));
        const hasVideoSource = videos.some(item =>
            item.currentSrc || item.src || item.srcObject ||
            (item.networkState === 3 && item.readyState === 0));
        const host = location.hostname.toLowerCase();
        const path = location.pathname.toLowerCase();
        const twitchLive = ['twitch.tv', 'www.twitch.tv'].includes(host) &&
            /^\/[^/]+\/?$/.test(path) &&
            !/^\/(directory|downloads|settings|subscriptions|videos|clip|clips|p|collections)\b/.test(path);
        const kickLive = host === 'kick.com' &&
            /^\/[^/]+\/?$/.test(path) &&
            !/^\/(categories|clips|videos|following|browse|search)\b/.test(path);
        const youtubeLive = ['youtube.com', 'www.youtube.com', 'm.youtube.com'].includes(host) &&
            (/^\/live\/[^/]+/.test(path) ||
             (/^\/watch$/.test(path) && /[?&]live=/.test(location.search)) ||
             /^\/@[^/]+\/live\/?$/.test(path));
        const otherLive = (host === 'tiktok.com' || host === 'www.tiktok.com') &&
            /^\/@[^/]+\/live\/?$/.test(path);
        const knownLive = twitchLive || kickLive || youtubeLive || otherLive;
        const unsupported = !h264 && !mseH264;
        const failed = mediaError ||
            (knownLive && hasVideoSource && (playerError || videos.length > 0));
        return {
            unsupported, hasVideo: videos.length > 0, knownLive,
            failed: failed && !offline, offline
        };
    })())"""

    def __init__(
        self, parent=None, navegador=None, url="about:blank", html=None,
        allow_webview2_fallback=True,
    ):
        super().__init__(parent)
        self._navegador = navegador
        self._webview2_zoom = 1.0
        self._webview2_muted = False
        self._initial_url = url
        self._webview2 = None
        self._webview2_closed = False
        self._webview2_visible = False
        self._fallback_target_url = ""
        self._allow_webview2_fallback = allow_webview2_fallback
        self._media_probe_attempts = 0
        self.id_startpage = html is not None
        if navegador is not None:
            self.webview2Error.connect(
                lambda message: navegador.mostrar_error_webview2(self, message)
            )
        self.newWindowRequested.connect(
            lambda target: navegador.crear_nueva_pestana(target)
            if navegador is not None
            else None
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self._qt_view = QWebEngineView(self)
        profile = navegador.perfil if navegador is not None else None
        self._qt_page = OperythonWebEnginePage(profile, self, self)
        self._qt_view.setPage(self._qt_page)
        self._qt_page.console_message_received.connect(
            self.consoleMessageReceived.emit
        )
        self._qt_page.newWindowRequested.connect(
            self._on_qt_new_window_requested
        )
        self._qt_view.urlChanged.connect(self.urlChanged.emit)
        self._qt_view.titleChanged.connect(self.titleChanged.emit)
        self._qt_view.loadFinished.connect(self._on_qt_load_finished)
        layout.addWidget(self._qt_view)
        self._media_probe_timer = QTimer(self)
        self._media_probe_timer.setInterval(900)
        self._media_probe_timer.timeout.connect(self._probe_media_fallback)
        if html is not None:
            self.setHtml(html)
        elif url:
            self._qt_view.load(QUrl(url))

    @staticmethod
    def _url_path_key(url):
        parsed = urlsplit(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]
        return host, parsed.path.rstrip("/").lower()

    def _aceptar_navegacion_qt(self, target):
        source = self.url().toString()
        destination = target.toString()
        try:
            if scripts_web.should_block_external_navigation(source, destination):
                print(f"Se bloqueó una navegación externa de Y2mate: {destination}")
                return False
        except scripts_web.ScriptError as error:
            print(f"No se pudo comprobar una redirección externa: {error}")
        if target.host().lower() != "operython":
            self.id_startpage = False
        self._initial_url = destination
        self._media_probe_attempts = 0
        self._media_probe_timer.stop()
        if self._navegador is not None:
            self._navegador.programar_guardado_pestanas()
        return True

    def _on_qt_new_window_requested(self, request):
        destination = request.requestedUrl().toString()
        if self._navegador is None:
            self.newWindowRequested.emit(destination)
            return
        try:
            if scripts_web.should_block_external_navigation(
                self.url().toString(), destination
            ):
                print(
                    "Se bloqueó una navegación externa de Y2mate: "
                    f"{destination}"
                )
                return
        except scripts_web.ScriptError as error:
            print(f"No se pudo comprobar una ventana nueva: {error}")
        visor = self._navegador.crear_nueva_pestana("about:blank")
        if visor is not None:
            request.openIn(visor._qt_page)

    def _on_qt_load_finished(self, success):
        self.loadFinished.emit(bool(success))
        if not success or not self._allow_webview2_fallback or self.id_startpage:
            return
        self._media_probe_attempts = 0
        self._media_probe_timer.start()
        QTimer.singleShot(0, self._probe_media_fallback)

    def _probe_media_fallback(self):
        if (
            not self._allow_webview2_fallback
            or self._webview2_visible
            or self._qt_view.url().scheme() not in {"http", "https"}
        ):
            self._media_probe_timer.stop()
            return
        self._media_probe_attempts += 1
        probed_url = self._qt_view.url().toString()

        def on_result(result):
            if (
                self._webview2_visible
                or probed_url != self._qt_view.url().toString()
            ):
                return
            try:
                report = json.loads(result) if isinstance(result, str) else result
            except json.JSONDecodeError as error:
                print(f"No se pudo interpretar la detección de video: {error}")
                report = None
            if not isinstance(report, dict):
                self._media_probe_timer.stop()
                return
            if report.get("unsupported") and report.get("failed"):
                self._media_probe_timer.stop()
                self._activar_fallback_webview2(probed_url)
                return
            should_retry = (
                report.get("unsupported")
                and not report.get("offline")
                and (report.get("hasVideo") or report.get("knownLive"))
                and self._media_probe_attempts < 18
            )
            if not should_retry:
                self._media_probe_timer.stop()

        self._qt_page.runJavaScript(self._MEDIA_FALLBACK_PROBE, on_result)

    def _activar_fallback_webview2(self, url):
        if not self._allow_webview2_fallback or self._webview2_closed:
            return
        self._fallback_target_url = url
        if self._webview2 is not None:
            self._mostrar_fallback_webview2(url)
            return
        _encolar_superficie_webview2(self)

    def _inicializar_webview2(self):
        if self._webview2_closed or self._webview2 is not None:
            return
        target_url = self._fallback_target_url or self._qt_view.url().toString()
        try:
            self._webview2 = WebView2Session(
                self,
                target_url,
                navegador=self._navegador,
            )
        except Exception as error:
            self.webview2Error.emit(str(error))
            _finalizar_inicializacion_webview2(self, False)
            return
        self._webview2.initialization_finished.connect(
            self._on_webview2_initialization_finished
        )
        self._webview2.url_changed.connect(
            lambda value: self.urlChanged.emit(QUrl(value))
        )
        self._webview2.navigation_started.connect(self._on_webview2_navigation_started)
        self._webview2.title_changed.connect(self.titleChanged.emit)
        self._webview2.load_finished.connect(self.loadFinished.emit)
        self._webview2.console_message_received.connect(
            self.consoleMessageReceived.emit
        )
        self._webview2.error_occurred.connect(self.webview2Error.emit)
        self._webview2.new_window_requested.connect(self.newWindowRequested.emit)
        self._webview2.set_zoom(self._webview2_zoom)
        self._webview2.set_muted(self._webview2_muted)
        self._webview2.widget.hide()
        self.layout().addWidget(self._webview2.widget)
        if self._webview2._initialization_completed:
            self._on_webview2_initialization_finished(
                self._webview2._initialization_succeeded
            )

    def _on_webview2_initialization_finished(self, success):
        _finalizar_inicializacion_webview2(self, success)
        if not success:
            return
        QTimer.singleShot(
            0,
            lambda: self._mostrar_fallback_webview2(self._fallback_target_url),
        )

    def _mostrar_fallback_webview2(self, url):
        if (
            self._webview2 is None
            or not self._webview2.is_ready
            or not self._fallback_target_url
        ):
            return
        target_url = url or self._fallback_target_url
        if self._url_path_key(self._webview2.url) != self._url_path_key(target_url):
            self._webview2.navigate(target_url)
        self._webview2_visible = True
        self._qt_page.setAudioMuted(True)
        self._webview2.set_muted(self._webview2_muted)
        self._qt_view.hide()
        self._webview2.widget.show()
        if self._navegador is not None:
            QTimer.singleShot(0, self._navegador.reponer_interfaz_sobre_webview)

    def _on_webview2_navigation_started(self, destination):
        self._initial_url = destination
        if self._url_path_key(destination) != self._url_path_key(
            self._fallback_target_url
        ):
            self._volver_a_qtwebengine(destination)

    def _volver_a_qtwebengine(self, destination):
        self._webview2_visible = False
        self._fallback_target_url = ""
        if self._webview2 is not None:
            self._webview2.set_muted(True)
        self._qt_page.setAudioMuted(self._webview2_muted)
        self._qt_view.show()
        self._qt_view.load(QUrl(destination))
        if self._webview2 is not None:
            self._webview2.widget.hide()

    def load(self, url):
        destination = url.toString() if isinstance(url, QUrl) else str(url)
        if destination.lower() in {
            "https://operython",
            "https://startpage",
            "https://operython/",
        }:
            self.id_startpage = True
            self.setHtml(
                self._navegador.generar_html_startpage()
                if self._navegador is not None
                else ""
            )
            return
        self.id_startpage = False
        self._initial_url = destination
        self._media_probe_timer.stop()
        self._fallback_target_url = ""
        self._webview2_visible = False
        self._qt_page.setAudioMuted(self._webview2_muted)
        if self._webview2 is not None:
            self._webview2.set_muted(True)
        self._qt_view.show()
        if self._webview2 is not None:
            self._webview2.widget.hide()
        self._qt_view.load(QUrl(destination))

    def url(self):
        if self._webview2_visible and self._webview2 is not None:
            return QUrl(self._webview2.url)
        if self.id_startpage:
            return QUrl("https://operython/")
        return self._qt_view.url()

    def title(self):
        if self._webview2_visible and self._webview2 is not None:
            return self._webview2.title
        return self._qt_view.title()

    def back(self):
        if self._webview2_visible and self._webview2 is not None:
            self._webview2.back()
        else:
            self._qt_view.back()

    def forward(self):
        if self._webview2_visible and self._webview2 is not None:
            self._webview2.forward()
        else:
            self._qt_view.forward()

    def reload(self):
        if self._webview2_visible and self._webview2 is not None:
            self._webview2.reload()
        else:
            self._qt_view.reload()

    def stop(self):
        if self._webview2_visible and self._webview2 is not None:
            self._webview2.stop()
        else:
            self._qt_view.stop()

    def setZoomFactor(self, factor):
        self._webview2_zoom = float(factor)
        self._qt_view.setZoomFactor(self._webview2_zoom)
        if self._webview2 is not None:
            self._webview2.set_zoom(self._webview2_zoom)

    def zoomFactor(self):
        if self._webview2_visible and self._webview2 is not None:
            return self._webview2.zoom()
        return self._qt_view.zoomFactor()

    def setAudioMuted(self, muted):
        self._webview2_muted = bool(muted)
        self._qt_page.setAudioMuted(
            True if self._webview2_visible else self._webview2_muted
        )
        if self._webview2 is not None:
            self._webview2.set_muted(
                self._webview2_muted if self._webview2_visible else True
            )

    def isAudioMuted(self):
        if self._webview2_visible and self._webview2 is not None:
            return self._webview2.is_muted()
        return self._qt_page.isAudioMuted()

    def runJavaScript(self, script, callback=None):
        if self._webview2_visible and self._webview2 is not None:
            self._webview2.execute_script(script, callback)
        elif callback is None:
            self._qt_page.runJavaScript(script)
        else:
            self._qt_page.runJavaScript(script, callback)

    def setHtml(self, html):
        self.id_startpage = True
        self._initial_url = "https://operython/"
        self._media_probe_timer.stop()
        self._fallback_target_url = ""
        self._webview2_visible = False
        self._qt_page.setAudioMuted(self._webview2_muted)
        if self._webview2 is not None:
            self._webview2.set_muted(True)
        self._qt_view.show()
        if self._webview2 is not None:
            self._webview2.widget.hide()
        self._qt_view.setHtml(html, QUrl("https://operython/"))

    def close_webview2(self):
        self._webview2_closed = True
        self._media_probe_timer.stop()
        self._qt_view.stop()
        if self._webview2 is not None:
            self._webview2.close()


class NavegadorOperython(QMainWindow):
    legacy_cookies_ready = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Operython GX")
        self.setGeometry(100, 100, 1280, 720)
        
        self.tableros = {
            "juegos": [],      
            "investigacion": [] 
        }
        self.indices_pestanas = {"juegos": 0, "investigacion": 0}
        self.tablero_actual = "juegos"
        self._reinicio_en_curso = False
        self.pestana_en_pantalla_completa = False
        self.estado_ventana_antes_pantalla_completa = None
        self.lista_historial_datos = []
        self.lista_descargas_datos = [] 
        self.adblock_general_activo = True
        self.adblock_excepciones_pagina = set()
        self.adblock_revision = 0
        
        self.urls_rapidas_inferiores = {"1": "https://google.com", "2": "https://youtube.com", "3": "https://github.com"}
        def interceptar_clicks_globales_fijo(objeto, evento):
            if evento.type() == QEvent.Type.MouseButtonPress:
                vol_clicks = getattr(self, "volumen_clicks_general", 40)
                if vol_clicks > 0:
                    import winsound
                    import time
                    
                    if not hasattr(self, "_ultimo_bip_tiempo"):
                        self._ultimo_bip_tiempo = 0.0
                        
                    tiempo_actual = time.time()
                    if tiempo_actual - self._ultimo_bip_tiempo > 0.1:
                        self._ultimo_bip_tiempo = tiempo_actual
                        winsound.Beep(450, 15)
                        
            return super(NavegadorOperython, self).eventFilter(objeto, evento)
        QApplication.instance().installEventFilter(self)
        self.eventFilter = interceptar_clicks_globales_fijo
        self.musica_reproducir = False
        self.ruta_musica_personalizada = ""
        
        self.buscador_predeterminado = "https://google.com"
        self.startpage_url = "https://google.com"
        self.color_tema = "#ff1e4a"
        self.color_hover = "#ff3c61"
        self.ancho_panel_guardado = 800
        self.modo_webgl = MODO_WEBGL
        self.cargar_todo_desde_json()
        paleta = PALETAS_COLOR[INDICES_COLOR.get(self.color_tema.lower(), 0)]
        (
            self.color_tema,
            self.color_hover,
            self.color_bg,
            self.color_bg_bar,
            self.color_bg_btn,
            self.color_bg_btn_hover,
        ) = paleta
        
        self.player_fondo = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.player_fondo.setAudioOutput(self.audio_output)
        self.player_fondo.setLoops(QMediaPlayer.Loops.Infinite)
        self.audio_output.setVolume(0.4)
        
        self.perfil = QWebEngineProfile("OperythonPerfilUniversal", self)
        self.perfil.setPersistentStoragePath(str(RUTA_SISTEMA / "Almacenamiento"))
        self._legacy_cookies = []
        self._legacy_cookies_loaded = False
        self._legacy_cookies_imported = (
            USER_DATA_ROOT / "qt_cookies_imported"
        ).is_file()
        self._legacy_cookie_timer = QTimer(self)
        self._legacy_cookie_timer.setSingleShot(True)
        self._legacy_cookie_timer.setInterval(800)
        self._legacy_cookie_timer.timeout.connect(
            self.finalizar_importacion_cookies
        )
        self.perfil.cookieStore().cookieAdded.connect(
            self.registrar_cookie_legacy
        )
        self.perfil.cookieStore().loadAllCookies()
        self._legacy_cookie_timer.start()
        self._favicon_manager = QNetworkAccessManager(self)
        
        self.actualizar_hoja_estilos()
        self.inicializar_estado_musica_fondo()
        self.contenedor_principal_maestro = QWidget()
        self.setCentralWidget(self.contenedor_principal_maestro)
        
        layout_maestro = QHBoxLayout(self.contenedor_principal_maestro)
        layout_maestro.setContentsMargins(0, 0, 0, 0)
        layout_maestro.setSpacing(0)
        self.espacio_reservado_sidebar = QWidget()
        self.espacio_reservado_sidebar.setFixedWidth(52)
        layout_maestro.addWidget(self.espacio_reservado_sidebar)
        self.barra_lateral = BarraLateralHover(self)
        self.barra_lateral.setFixedWidth(52)
        
        layout_lateral = QVBoxLayout(self.barra_lateral)
        layout_lateral.setContentsMargins(4, 8, 4, 8)
        layout_lateral.setSpacing(5)
        layout_lateral.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.btn_juegos = QPushButton("🕹️")
        self.btn_investigacion = QPushButton("🔬") 
        self.btn_chat = QPushButton("💬")
        self.btn_musica = QPushButton("🎵")
        self.btn_historial = QPushButton("📜") 
        self.btn_descargas = QPushButton("📥") 
        self.btn_scripts = QPushButton("🧩")
        self.btn_adblock = QPushButton("🛡️")
        self.btn_ajustes = QPushButton("⚙️")
        self.mapeo_nombres_botones = {
            self.btn_juegos: ("🕹️", " Juegos"),
            self.btn_investigacion: ("🔬", " Investigación"),
            self.btn_chat: ("💬", " Discord Chat"),
            self.btn_musica: ("🎵", " Spotify Player"),
            self.btn_historial: ("📜", " Historial"),
            self.btn_descargas: ("📥", " Descargas"),
            self.btn_scripts: ("🧩", " Scripts web"),
            self.btn_adblock: ("🛡️", " Adblock"),
            self.btn_ajustes: ("⚙️", " Ajustes")
        }
        for btn in self.mapeo_nombres_botones.keys():
            btn.setObjectName("btn_lateral")
            btn.setCheckable(True)
            btn.setFixedSize(44, 36)
            btn.setStyleSheet("font-family: 'Segoe UI Emoji', 'Segoe UI', sans-serif; font-size: 15px;")
        self.btn_juegos.setChecked(True) 
        self.btn_juegos.clicked.connect(lambda: self.conmutar_tablero("juegos"))
        self.btn_investigacion.clicked.connect(lambda: self.conmutar_tablero("investigacion"))
        self.btn_chat.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("chat"))
        self.btn_musica.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("musica"))
        self.btn_historial.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("historial"))
        self.btn_descargas.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("descargas"))
        self.btn_scripts.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("scripts"))
        self.btn_adblock.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("adblock"))
        self.btn_ajustes.clicked.connect(lambda: self.controlar_panel_lateral_desplegable("ajustes"))
        layout_lateral.addWidget(self.btn_juegos)
        layout_lateral.addWidget(self.btn_investigacion)
        layout_lateral.addWidget(self.btn_chat)
        layout_lateral.addWidget(self.btn_musica)
        layout_lateral.addWidget(self.btn_historial)
        layout_lateral.addWidget(self.btn_descargas)
        layout_lateral.addWidget(self.btn_scripts)
        layout_lateral.addWidget(self.btn_adblock)
        layout_lateral.addWidget(self.btn_ajustes)
        
        layout_lateral.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))
        
        self.btn_audio_ambiente = BotonPersonalizadoMouse("🔇", "bg_audio", self.ejecutar_click_izquierdo_ambiente, self.ejecutar_click_derecho_ambiente)
        layout_lateral.addWidget(self.btn_audio_ambiente)
        self.btn_rapido1 = BotonPersonalizadoMouse("N1", "1", self.ejecutar_click_izquierdo_rapido, self.ejecutar_click_derecho_configurar)
        self.btn_rapido2 = BotonPersonalizadoMouse("N2", "2", self.ejecutar_click_izquierdo_rapido, self.ejecutar_click_derecho_configurar)
        self.btn_rapido3 = BotonPersonalizadoMouse("N3", "3", self.ejecutar_click_izquierdo_rapido, self.ejecutar_click_derecho_configurar)
        
        layout_lateral.addWidget(self.btn_rapido1)
        layout_lateral.addWidget(self.btn_rapido2)
        layout_lateral.addWidget(self.btn_rapido3)
        self.splitter_principal = QSplitter(Qt.Orientation.Horizontal)
        self.splitter_principal.setHandleWidth(4)
        layout_maestro.addWidget(self.splitter_principal)
        self.panel_desplegable = QWidget()
        self.panel_desplegable.setMinimumWidth(0)
        self.panel_desplegable.setObjectName("panel_desplegable")
        
        layout_interno_panel = QVBoxLayout(self.panel_desplegable)
        layout_interno_panel.setContentsMargins(0, 0, 0, 0)
        layout_interno_panel.setSpacing(0)
        self.titulo_panel = QLabel("Panel")
        self.titulo_panel.setObjectName("titulo_panel")
        layout_interno_panel.addWidget(self.titulo_panel)
        self.sub_paneles = QStackedWidget()
        layout_interno_panel.addWidget(self.sub_paneles)
        self.web_chat = VisorDePestana(
            navegador=self,
            url="https://discord.com",
            allow_webview2_fallback=False,
        )
        self.web_chat.loadFinished.connect(
            lambda: self.aplicar_scripts_web(self.web_chat, actualizar_estado=False)
        )
        self.sub_paneles.addWidget(self.web_chat)
        self.web_musica = VisorDePestana(
            navegador=self,
            url="https://spotify.com",
            allow_webview2_fallback=False,
        )
        self.web_musica.loadFinished.connect(
            lambda: self.aplicar_scripts_web(self.web_musica, actualizar_estado=False)
        )
        self.sub_paneles.addWidget(self.web_musica)
        self.panel_contenedor_historial = QWidget()
        layout_vertical_historial = QVBoxLayout(self.panel_contenedor_historial)
        layout_vertical_historial.setContentsMargins(0, 0, 0, 0)
        
        self.widget_lista_historial = QListWidget()
        self.widget_lista_historial.itemClicked.connect(self.hacer_clic_en_item_historial)
        
        self.btn_borrar_historial_sospechoso = QPushButton("💥 Eliminar historial")
        self.btn_borrar_historial_sospechoso.clicked.connect(self.destruir_historial_completo)
        
        layout_vertical_historial.addWidget(self.widget_lista_historial)
        layout_vertical_historial.addWidget(self.btn_borrar_historial_sospechoso)
        self.sub_paneles.addWidget(self.panel_contenedor_historial)
        self.panel_contenedor_descargas = QWidget()
        layout_vertical_descargas = QVBoxLayout(self.panel_contenedor_descargas)
        layout_vertical_descargas.setContentsMargins(0, 0, 0, 0)
        self.widget_lista_descargas = QListWidget()
        self.btn_borrar_descargas_locales = QPushButton("🗑️ Limpiar historial de descargas")
        self.btn_borrar_descargas_locales.clicked.connect(self.destruir_descargas_completo)
        layout_vertical_descargas.addWidget(self.widget_lista_descargas)
        layout_vertical_descargas.addWidget(self.btn_borrar_descargas_locales)
        self.sub_paneles.addWidget(self.panel_contenedor_descargas)
        self.panel_config = QWidget()
        layout_form = QFormLayout(self.panel_config)
        layout_form.setContentsMargins(15, 15, 15, 15)
        lbl_vol_musica = QLabel("Volumen Música:")
        lbl_vol_musica.setObjectName("label_ajustes")
        self.slider_vol_musica = QSlider(Qt.Orientation.Horizontal)
        self.slider_vol_musica.setRange(0, 100)
        self.slider_vol_musica.setValue(int(self.audio_output.volume() * 100))
        self.slider_vol_musica.valueChanged.connect(self.cambiar_volumen_musica_fondo)
        lbl_vol_sonidos = QLabel("Sonidos Interfaz:")
        lbl_vol_sonidos.setObjectName("label_ajustes")
        self.slider_vol_sonidos = QSlider(Qt.Orientation.Horizontal)
        self.slider_vol_sonidos.setRange(0, 100)
        self.slider_vol_sonidos.setValue(getattr(self, "volumen_sonidos", 40))
        self.slider_vol_sonidos.valueChanged.connect(self.cambiar_volumen_efectos_interfaz)
        lbl_vol_general = QLabel("Sonido Clicks:")
        lbl_vol_general.setObjectName("label_ajustes")
        self.slider_vol_general = QSlider(Qt.Orientation.Horizontal)
        self.slider_vol_general.setRange(0, 100)
        self.slider_vol_general.setValue(getattr(self, "volumen_clicks_general", 40))
        self.slider_vol_general.valueChanged.connect(self.cambiar_volumen_clicks_general)
        layout_form.addRow(lbl_vol_musica, self.slider_vol_musica)
        layout_form.addRow(lbl_vol_sonidos, self.slider_vol_sonidos)
        layout_form.addRow(lbl_vol_general, self.slider_vol_general)
        lbl_buscar = QLabel("Buscador:")
        lbl_buscar.setObjectName("label_ajustes")
        self.combo_buscar = QComboBox()
        self.combo_buscar.addItems(["Google", "Bing", "DuckDuckGo", "Brave"])
        if "://brave.com" in self.buscador_predeterminado: self.combo_buscar.setCurrentIndex(3)
        if "bing.com" in self.buscador_predeterminado: self.combo_buscar.setCurrentIndex(1)
        elif "duckduckgo.com" in self.buscador_predeterminado: self.combo_buscar.setCurrentIndex(2)
        self.combo_buscar.currentIndexChanged.connect(self.cambiar_motor_busqueda)
        lbl_webgl = QLabel("Renderizado WebGL:")
        lbl_webgl.setObjectName("label_ajustes")
        self.combo_webgl = QComboBox()
        self.combo_webgl.addItem("GPU (más rápido, recomendado)", "gpu")
        self.combo_webgl.addItem("SwiftShader (CPU, compatibilidad)", "swiftshader")
        self.combo_webgl.setCurrentIndex(self.combo_webgl.findData(self.modo_webgl))
        self.combo_webgl.currentIndexChanged.connect(self.cambiar_modo_webgl)
        self.lbl_estado_webgl = QLabel(
            "Afecta Qt WebEngine y el respaldo WebView2. "
            "Reinicia Operython para aplicar el cambio."
        )
        self.lbl_estado_webgl.setObjectName("label_ajustes")
        self.lbl_estado_webgl.setWordWrap(True)
        layout_form.addRow(lbl_webgl, self.combo_webgl)
        layout_form.addRow(self.lbl_estado_webgl)
        lbl_color = QLabel("Color de Acento:")
        lbl_color.setObjectName("label_ajustes")
        self.combo_color = QComboBox()
        self.combo_color.addItems(["Color Predeterminado (Verde código)", "Rojo gamer", "Azul Ciano", "Morado Eléctrico", "Amarillo Neón", "Negro Profundo", "Blanco Premium", "Gris Claro", "Marrón Elegante"])
        self.combo_color.setCurrentIndex(
            INDICES_COLOR.get(self.color_tema.lower(), 0)
        )
        self.combo_color.currentIndexChanged.connect(self.cambiar_color_interfaz)
        lbl_startpage = QLabel("Página de Inicio:")
        lbl_startpage.setObjectName("label_ajustes")
        self.line_edit_startpage = QLineEdit()
        self.line_edit_startpage.setText(self.startpage_url)
        self.line_edit_startpage.setPlaceholderText("Ej: https://google.com")
        self.line_edit_startpage.editingFinished.connect(self.cambiar_url_startpage)
        lbl_fondo_sp = QLabel("Fondo de Startpage:")
        lbl_fondo_sp.setObjectName("label_ajustes")
        self.btn_seleccionar_fondo_sp = QPushButton("🌌 Seleccionar Imagen")
        self.btn_seleccionar_fondo_sp.clicked.connect(self.ejecutar_cambio_fondo_startpage)
        layout_form.addRow(lbl_fondo_sp, self.btn_seleccionar_fondo_sp)
        layout_form.addRow(lbl_buscar, self.combo_buscar)
        layout_form.addRow(lbl_color, self.combo_color)
        layout_form.addRow(lbl_startpage, self.line_edit_startpage)
        self.sub_paneles.addWidget(self.panel_config)
        self.panel_scripts = QWidget()
        layout_scripts = QVBoxLayout(self.panel_scripts)
        layout_scripts.setContentsMargins(12, 12, 12, 12)
        layout_scripts.setSpacing(8)
        self.lbl_ayuda_scripts = QLabel(
            "Cada script vive en su propia carpeta, junto a assets. Puedes importar "
            "un TXT con sus recursos al lado o descomprimir una carpeta de script "
            "directamente en scripts_web. Logotipe: enabled muestra "
            "logo.png, logo.jpg, logo.jpeg o logo.svg junto al nombre. Solo se aplican "
            "en sus dominios declarados; no ejecutan Python ni JavaScript arbitrario. "
            "Abre «Descripción» o haz doble clic en un script para ver y configurar "
            "sus funciones. Actualizar recarga las páginas abiertas."
        )
        self.lbl_ayuda_scripts.setObjectName("label_ajustes")
        self.lbl_ayuda_scripts.setWordWrap(True)
        layout_scripts.addWidget(self.lbl_ayuda_scripts)
        self.lbl_estado_scripts = QLabel("No se ejecutan scripts sin importarlos y confirmarlos.")
        self.lbl_estado_scripts.setObjectName("label_ajustes")
        self.lbl_estado_scripts.setWordWrap(True)
        self.lbl_estado_scripts.setMinimumWidth(0)
        self.lbl_estado_scripts.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        layout_scripts.addWidget(self.lbl_estado_scripts)
        self.btn_importar_script = QPushButton("📄 Importar script .txt")
        self.btn_importar_script.clicked.connect(self.importar_script_web)
        layout_scripts.addWidget(self.btn_importar_script)
        self.btn_editor_script = QPushButton("✏️ Crear / editar script")
        self.btn_editor_script.clicked.connect(self.abrir_editor_scripts)
        layout_scripts.addWidget(self.btn_editor_script)
        self.btn_descripcion_script = QPushButton("ℹ️ Descripción")
        self.btn_descripcion_script.clicked.connect(
            self.mostrar_descripcion_script_web
        )
        layout_scripts.addWidget(self.btn_descripcion_script)
        self.lista_scripts = QListWidget()
        self.lista_scripts.setIconSize(QSize(24, 24))
        self.lista_scripts.itemDoubleClicked.connect(
            self.mostrar_funciones_script_web
        )
        layout_scripts.addWidget(self.lista_scripts)
        self.btn_toggle_script = QPushButton("Activar / desactivar")
        self.btn_toggle_script.clicked.connect(self.alternar_script_web)
        self.btn_quitar_script = QPushButton("🗑️ Quitar seleccionado")
        self.btn_quitar_script.clicked.connect(self.quitar_script_web)
        self.btn_actualizar_scripts = QPushButton("🔄 Actualizar lista y páginas")
        self.btn_actualizar_scripts.clicked.connect(self.actualizar_lista_scripts)
        layout_scripts.addWidget(self.btn_toggle_script)
        layout_scripts.addWidget(self.btn_quitar_script)
        layout_scripts.addWidget(self.btn_actualizar_scripts)
        self.sub_paneles.addWidget(self.panel_scripts)
        self.panel_adblock = QWidget()
        layout_adblock = QVBoxLayout(self.panel_adblock)
        layout_adblock.setContentsMargins(12, 12, 12, 12)
        layout_adblock.setSpacing(8)
        self.lbl_adblock_pagina = QLabel("Página actual: sin página web")
        self.lbl_adblock_pagina.setObjectName("label_ajustes")
        self.lbl_adblock_pagina.setWordWrap(True)
        self.lbl_adblock_pagina.setMinimumWidth(0)
        self.lbl_adblock_pagina.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        self.lbl_adblock_pagina.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        layout_adblock.addWidget(self.lbl_adblock_pagina)
        self.lbl_adblock_ayuda = QLabel(
            "La excepción permite anuncios en el sitio actual. El estado general "
            "se conserva hasta que vuelvas a activarlo."
        )
        self.lbl_adblock_ayuda.setObjectName("label_ajustes")
        self.lbl_adblock_ayuda.setWordWrap(True)
        layout_adblock.addWidget(self.lbl_adblock_ayuda)
        self.btn_adblock_excepcion = QPushButton()
        self.btn_adblock_excepcion.setCheckable(True)
        self.btn_adblock_excepcion.clicked.connect(
            self.alternar_excepcion_adblock_pagina
        )
        layout_adblock.addWidget(self.btn_adblock_excepcion)
        self.btn_adblock_general = QPushButton()
        self.btn_adblock_general.setCheckable(True)
        self.btn_adblock_general.clicked.connect(self.alternar_adblock_general)
        layout_adblock.addWidget(self.btn_adblock_general)
        self.lbl_adblock_resumen = QLabel("Anuncios bloqueados: 0")
        self.lbl_adblock_resumen.setObjectName("label_ajustes")
        layout_adblock.addWidget(self.lbl_adblock_resumen)
        self.lista_adblock_elementos = QListWidget()
        layout_adblock.addWidget(self.lista_adblock_elementos)
        self.sub_paneles.addWidget(self.panel_adblock)
        self.actualizar_lista_scripts()
        self.contenedor_derecho = QWidget()
        self.contenedor_derecho.setMinimumWidth(0)
        layout_derecho = QVBoxLayout(self.contenedor_derecho)
        layout_derecho.setContentsMargins(0, 0, 0, 0)
        layout_derecho.setSpacing(0)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.tabCloseRequested.connect(self.cerrar_pestana)
        self.tabs.currentChanged.connect(self.cambio_de_pestana)
        self.tabs.currentChanged.connect(self.actualizar_panel_adblock)
        self.tabs.currentChanged.connect(self.programar_guardado_pestanas)
        self.tabs.tabBar().tabMoved.connect(self.programar_guardado_pestanas)
        self.timer_guardado_pestanas = QTimer(self)
        self.timer_guardado_pestanas.setSingleShot(True)
        self.timer_guardado_pestanas.setInterval(500)
        self.timer_guardado_pestanas.timeout.connect(self.guardar_todo_en_json)
        self.timer_adblock = QTimer(self)
        self.timer_adblock.setInterval(1200)
        self.timer_adblock.timeout.connect(self.actualizar_panel_adblock)
        contenedor_cruz = QWidget()
        contenedor_cruz.setFixedSize(44, 34) 
        contenedor_cruz.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        layout_cruz = QHBoxLayout(contenedor_cruz)
        layout_cruz.setContentsMargins(6, 4, 6, 4)
        layout_cruz.setSpacing(0)
        self.btn_nueva_tab = QPushButton(" ➕")
        self.btn_nueva_tab.setObjectName("btn_nueva_tab_original")
        self.btn_nueva_tab.setFixedSize(26, 26)
        self.btn_nueva_tab.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_nueva_tab.setStyleSheet("padding-bottom: 3px;")
        
        self.btn_nueva_tab.clicked.connect(lambda: self.crear_nueva_pestana(self.startpage_url))
        
        layout_cruz.addWidget(self.btn_nueva_tab)
        
        self.tabs.setCornerWidget(contenedor_cruz, Qt.Corner.TopLeftCorner)
        self.widget_nueva_tab_corner = contenedor_cruz
        self.toolbar = QToolBar("Navegación")
        self.toolbar.setMovable(False)
        self.addToolBar(self.toolbar)
        self.atajo_salir_pantalla_completa = QShortcut(QKeySequence("Escape"), self)
        self.atajo_salir_pantalla_completa.setContext(Qt.ShortcutContext.WindowShortcut)
        self.atajo_salir_pantalla_completa.setEnabled(False)
        self.atajo_salir_pantalla_completa.activated.connect(
            lambda: self.alternar_pantalla_completa_pestana()
            if self.pestana_en_pantalla_completa else None
        )
        self.atajo_pantalla_completa = QShortcut(QKeySequence("F11"), self)
        self.atajo_pantalla_completa.setContext(Qt.ShortcutContext.WindowShortcut)
        self.atajo_pantalla_completa.activated.connect(
            self.alternar_pantalla_completa_pestana
        )
        self.atajo_recargar = QShortcut(QKeySequence("F5"), self)
        self.atajo_recargar.setContext(Qt.ShortcutContext.WindowShortcut)
        self.atajo_recargar.activated.connect(self.recargar_pestana_actual)
        self.atajo_nueva_pestana = QShortcut(QKeySequence("Ctrl+T"), self)
        self.atajo_nueva_pestana.setContext(Qt.ShortcutContext.WindowShortcut)
        self.atajo_nueva_pestana.activated.connect(
            lambda: self.crear_nueva_pestana(self.startpage_url)
        )
        self.atajo_cerrar_pestana = QShortcut(QKeySequence("Ctrl+W"), self)
        self.atajo_cerrar_pestana.setContext(Qt.ShortcutContext.WindowShortcut)
        self.atajo_cerrar_pestana.activated.connect(self.cerrar_pestana_actual)
        self.atajos_pestanas = []
        for numero in range(1, 10):
            atajo = QShortcut(QKeySequence(f"Ctrl+{numero}"), self)
            atajo.setContext(Qt.ShortcutContext.WindowShortcut)
            atajo.activated.connect(
                lambda numero=numero: self.seleccionar_pestana_atajo(numero)
            )
            self.atajos_pestanas.append(atajo)
        self.atajos_rapidos = []
        for numero in range(1, 4):
            atajo = QShortcut(QKeySequence(f"Alt+{numero}"), self)
            atajo.setContext(Qt.ShortcutContext.WindowShortcut)
            atajo.activated.connect(
                lambda numero=numero: self.ejecutar_click_izquierdo_rapido(
                    str(numero)
                )
            )
            self.atajos_rapidos.append(atajo)
        self.btn_atras = QPushButton("⬅")
        self.btn_atras.clicked.connect(lambda: self.tabs.currentWidget().back() if self.tabs.currentWidget() else None)
        self.toolbar.addWidget(self.btn_atras)
        self.btn_adelante = QPushButton("➡")
        self.btn_adelante.clicked.connect(lambda: self.tabs.currentWidget().forward() if self.tabs.currentWidget() else None)
        self.toolbar.addWidget(self.btn_adelante)
        self.btn_recargar = QPushButton("🔄")
        self.btn_recargar.clicked.connect(lambda: self.tabs.currentWidget().reload() if self.tabs.currentWidget() else None)
        self.toolbar.addWidget(self.btn_recargar)
        self.btn_reinicio_maestro = QPushButton("⚡")
        self.btn_reinicio_maestro.setToolTip("Reiniciar Operython por completo")
        self.btn_reinicio_maestro.clicked.connect(self.ejecutar_reinicio_completo_sistema)
        self.toolbar.addWidget(self.btn_reinicio_maestro)
        self.widget_control_zoom = QWidget()
        layout_zoom_bar = QHBoxLayout(self.widget_control_zoom)
        layout_zoom_bar.setContentsMargins(4, 0, 4, 0)
        layout_zoom_bar.setSpacing(2)
        self.btn_toolbar_zoom_mas = QPushButton("➕")
        self.btn_toolbar_zoom_mas.setObjectName("btn_zoom_toolbar")
        self.btn_toolbar_zoom_mas.setFixedSize(26, 26)
        self.btn_toolbar_zoom_mas.clicked.connect(lambda: self.ejecutar_zoom_mas(None))
        self.lbl_toolbar_zoom_valor = QLabel("100%")
        self.lbl_toolbar_zoom_valor.setFixedSize(42, 26)
        self.lbl_toolbar_zoom_valor.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_toolbar_zoom_valor.setStyleSheet("color: #ffffff; font-weight: bold; background: #121526; border: 1px solid #222744; border-radius: 4px; font-size: 11px;")
        self.btn_toolbar_zoom_menos = QPushButton("➖")
        self.btn_toolbar_zoom_menos.setObjectName("btn_zoom_toolbar")
        self.btn_toolbar_zoom_menos.setFixedSize(26, 26)
        self.btn_toolbar_zoom_menos.clicked.connect(lambda: self.ejecutar_zoom_menos(None))
        layout_zoom_bar.addWidget(self.btn_toolbar_zoom_mas)
        layout_zoom_bar.addWidget(self.lbl_toolbar_zoom_valor)
        layout_zoom_bar.addWidget(self.btn_toolbar_zoom_menos)
        
        self.toolbar.addWidget(self.widget_control_zoom)
        self.barra_url = QLineEdit()
        self.barra_url.setPlaceholderText("Busca o escribe una dirección web aquí...")
        self.barra_url.returnPressed.connect(self.navegar_a_url)
        self.toolbar.addWidget(self.barra_url)
        self.btn_abrir_archivo = QPushButton("💾")
        self.btn_abrir_archivo.setToolTip("Abrir archivo local")
        self.btn_abrir_archivo.clicked.connect(self.abrir_archivo_local)
        self.toolbar.addWidget(self.btn_abrir_archivo)
        self.btn_ir = QPushButton("Ir")
        self.btn_ir.setObjectName("btn_ir")
        self.btn_ir.clicked.connect(self.navegar_a_url)
        self.toolbar.addWidget(self.btn_ir)
        self.btn_pantalla_completa = QPushButton("⛶")
        self.btn_pantalla_completa.setToolTip(
            "Mostrar la pestaña actual a pantalla completa (Esc para salir)"
        )
        self.btn_pantalla_completa.clicked.connect(
            self.alternar_pantalla_completa_pestana
        )
        self.toolbar.addWidget(self.btn_pantalla_completa)
        layout_derecho.addWidget(self.tabs)
        self.splitter_principal.addWidget(self.panel_desplegable)
        self.splitter_principal.addWidget(self.contenedor_derecho)
        self.splitter_principal.setStretchFactor(0, 0)
        self.splitter_principal.setStretchFactor(1, 1)
        
        self._establecer_tamanos_splitter(0)
        self.splitter_principal.splitterMoved.connect(self.detectar_redimensionado_manual)
        self.splitter_principal.splitterMoved.connect(
            self.programar_reajuste_pagina_web
        )
        self.timer_reajuste_pagina_web = QTimer(self)
        self.timer_reajuste_pagina_web.setSingleShot(True)
        self.timer_reajuste_pagina_web.setInterval(100)
        self.timer_reajuste_pagina_web.timeout.connect(
            self.reajustar_pagina_web
        )
        self.barra_lateral.setParent(self.contenedor_principal_maestro)
        self.barra_lateral.setAttribute(
            Qt.WidgetAttribute.WA_NativeWindow, True
        )
        self.barra_lateral.winId()
        self.barra_lateral.raise_()
        self.cargar_todo_desde_json()
        if self.tabs.count() == 0:
            self.renderizar_pestanas_del_tablero_actual()
        self.actualizar_vista_lista_historial()
        self.actualizar_vista_lista_descargas()
        self.actualizar_iconos_atajos_inferiores()
    def registrar_cookie_legacy(self, cookie):
        if self._legacy_cookies_loaded:
            return
        if not cookie.name() or not cookie.domain():
            return
        try:
            name = bytes(cookie.name()).decode("utf-8")
            value = bytes(cookie.value()).decode("utf-8")
        except UnicodeDecodeError as error:
            print(f"Se omitió una cookie Qt que no se pudo convertir a texto: {error}")
            return
        expires = (
            0
            if cookie.isSessionCookie()
            else int(cookie.expirationDate().toSecsSinceEpoch())
        )
        data = {
            "name": name,
            "value": value,
            "domain": cookie.domain(),
            "path": cookie.path() or "/",
            "http_only": cookie.isHttpOnly(),
            "secure": cookie.isSecure(),
            "expires": expires,
        }
        key = (data["name"], data["domain"], data["path"])
        for index, existing in enumerate(self._legacy_cookies):
            existing_key = (
                existing["name"],
                existing["domain"],
                existing["path"],
            )
            if existing_key == key:
                self._legacy_cookies[index] = data
                break
        else:
            self._legacy_cookies.append(data)
        self._legacy_cookie_timer.start()

    def finalizar_importacion_cookies(self):
        if self._legacy_cookies_loaded:
            return
        self._legacy_cookies_loaded = True
        self.legacy_cookies_ready.emit()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.barra_lateral.setFixedHeight(self.contenedor_principal_maestro.height())
        self.barra_lateral.move(0, 0)
        QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
        self.programar_reajuste_pagina_web()

    def reponer_interfaz_sobre_webview(self):
        widgets = (
            getattr(self, "toolbar", None),
            getattr(self, "tabs", None).tabBar()
            if getattr(self, "tabs", None)
            else None,
            getattr(self, "widget_nueva_tab_corner", None),
            getattr(self, "barra_lateral", None),
        )
        for widget in widgets:
            if widget is not None and widget.isVisible():
                widget.raise_()
    def programar_guardado_pestanas(self, *_):
        timer = getattr(self, "timer_guardado_pestanas", None)
        if timer is not None:
            timer.start()

    def capturar_urls_pestanas(self):
        urls = []
        for index in range(self.tabs.count()):
            visor = self.tabs.widget(index)
            if visor is None:
                continue
            if getattr(visor, "id_startpage", False):
                urls.append("https://operython")
                continue
            url = self.formatear_url(visor.url())
            if url in {"", "about:blank"}:
                initial_url = getattr(visor, "_initial_url", "")
                if initial_url and initial_url != "about:blank":
                    url = initial_url
            if url.startswith("data:text/html") or url.rstrip("/").lower() in {
                "https://operython",
                "https://startpage",
            }:
                url = "https://operython"
            urls.append(url)
        return urls

    def alternar_pantalla_completa_pestana(self):
        if not self.pestana_en_pantalla_completa:
            self.estado_ventana_antes_pantalla_completa = {
                "maximizada": self.isMaximized(),
                "ancho_sidebar": self.espacio_reservado_sidebar.width(),
                "sidebar_visible": self.barra_lateral.isVisible(),
                "toolbar_visible": self.toolbar.isVisible(),
                "tabbar_visible": self.tabs.tabBar().isVisible(),
                "corner_visible": self.widget_nueva_tab_corner.isVisible(),
                "splitter_sizes": self.splitter_principal.sizes(),
            }
            self.pestana_en_pantalla_completa = True
            self.atajo_salir_pantalla_completa.setEnabled(True)
            self.toolbar.hide()
            self.tabs.tabBar().hide()
            self.widget_nueva_tab_corner.hide()
            self.espacio_reservado_sidebar.setFixedWidth(0)
            self.barra_lateral.hide()
            self._establecer_tamanos_splitter(0)
            self.btn_pantalla_completa.setToolTip(
                "Salir de pantalla completa (Esc o F11)"
            )
            self.showFullScreen()
            visor = self.tabs.currentWidget()
            if visor:
                visor.setFocus()
            return

        estado = self.estado_ventana_antes_pantalla_completa or {}
        self.pestana_en_pantalla_completa = False
        self.atajo_salir_pantalla_completa.setEnabled(False)
        self.toolbar.setVisible(estado.get("toolbar_visible", True))
        self.tabs.tabBar().setVisible(estado.get("tabbar_visible", True))
        self.widget_nueva_tab_corner.setVisible(estado.get("corner_visible", True))
        self.espacio_reservado_sidebar.setFixedWidth(
            estado.get("ancho_sidebar", 52)
        )
        self.barra_lateral.setVisible(estado.get("sidebar_visible", True))
        self.btn_pantalla_completa.setToolTip(
            "Mostrar la pestaña actual a pantalla completa (Esc para salir)"
        )
        if estado.get("maximizada"):
            self.showMaximized()
        else:
            self.showNormal()
        tamaños = estado.get("splitter_sizes")
        if tamaños:
            QTimer.singleShot(
                0, lambda: self._restaurar_tamanos_splitter(tamaños)
            )
        self.estado_ventana_antes_pantalla_completa = None

    def _establecer_tamanos_splitter(self, ancho_panel):
        ancho_total = self.splitter_principal.width()
        ancho_panel = max(0, min(int(ancho_panel), ancho_total))
        self.panel_desplegable.setMaximumWidth(16_777_215)
        self.splitter_principal.setSizes(
            [ancho_panel, ancho_total - ancho_panel]
        )

    def _restaurar_tamanos_splitter(self, tamaños):
        self.panel_desplegable.setMaximumWidth(16_777_215)
        self.splitter_principal.setSizes(tamaños)
        self.programar_reajuste_pagina_web()

    def recargar_pestana_actual(self):
        visor = self.tabs.currentWidget()
        if visor:
            visor.reload()
    def cerrar_pestana_actual(self):
        indice = self.tabs.currentIndex()
        if indice >= 0:
            self.cerrar_pestana(indice)
    def seleccionar_pestana_atajo(self, numero):
        cantidad = self.tabs.count()
        if not cantidad:
            return
        indice = cantidad - 1 if numero == 9 else numero - 1
        if indice < cantidad:
            self.tabs.setCurrentIndex(indice)
    def expandir_barra_lateral_hover(self):
        """Expande la barra lateral corrigiendo de raíz el estiramiento y los nombres de los atajos"""
        self.barra_lateral.setFixedWidth(168)
        
        for btn, (icono, nombre) in self.mapeo_nombres_botones.items():
            btn.setFixedWidth(160)
            btn.setText(icono + nombre)
        
        self.btn_audio_ambiente.setFixedWidth(160)
        self.btn_audio_ambiente.setText("🔊 Música On" if self.musica_reproducir else "🔇 Música Off")
        
        for btn in [self.btn_rapido1, self.btn_rapido2, self.btn_rapido3]:
            btn.setFixedWidth(160)
            url = self.urls_rapidas_inferiores.get(btn.id_boton, "")
            if url:
                limpio = url.split("//")[-1].split("www.")[-1].split(".")[0]
                btn.setText(limpio.capitalize())
            else:
                btn.setText(btn.texto_base)
        self.barra_lateral.raise_()
        QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
    def ejecutar_zoom_mas(self, id_boton):
        """Sube el zoom de la pestaña activa en pasos de 10%"""
        visor_actual = self.tabs.currentWidget()
        if visor_actual:
            zoom_actual = visor_actual.zoomFactor()
            nuevo_zoom = zoom_actual + 0.1
            if nuevo_zoom <= 4.0:
                visor_actual.setZoomFactor(nuevo_zoom)
                self.lbl_toolbar_zoom_valor.setText(f"{int(nuevo_zoom * 100)}%")
    def ejecutar_zoom_menos(self, id_boton):
        """Baja el zoom de la pestaña activa en pasos de 10%"""
        visor_actual = self.tabs.currentWidget()
        if visor_actual:
            zoom_actual = visor_actual.zoomFactor()
            nuevo_zoom = zoom_actual - 0.1
            if nuevo_zoom >= 0.3:
                visor_actual.setZoomFactor(nuevo_zoom)
                self.lbl_toolbar_zoom_valor.setText(f"{int(nuevo_zoom * 100)}%")
    def retraer_barra_lateral_hover(self):
        """Contrae la barra lateral al tamaño compacto original sin perder el favicon interno"""
        self.barra_lateral.setFixedWidth(52)
        for btn, (icono, _) in self.mapeo_nombres_botones.items():
            btn.setFixedWidth(44)
            btn.setText(icono)
            
        self.btn_audio_ambiente.setFixedWidth(44)
        self.btn_audio_ambiente.setText("🔊" if self.musica_reproducir else "🔇")
        
        for btn in [self.btn_rapido1, self.btn_rapido2, self.btn_rapido3]:
            btn.setFixedWidth(44)
            if btn.icon().isNull():
                btn.setText(btn.texto_base)
            else:
                btn.setText("")
        QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
    def conmutar_tablero(self, nuevo_tablero):
        if self.tablero_actual == nuevo_tablero:
            self.btn_juegos.setChecked(nuevo_tablero == "juegos")
            self.btn_investigacion.setChecked(nuevo_tablero == "investigacion")
            return
        self.tableros[self.tablero_actual] = self.capturar_urls_pestanas()
        self.indices_pestanas[self.tablero_actual] = max(
            0, self.tabs.currentIndex()
        )
        self.tablero_actual = nuevo_tablero
        self.btn_juegos.setChecked(nuevo_tablero == "juegos")
        self.btn_investigacion.setChecked(nuevo_tablero == "investigacion")
        self.btn_chat.setChecked(False)
        self.btn_musica.setChecked(False)
        self.btn_historial.setChecked(False)
        self.btn_descargas.setChecked(False)
        self.btn_scripts.setChecked(False)
        self.btn_ajustes.setChecked(False)
        self._establecer_tamanos_splitter(0)
        self.renderizar_pestanas_del_tablero_actual()
        self.guardar_todo_en_json()
    def renderizar_pestanas_del_tablero_actual(self):
        self.tabs.currentChanged.disconnect(self.cambio_de_pestana)
        while self.tabs.count() > 0:
            widget = self.tabs.widget(0)
            self.tabs.removeTab(0)
            if widget: self.destruir_vista_pestana(widget)
        self.tabs.currentChanged.connect(self.cambio_de_pestana)
        urls_a_cargar = self.tableros.get(self.tablero_actual, [])
        if urls_a_cargar and len(urls_a_cargar) > 0:
            for url in urls_a_cargar: 
                if url.strip(): self.crear_nueva_pestana(url)
        else:
            if self.tablero_actual == "juegos": 
                self.crear_nueva_pestana("https://poki.com")
            else: 
                self.crear_nueva_pestana(self.startpage_url)
        if self.tabs.count():
            saved_index = self.indices_pestanas.get(self.tablero_actual, 0)
            self.tabs.setCurrentIndex(
                min(max(0, saved_index), self.tabs.count() - 1)
            )
        self.programar_guardado_pestanas()
    def controlar_panel_lateral_desplegable(self, modulo):
        botones_panel = [
            self.btn_chat,
            self.btn_musica,
            self.btn_historial,
            self.btn_descargas,
            self.btn_scripts,
            self.btn_adblock,
            self.btn_ajustes,
        ]
        mapeo = {
            "chat": (self.btn_chat, 0, "💬 Discord Chat"),
            "musica": (self.btn_musica, 1, "🎵 Spotify Player"),
            "historial": (self.btn_historial, 2, "📜 Historial de Navegación"),
            "descargas": (self.btn_descargas, 3, "📥 Descargas Registradas"),
            "ajustes": (self.btn_ajustes, 4, "⚙️ Configuración"),
            "scripts": (self.btn_scripts, 5, "🧩 Scripts web"),
            "adblock": (self.btn_adblock, 6, "🛡️ Adblock")
        }
        
        btn_foco, index_stack, titulo = mapeo[modulo]
        for btn in botones_panel:
            if btn is not btn_foco:
                btn.setChecked(False)
        if btn_foco.isChecked():
            self.titulo_panel.setText(titulo)
            self.sub_paneles.setCurrentIndex(index_stack)
            QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
            if modulo == "adblock":
                self.actualizar_panel_adblock()
                self.timer_adblock.start()
            else:
                self.timer_adblock.stop()
            if modulo == "scripts":
                self.actualizar_lista_scripts()
            self._establecer_tamanos_splitter(self.ancho_panel_guardado)
            self.programar_tamanos_panel_lateral()
            self.programar_reajuste_pagina_web()
        else:
            self.timer_adblock.stop()
            self._establecer_tamanos_splitter(0)
            self.programar_tamanos_panel_lateral()
            self.programar_reajuste_pagina_web()
    def programar_tamanos_panel_lateral(self):
        QTimer.singleShot(0, self.sincronizar_tamanos_panel_lateral)
    def sincronizar_tamanos_panel_lateral(self):
        botones_panel = (
            self.btn_chat,
            self.btn_musica,
            self.btn_historial,
            self.btn_descargas,
            self.btn_scripts,
            self.btn_adblock,
            self.btn_ajustes,
        )
        ancho = (
            self.ancho_panel_guardado
            if any(boton.isChecked() for boton in botones_panel)
            else 0
        )
        self._establecer_tamanos_splitter(ancho)
        self.programar_reajuste_pagina_web()
    def programar_reajuste_pagina_web(self, *_):
        timer = getattr(self, "timer_reajuste_pagina_web", None)
        if timer is not None:
            timer.start()
    def reajustar_pagina_web(self):
        visor = self.tabs.currentWidget() if hasattr(self, "tabs") else None
        if not visor:
            return
        visor.updateGeometry()
        visor.runJavaScript("window.dispatchEvent(new Event('resize'));")
    def importar_script_web(self):
        ruta, _ = QFileDialog.getOpenFileName(
            self, "Importar script de Operython", "", "Scripts de Operython (*.txt)"
        )
        if not ruta:
            return
        origen = Path(ruta)
        try:
            texto = origen.read_text(encoding="utf-8")
            script = scripts_web.parse_script(texto)
        except (OSError, UnicodeDecodeError, scripts_web.ScriptError) as error:
            QMessageBox.warning(self, "Script no válido", str(error))
            return

        respuesta = QMessageBox.warning(
            self,
            "Confirmar script",
            f"Importar «{script['name']}» para:\n"
            f"{', '.join(script['sites'])}\n\n"
            "Sus instrucciones pueden cambiar la visibilidad, el texto y estilos "
            "de elementos o imágenes en esos sitios. No admite código libre ni "
            "acceso a red. "
            "¿Confías en este script?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if respuesta != QMessageBox.StandardButton.Yes:
            return

        try:
            destino = scripts_web.create_script_package_path(script)
        except scripts_web.ScriptError as error:
            QMessageBox.warning(self, "Nombre de script no válido", str(error))
            return
        try:
            scripts_web.SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
            destino.parent.mkdir(parents=True, exist_ok=True)
            if destino.exists():
                raise scripts_web.ScriptError(
                    f"Ya existe un script en la carpeta «{destino.parent.name}»."
                )
            (destino.parent / "assets").mkdir(parents=True, exist_ok=True)
            destino.write_bytes(origen.read_bytes())
            codigo_copiado = destino.read_text(encoding="utf-8")
            script_copiado = scripts_web.parse_script(codigo_copiado)
            scripts_web.import_script_assets(
                origen, destino, script_copiado
            )
            estado = scripts_web.read_script_state()
            estado[scripts_web.script_state_key(destino)] = True
            scripts_web.write_script_state(estado)
        except (OSError, UnicodeDecodeError, scripts_web.ScriptError) as error:
            if destino.is_file():
                mensaje = (
                    f"El script se copió en «{destino.parent}», pero no se pudo "
                    f"completar su carpeta assets: {error}"
                )
            else:
                mensaje = str(error)
            QMessageBox.warning(self, "No se pudo completar la importación", mensaje)
            return
        self.lbl_estado_scripts.setText(f"Importado: {script['name']}.")
        self.actualizar_lista_scripts()

    def abrir_editor_scripts(self):
        item = self.lista_scripts.currentItem()
        ruta_script = item.data(Qt.ItemDataRole.UserRole) if item else ""
        ruta_editor = Path(__file__).with_name("EditorScripts.py")
        try:
            argumentos = [sys.executable, str(ruta_editor)]
            if ruta_script:
                argumentos.append(str(ruta_script))
            subprocess.Popen(argumentos, cwd=str(RUTA_SISTEMA))
        except OSError as error:
            QMessageBox.warning(self, "No se pudo abrir el editor", str(error))

    def actualizar_lista_scripts(self):
        self.lista_scripts.clear()
        try:
            estado = scripts_web.read_script_state()
            archivos = scripts_web.list_scripts()
        except scripts_web.ScriptError as error:
            self.lbl_estado_scripts.setText(str(error))
            return
        if not archivos:
            self.lista_scripts.addItem("No hay scripts importados.")
            self.lista_scripts.item(0).setFlags(Qt.ItemFlag.NoItemFlags)
            self.actualizar_scripts_en_pestanas_abiertas()
            return
        for ruta in archivos:
            icono = QIcon()
            try:
                script = scripts_web.parse_script(ruta.read_text(encoding="utf-8"))
                scripts_web.validate_script_assets(script, ruta)
                titulo = script["name"]
                if script.get("logo_enabled"):
                    logo = scripts_web.resolve_logo_asset(
                        ruta, script.get("logo_file")
                    )
                    if logo is not None:
                        icono = crear_icono_script(logo)
            except (OSError, UnicodeDecodeError, scripts_web.ScriptError) as error:
                titulo = f"{scripts_web.script_state_key(ruta)} — no válido: {error}"
            activo = scripts_web.is_script_enabled(estado, ruta)
            item = QListWidgetItem(f"{'✅' if activo else '⏸️'} {titulo}")
            if not icono.isNull():
                item.setIcon(icono)
            item.setData(Qt.ItemDataRole.UserRole, str(ruta))
            self.lista_scripts.addItem(item)
        self.actualizar_scripts_en_pestanas_abiertas()

    def mostrar_descripcion_script_web(self):
        ruta = self.script_web_seleccionado()
        if not ruta:
            return
        try:
            script = scripts_web.parse_script(ruta.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, scripts_web.ScriptError) as error:
            QMessageBox.warning(self, "No se pudo leer el script", str(error))
            return
        descripcion = script.get("description") or (
            "Este script todavía no tiene una descripción."
        )
        QMessageBox.information(
            self,
            f"Descripción: {script['name']}",
            f"{descripcion}\n\nSitios: {', '.join(script['sites'])}",
        )

    def mostrar_funciones_script_web(self, item=None):
        ruta = (
            Path(item.data(Qt.ItemDataRole.UserRole))
            if item is not None and item.data(Qt.ItemDataRole.UserRole)
            else self.script_web_seleccionado()
        )
        if not ruta:
            return
        try:
            script = scripts_web.parse_script(ruta.read_text(encoding="utf-8"))
            estados = scripts_web.read_script_function_state()
        except (OSError, UnicodeDecodeError, scripts_web.ScriptError) as error:
            QMessageBox.warning(self, "No se pudo abrir el script", str(error))
            return

        clave_script = scripts_web.script_state_key(ruta)
        estado_funciones = estados.get(clave_script, {})
        dialogo = QDialog(self)
        dialogo.setWindowTitle(f"Funciones de {script['name']}")
        dialogo.resize(520, 440)
        layout = QVBoxLayout(dialogo)
        descripcion = QLabel(
            script.get("description")
            or "Este script todavía no tiene una descripción."
        )
        descripcion.setWordWrap(True)
        layout.addWidget(descripcion)
        lista_funciones = QListWidget()
        lista_funciones.setWordWrap(True)
        lista_funciones.setSpacing(4)
        for indice, (clave, texto) in enumerate(
            scripts_web.script_functions(script), start=1
        ):
            funcion = QListWidgetItem(f"{indice}. {texto}")
            funcion.setFlags(
                funcion.flags()
                | Qt.ItemFlag.ItemIsUserCheckable
                | Qt.ItemFlag.ItemIsEnabled
            )
            funcion.setCheckState(
                Qt.CheckState.Checked
                if estado_funciones.get(clave, True)
                else Qt.CheckState.Unchecked
            )
            funcion.setData(Qt.ItemDataRole.UserRole, clave)
            lista_funciones.addItem(funcion)
        layout.addWidget(lista_funciones)
        ayuda = QLabel(
            "Desmarca las funciones que no quieras usar. Los cambios se guardan "
            "en la configuración maestra al pulsar «Guardar»."
        )
        ayuda.setWordWrap(True)
        layout.addWidget(ayuda)
        botones = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        botones.button(QDialogButtonBox.StandardButton.Save).setText("Guardar")
        botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        botones.accepted.connect(dialogo.accept)
        botones.rejected.connect(dialogo.reject)
        layout.addWidget(botones)
        if dialogo.exec() != QDialog.DialogCode.Accepted:
            return

        try:
            estados = scripts_web.read_script_function_state()
            estados[clave_script] = {
                item.data(Qt.ItemDataRole.UserRole): (
                    item.checkState() == Qt.CheckState.Checked
                )
                for index in range(lista_funciones.count())
                if (item := lista_funciones.item(index)) is not None
            }
            scripts_web.write_script_function_state(estados)
        except scripts_web.ScriptError as error:
            QMessageBox.warning(self, "No se pudo guardar", str(error))
            return
        self.lbl_estado_scripts.setText(
            f"Funciones de «{script['name']}» guardadas."
        )
        self.actualizar_lista_scripts()

    def script_web_seleccionado(self):
        item = self.lista_scripts.currentItem()
        if not item:
            return None
        ruta = item.data(Qt.ItemDataRole.UserRole)
        if not ruta:
            return None
        return Path(ruta)

    def alternar_script_web(self):
        ruta = self.script_web_seleccionado()
        if not ruta:
            return
        nombre_script = (
            ruta.parent.name
            if ruta.parent != scripts_web.SCRIPTS_DIR
            else ruta.stem
        )
        try:
            estado = scripts_web.read_script_state()
            clave_estado = scripts_web.script_state_key(ruta)
            activo = scripts_web.is_script_enabled(estado, ruta)
            estado[clave_estado] = not activo
            scripts_web.write_script_state(estado)
        except scripts_web.ScriptError as error:
            QMessageBox.warning(self, "No se pudo cambiar el estado", str(error))
            return
        self.lbl_estado_scripts.setText(
            f"«{nombre_script}» {'desactivado' if activo else 'activado'}."
        )
        self.actualizar_lista_scripts()

    def quitar_script_web(self):
        ruta = self.script_web_seleccionado()
        if not ruta:
            return
        confirmar = QMessageBox.question(
            self,
            "Quitar script",
            f"¿Quitar el paquete «{ruta.parent.name if ruta.parent != scripts_web.SCRIPTS_DIR else ruta.stem}» de Operython?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirmar != QMessageBox.StandardButton.Yes:
            return
        try:
            estado = scripts_web.read_script_state()
            funciones_estado = scripts_web.read_script_function_state()
            estado.pop(scripts_web.script_state_key(ruta), None)
            funciones_estado.pop(scripts_web.script_state_key(ruta), None)
            estado.pop(ruta.name, None)
            scripts_web.remove_script_package(ruta)
            scripts_web.write_script_state(estado)
            scripts_web.write_script_function_state(funciones_estado)
        except (OSError, scripts_web.ScriptError) as error:
            QMessageBox.warning(self, "No se pudo quitar el script", str(error))
            return
        self.lbl_estado_scripts.setText(
            f"«{ruta.parent.name if ruta.parent != scripts_web.SCRIPTS_DIR else ruta.stem}» se quitó."
        )
        self.actualizar_lista_scripts()

    def alternar_excepcion_adblock_pagina(self):
        visor = self.tabs.currentWidget()
        origen = scripts_web.adblock_page_key(
            visor.url().toString() if visor else ""
        )
        if not origen:
            return
        if origen in self.adblock_excepciones_pagina:
            self.adblock_excepciones_pagina.remove(origen)
        else:
            self.adblock_excepciones_pagina.add(origen)
        self.adblock_revision += 1
        self._marcar_adblock_sincronizando()
        self.guardar_todo_en_json()
        self.actualizar_scripts_en_pestanas_abiertas()
        self.actualizar_panel_adblock()

    def alternar_adblock_general(self):
        self.adblock_general_activo = not self.adblock_general_activo
        self.adblock_revision += 1
        self._marcar_adblock_sincronizando()
        self.guardar_todo_en_json()
        self.actualizar_scripts_en_pestanas_abiertas()
        self.actualizar_panel_adblock()

    def _marcar_adblock_sincronizando(self):
        self.lbl_adblock_resumen.setText(
            "Aplicando el cambio del bloqueador..."
        )
        self.lista_adblock_elementos.clear()
        self.lista_adblock_elementos.addItem(
            "Puedes volver a cambiar estas opciones cuando quieras."
        )

    def _mostrar_reporte_adblock(self, visor, url, revision, reporte):
        if (
            self.tabs.currentWidget() is not visor
            or visor.url().toString() != url
            or revision != self.adblock_revision
            or not isinstance(reporte, dict)
        ):
            return
        if not reporte.get("enabled"):
            self.lbl_adblock_resumen.setText(
                "Bloqueador activado; sincronizando con la página..."
            )
            return
        cantidad = int(reporte.get("count", 0))
        elementos = reporte.get("items", [])
        if not isinstance(elementos, list):
            elementos = []
        self.lbl_adblock_resumen.setText(
            f"Anuncios bloqueados en esta página: {cantidad}"
        )
        elementos = [str(elemento) for elemento in elementos[:100]]
        actuales = [
            self.lista_adblock_elementos.item(index).text()
            for index in range(self.lista_adblock_elementos.count())
        ]
        if actuales != elementos:
            self.lista_adblock_elementos.clear()
            if elementos:
                self.lista_adblock_elementos.addItems(elementos)
            elif cantidad:
                self.lista_adblock_elementos.addItem(
                    "Hay anuncios bloqueados, pero no se pudo leer su descripción."
                )
            else:
                self.lista_adblock_elementos.addItem(
                    "Todavía no se detectaron anuncios en esta página."
                )

    def actualizar_panel_adblock(self, *_):
        if not hasattr(self, "lbl_adblock_pagina"):
            return
        visor = self.tabs.currentWidget() if hasattr(self, "tabs") else None
        url = visor.url().toString() if visor else ""
        origen = scripts_web.adblock_page_key(url)
        excepcion = bool(origen and origen in self.adblock_excepciones_pagina)
        self.btn_adblock_excepcion.setEnabled(bool(origen))
        self.btn_adblock_excepcion.setChecked(excepcion)
        self.btn_adblock_excepcion.setText(
            "Permitir anuncios en este sitio: "
            + ("SÍ" if excepcion else "NO")
        )
        self.btn_adblock_general.setChecked(self.adblock_general_activo)
        self.btn_adblock_general.setText(
            "Bloqueador general: "
            + ("ACTIVADO" if self.adblock_general_activo else "DESACTIVADO")
        )
        if not visor or not url:
            self.lbl_adblock_pagina.setText("Página actual: sin página web")
            self.lbl_adblock_resumen.setText("Anuncios bloqueados: 0")
            self.lista_adblock_elementos.clear()
            return
        titulo = visor.title().strip()
        detalle_url = f"{titulo}\n{url}" if titulo else url
        self.lbl_adblock_pagina.setText(f"Página actual:\n{detalle_url}")
        if not self.adblock_general_activo or excepcion:
            self.lbl_adblock_resumen.setText(
                "Bloqueador apagado para esta página."
                if excepcion
                else "Bloqueador general desactivado."
            )
            self.lista_adblock_elementos.clear()
            self.lista_adblock_elementos.addItem(
                "Los anuncios no se bloquean en este momento."
            )
            return
        revision = self.adblock_revision

        def mostrar_reporte(reporte):
            if isinstance(reporte, str):
                try:
                    reporte = json.loads(reporte)
                except json.JSONDecodeError as error:
                    print(f"No se pudo interpretar el reporte de Adblock: {error}")
                    return
            if reporte is not None:
                self._mostrar_reporte_adblock(visor, url, revision, reporte)

        visor.runJavaScript(
            "JSON.stringify(window.__operythonAdBlockReport"
            " ? window.__operythonAdBlockReport() : null)",
            mostrar_reporte,
        )

    def aplicar_scripts_web(self, visor, actualizar_estado=True):
        url = visor.url().toString()
        origen_adblock = scripts_web.adblock_page_key(url)
        excepcion_adblock = bool(
            origen_adblock
            and origen_adblock in self.adblock_excepciones_pagina
        )
        adblock_activo_en_pagina = (
            self.adblock_general_activo and not excepcion_adblock
        )
        try:
            funciones_estado = scripts_web.read_script_function_state()
            scripts, errores = scripts_web.load_enabled_scripts()
        except scripts_web.ScriptError as error:
            if actualizar_estado:
                self.lbl_estado_scripts.setText(str(error))
            return [str(error)]
        acciones_pagina = []
        aplicados = 0
        for ruta, script in scripts:
            if scripts_web.script_matches_url(script, url):
                clave_script = scripts_web.script_state_key(ruta)
                estado_funciones = funciones_estado.get(clave_script, {})
                acciones_antes = len(acciones_pagina)
                for action, (clave_funcion, _) in zip(
                    script["actions"], scripts_web.script_functions(script)
                ):
                    if not estado_funciones.get(clave_funcion, True):
                        continue
                    if (
                        script["name"].casefold() == "y2mate no ads"
                        and action["type"] == "OCULTAR"
                        and not adblock_activo_en_pagina
                    ):
                        continue
                    page_action = dict(action)
                    if (
                        script["name"].casefold() == "y2mate no ads"
                        and page_action["type"] == "OCULTAR"
                    ):
                        page_action["count_as_ad"] = True
                    if page_action["type"] == "BOTON_ALTERNAR":
                        page_action["_group_name"] = clave_script
                    elif page_action["type"] == "IMAGEN":
                        page_action["_script_path"] = str(ruta)
                    acciones_pagina.append(page_action)
                if len(acciones_pagina) > acciones_antes:
                    aplicados += 1
        try:
            javascript = scripts_web.build_javascript(
                {"name": "Operython scripts", "actions": acciones_pagina},
                adblock_enabled=adblock_activo_en_pagina,
            )
        except scripts_web.ScriptError as error:
            errores.append(str(error))
            if actualizar_estado:
                self.lbl_estado_scripts.setText("Scripts con errores: " + "; ".join(errores))
            return errores
        visor.runJavaScript(javascript)
        if errores:
            if actualizar_estado:
                self.lbl_estado_scripts.setText("Scripts con errores: " + "; ".join(errores))
        elif aplicados and actualizar_estado:
            self.lbl_estado_scripts.setText(f"Se aplicaron {aplicados} script(s) en {url}.")
        return errores

    def actualizar_scripts_en_pestanas_abiertas(self):
        pestanas = getattr(self, "tabs", None)
        if pestanas is None:
            return
        actualizadas = 0
        visores = [
            pestanas.widget(index)
            for index in range(pestanas.count())
        ]
        visores.extend(
            visor
            for visor in (
                getattr(self, "web_chat", None),
                getattr(self, "web_musica", None),
            )
            if visor is not None
        )
        visores_unicos = []
        for visor in visores:
            if visor is not None and visor not in visores_unicos:
                visores_unicos.append(visor)
        for visor in visores_unicos:
            if visor and visor.url().scheme() in {"http", "https"}:
                visor.reload()
                actualizadas += 1
        if actualizadas:
            self.lbl_estado_scripts.setText(
                f"Se recargaron {actualizadas} página(s) para aplicar los scripts."
            )

    def mostrar_error_webview2(self, visor, mensaje):
        if self.tabs.indexOf(visor) >= 0 or visor in (
            getattr(self, "web_chat", None),
            getattr(self, "web_musica", None),
        ):
            QMessageBox.critical(
                self,
                "Error del navegador",
                "No se pudo iniciar la reproducción en WebView2:\n\n" + mensaje,
            )
        else:
            print(f"Error de WebView2 en una pestaña cerrada: {mensaje}")

    def detectar_redimensionado_manual(self, pos, index):
        if index == 1 and pos > 10:
            self.ancho_panel_guardado = pos
            self.guardar_todo_en_json()
    def procesar_solicitud_descarga(self, solicitud):
        descarga = solicitud.DownloadOperation
        nombre_sugerido = Path(str(descarga.ResultFilePath)).name
        if not nombre_sugerido:
            nombre_sugerido = Path(urlsplit(str(descarga.Uri)).path).name
        if not nombre_sugerido:
            nombre_sugerido = "descarga"
        ruta_defecto = str(Path.home() / "Downloads" / nombre_sugerido)
        ruta_final, _ = QFileDialog.getSaveFileName(self, "Guardar Archivo como...", ruta_defecto)
        if not ruta_final:
            solicitud.Handled = True
            descarga.Cancel()
            return

        solicitud.ResultFilePath = ruta_final
        solicitud.Handled = True
        descarga_info = {"nombre": Path(ruta_final).name, "estado": "⏳ Descargando (0%)"}
        self.lista_descargas_datos.insert(0, descarga_info)
        self.actualizar_vista_lista_descargas()
        callbacks = (
            lambda *_: self.actualizar_progreso_descarga(descarga, descarga_info),
            lambda *_: self.finalizar_estado_descarga(descarga, descarga_info),
        )
        descarga.BytesReceivedChanged += callbacks[0]
        descarga.StateChanged += callbacks[1]
        self._callbacks_descargas = getattr(self, "_callbacks_descargas", [])
        self._callbacks_descargas.append((descarga, callbacks))
        self.btn_descargas.setChecked(True)
        self.controlar_panel_lateral_desplegable("descargas")
    def actualizar_progreso_descarga(self, descarga, info):
        total = int(descarga.TotalBytesToReceive)
        if total > 0:
            progreso = int((int(descarga.BytesReceived) / total) * 100)
            info["estado"] = f"⏳ Descargando ({progreso}%)"
            self.actualizar_vista_lista_descargas()
    def finalizar_estado_descarga(self, state, info):
        descarga = state
        state_name = str(descarga.State)
        if state_name.endswith("Completed"):
            info["estado"] = "✅ Completado"
        elif state_name.endswith("Interrupted"):
            info["estado"] = "⚠️ Interrumpido"
        elif state_name.endswith("Cancelled"):
            info["estado"] = "❌ Cancelado"
        else:
            return
        self.actualizar_vista_lista_descargas()
        self.guardar_todo_en_json()
        for operation, callbacks in getattr(self, "_callbacks_descargas", []):
            if operation is descarga:
                operation.BytesReceivedChanged -= callbacks[0]
                operation.StateChanged -= callbacks[1]
                self._callbacks_descargas.remove((operation, callbacks))
                break
    def actualizar_vista_lista_descargas(self):
        self.widget_lista_descargas.clear()
        for data in self.lista_descargas_datos:
            texto_item = f"Archivo: {data['nombre']}\nEstado: {data['estado']}"
            self.widget_lista_descargas.addItem(QListWidgetItem(texto_item))
    def ejecutar_click_izquierdo_ambiente(self, id_boton):
        """Click Izquierdo: Conmuta la reproducción de la música de fondo"""
        if not self.ruta_musica_personalizada or not os.path.exists(self.ruta_musica_personalizada):
            self.ejecutar_click_derecho_ambiente(id_boton)
            return
            
        self.musica_reproducir = not self.musica_reproducir
        if self.musica_reproducir:
            self.player_fondo.play()
            self.btn_audio_ambiente.setText("🔊" if self.barra_lateral.width() < 60 else "🔊 Música On")
        else:
            self.player_fondo.pause()
            self.btn_audio_ambiente.setText("🔇" if self.barra_lateral.width() < 60 else "🔇 Música Off")
        self.guardar_todo_en_json()
    def ejecutar_click_derecho_ambiente(self, id_boton):
        """Click Derecho: Abre el explorador filtrando por archivos .mp3"""
        ruta_archivo, _ = QFileDialog.getOpenFileName(self, "Seleccionar Música de Fondo (.mp3)", "", "Archivos de Audio (*.mp3)")
        if ruta_archivo:
            self.ruta_musica_personalizada = ruta_archivo
            self.player_fondo.setSource(QUrl.fromLocalFile(ruta_archivo))
            self.musica_reproducir = True
            self.player_fondo.play()
            self.btn_audio_ambiente.setText("🔊" if self.barra_lateral.width() < 60 else "🔊 Música On")
            self.guardar_todo_en_json()
    def inicializar_estado_musica_fondo(self):
        """Aplica la pista cargada previamente desde el JSON en la inicialización"""
        if self.ruta_musica_personalizada and os.path.exists(self.ruta_musica_personalizada):
            self.player_fondo.setSource(QUrl.fromLocalFile(self.ruta_musica_personalizada))
            if self.musica_reproducir:
                self.player_fondo.play()
    def ejecutar_click_izquierdo_rapido(self, id_boton):
        url = self.urls_rapidas_inferiores.get(id_boton, self.startpage_url)
        self.crear_nueva_pestana(url)
    def ejecutar_click_derecho_configurar(self, id_boton):
        url_actual = self.urls_rapidas_inferiores.get(id_boton, "")
        url_nueva, ok = QInputDialog.getText(self, "Asignar Acceso Rápido", f"Escribe la URL para el botón N{id_boton}:", QLineEdit.EchoMode.Normal, url_actual)
        if ok and url_nueva.strip():
            entrada = url_nueva.strip()
            self.urls_rapidas_inferiores[id_boton] = entrada
            self.actualizar_iconos_atajos_inferiores()
            self.guardar_todo_en_json()
    def actualizar_iconos_atajos_inferiores(self):
        botones_map = {"1": self.btn_rapido1, "2": self.btn_rapido2, "3": self.btn_rapido3}
        for id_btn, boton in botones_map.items():
            url = self.urls_rapidas_inferiores.get(id_btn, "")
            if url:
                url_sitio = url if urlsplit(url).scheme else f"https://{url}"
                favicon_url = (
                    "https://www.google.com/s2/favicons?domain_url="
                    + quote(url_sitio, safe="")
                    + "&sz=64"
                )
                self.descargar_y_assignar_icon(favicon_url, boton, f"N{id_btn}")
    def descargar_y_assignar_icon(self, icon_url, boton, texto_defecto):
        reply = self._favicon_manager.get(QNetworkRequest(QUrl(icon_url)))

        def asignar_icono():
            pixmap = QPixmap()
            if pixmap.loadFromData(bytes(reply.readAll())):
                boton.setIcon(QIcon(pixmap))
                boton.setIconSize(QSize(18, 18))
                if self.barra_lateral.width() <= 60:
                    boton.setText("")
            else:
                boton.setIcon(QIcon())
                boton.setText(texto_defecto)
            reply.deleteLater()

        reply.finished.connect(asignar_icono)
    def cambiar_url_startpage(self):
        entrada = self.line_edit_startpage.text().strip()
        if entrada:
            self.startpage_url = entrada
            self.line_edit_startpage.setText(self.startpage_url)
            self.guardar_todo_en_json()
    def agregar_al_historial_local(self, titulo, url):
        if url and not url.startswith("about:") and not url.startswith("data:"):
            if not self.lista_historial_datos or self.lista_historial_datos[0]["url"]: 
                self.lista_historial_datos.insert(0, {"titulo": titulo, "url": url})
                self.actualizar_vista_lista_historial()
                self.guardar_todo_en_json()
    def actualizar_vista_lista_historial(self):
        self.widget_lista_historial.clear()
        for data in self.lista_historial_datos:
            texto_item = f"{data['titulo']} \n({data['url'][:45]}...)"
            item = QListWidgetItem(texto_item)
            item.setData(Qt.ItemDataRole.UserRole, data["url"])
            self.widget_lista_historial.addItem(item)
    def hacer_clic_en_item_historial(self, item):
        url = item.data(Qt.ItemDataRole.UserRole)
        if url: self.crear_nueva_pestana(url)
    def destruir_historial_completo(self):
        self.lista_historial_datos = []
        self.widget_lista_historial.clear()
        self.guardar_todo_en_json()
    def destruir_descargas_completo(self):
        self.lista_descargas_datos = []
        self.widget_lista_descargas.clear()
        self.guardar_todo_en_json()
    def cambiar_motor_busqueda(self, index):
        motores = {0: "https://google.com", 1: "https://bing.com", 2: "https://duckduckgo.com"}
        self.buscador_predeterminado = motores.get(index, "https://google.com")
        self.guardar_todo_en_json()
    def cambiar_modo_webgl(self, index):
        mode = self.combo_webgl.itemData(index)
        if mode not in {"gpu", "swiftshader"}:
            return
        self.modo_webgl = mode
        self.lbl_estado_webgl.setText(
            "Afecta Qt WebEngine y el respaldo WebView2. "
            "Cierra y vuelve a abrir Operython para aplicar el cambio."
        )
        self.guardar_todo_en_json()
    def cambiar_color_interfaz(self, index):
        (
            self.color_tema,
            self.color_hover,
            self.color_bg,
            self.color_bg_bar,
            self.color_bg_btn,
            self.color_bg_btn_hover,
        ) = PALETAS_COLOR.get(index, PALETAS_COLOR[0])
        self.actualizar_hoja_estilos()
        self.guardar_todo_en_json()
    def actualizar_hoja_estilos(self):
        if not hasattr(self, 'color_bg'):
            self.color_bg, self.color_bg_bar, self.color_bg_btn, self.color_bg_btn_hover = "#07080d", "#0b0c16", "#0d0f1a", "#121526"
            
        estilo_dinamico = ESTILO_OPERA_GX.replace("var(--theme-color, #ff1e4a)", self.color_tema)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-hover, #ff3c61)", self.color_hover)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg, #07080d)", self.color_bg)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-bar, #0b0c16)", self.color_bg_bar)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-btn, #0d0f1a)", self.color_bg_btn)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-btn-hover, #121526)", self.color_bg_btn_hover)
        self.setStyleSheet(estilo_dinamico)
    def actualizar_hoja_estilos(self):
        if not hasattr(self, 'color_bg') or not self.color_bg:
            self.color_bg, self.color_bg_bar, self.color_bg_btn, self.color_bg_btn_hover = "#07080d", "#0b0c16", "#0d0f1a", "#121526"
            
        estilo_dinamico = ESTILO_OPERA_GX.replace("var(--theme-color, #ff1e4a)", self.color_tema)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-hover, #ff3c61)", self.color_hover)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg, #07080d)", self.color_bg)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-bar, #0b0c16)", self.color_bg_bar)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-btn, #0d0f1a)", self.color_bg_btn)
        estilo_dinamico = estilo_dinamico.replace("var(--theme-bg-btn-hover, #121526)", self.color_bg_btn_hover)
        self.setStyleSheet(estilo_dinamico)
    def cargar_todo_desde_json(self):
        if not hasattr(self, 'startpage_sitios'): self.startpage_sitios = []
        if CONFIG_MAESTRA.exists():
            try:
                with open(CONFIG_MAESTRA, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if not isinstance(data, dict):
                        print(
                            "No se pudo cargar la configuración de Operython: "
                            "el archivo no contiene un objeto JSON."
                        )
                        return
                    self.buscador_predeterminado = data.get("buscador", "https://google.com")
                    self.startpage_url = data.get("startpage_url", "https://google.com")
                    self.color_tema = data.get("color_tema", "#ff1e4a")
                    self.color_hover = data.get("color_hover", "#ff3c61")
                    self.modo_webgl = data.get("webgl_mode", self.modo_webgl)
                    if self.modo_webgl not in {"gpu", "swiftshader"}:
                        self.modo_webgl = "gpu"
                    tablero_guardado = data.get("tablero_actual", "juegos")
                    self.tablero_actual = (
                        tablero_guardado
                        if isinstance(tablero_guardado, str)
                        and tablero_guardado in self.tableros
                        else "juegos"
                    )
                    self.ancho_panel_guardado = data.get("ancho_panel_lateral", 300)
                    self.musica_reproducir = data.get("bg_audio_on", False)
                    self.ruta_musica_personalizada = data.get("bg_audio_path", "")
                    self.lista_historial_datos = data.get("historial_navegacion", [])
                    self.lista_descargas_datos = data.get("historial_descargas", [])
                    self.urls_rapidas_inferiores = data.get("urls_rapidas_inferiores", {"1": "https://google.com", "2": "https://youtube.com", "3": "https://github.com"})
                    self.ruta_fondo_startpage = data.get("ruta_fondo_startpage", "")
                    self.startpage_sitios = data.get("startpage_sitios", [])
                    self.adblock_general_activo = bool(
                        data.get("adblock_general_activo", True)
                    )
                    excepciones_adblock = data.get(
                        "adblock_excepciones_pagina", []
                    )
                    if isinstance(excepciones_adblock, list):
                        self.adblock_excepciones_pagina = {
                            str(origin)
                            for origin in excepciones_adblock
                            if isinstance(origin, str)
                        }
                    
                    vol_musica = data.get("volumen_musica_maestro", 40)
                    if hasattr(self, 'audio_output'):
                        self.audio_output.setVolume(vol_musica / 100.0)
                        
                    self.volumen_sonidos = data.get("volumen_sonidos_interfaz", 40)
                    self.volumen_clicks_general = data.get("volumen_clicks_general", 40)
                    
                    # Usamos blockSignals para que al mover la palanca no se genere un bucle infinito de guardado
                    if hasattr(self, 'slider_vol_musica'):
                        self.slider_vol_musica.blockSignals(True)
                        self.slider_vol_musica.setValue(vol_musica)
                        self.slider_vol_musica.blockSignals(False)
                        
                    if hasattr(self, 'slider_vol_sonidos'):
                        self.slider_vol_sonidos.blockSignals(True)
                        self.slider_vol_sonidos.setValue(self.volumen_sonidos)
                        self.slider_vol_sonidos.blockSignals(False)
                        
                    if hasattr(self, 'slider_vol_general'):
                        self.slider_vol_general.blockSignals(True)
                        self.slider_vol_general.setValue(self.volumen_clicks_general)
                        self.slider_vol_general.blockSignals(False)
                    
                    saved_tableros = data.get("tableros", {})
                    if isinstance(saved_tableros, dict):
                        for tablero in self.tableros:
                            urls = saved_tableros.get(tablero)
                            if isinstance(urls, list):
                                self.tableros[tablero] = [
                                    str(url) for url in urls if isinstance(url, str)
                                ]
                    saved_indices = data.get("indices_pestanas", {})
                    if isinstance(saved_indices, dict):
                        for tablero in self.indices_pestanas:
                            index = saved_indices.get(tablero, 0)
                            if isinstance(index, int) and not isinstance(index, bool):
                                self.indices_pestanas[tablero] = max(0, index)

                    if hasattr(self, "tabs"):
                        self.renderizar_pestanas_del_tablero_actual()
            except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
                print(f"No se pudo cargar la configuración de Operython: {error}")
    def guardar_todo_en_json(self):
        if hasattr(self, "tabs"):
            self.tableros[self.tablero_actual] = self.capturar_urls_pestanas()
            self.indices_pestanas[self.tablero_actual] = max(
                0, self.tabs.currentIndex()
            )
        try:
            scripts_estado = scripts_web.read_script_state()
            scripts_funciones_estado = scripts_web.read_script_function_state()
        except scripts_web.ScriptError as error:
            print(f"No se pudo guardar la configuración de scripts web: {error}")
            return False
        data = {
            "buscador": self.buscador_predeterminado, 
            "startpage_url": self.startpage_url,
            "color_tema": self.color_tema, 
            "color_hover": self.color_hover,
            "webgl_mode": self.modo_webgl,
            "tablero_actual": self.tablero_actual, 
            "indices_pestanas": self.indices_pestanas,
            "ancho_panel_lateral": self.ancho_panel_guardado,
            "bg_audio_on": self.musica_reproducir,
            "bg_audio_path": self.ruta_musica_personalizada,
            "historial_navegacion": self.lista_historial_datos, 
            "historial_descargas": self.lista_descargas_datos,
            "urls_rapidas_inferiores": self.urls_rapidas_inferiores, 
            "tableros": self.tableros,
            "ruta_fondo_startpage": getattr(self, "ruta_fondo_startpage", ""),
            "startpage_sitios": getattr(self, "startpage_sitios", []),
            "volumen_musica_maestro": int(self.audio_output.volume() * 100) if hasattr(self, 'audio_output') else 40,
            "volumen_sonidos_interfaz": getattr(self, "volumen_sonidos", 40),
            "volumen_clicks_general": getattr(self, "volumen_clicks_general", 40),
            "scripts_web_estado": scripts_estado,
            "scripts_web_funciones": scripts_funciones_estado,
            "adblock_general_activo": self.adblock_general_activo,
            "adblock_excepciones_pagina": sorted(
                self.adblock_excepciones_pagina
            )
        }
        archivo_temporal = CONFIG_MAESTRA.with_name(
            f".{CONFIG_MAESTRA.name}.{os.getpid()}.tmp"
        )
        try:
            CONFIG_MAESTRA.parent.mkdir(parents=True, exist_ok=True)
            with archivo_temporal.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
            os.replace(archivo_temporal, CONFIG_MAESTRA)
        except (OSError, TypeError, ValueError) as error:
            print(f"No se pudo guardar la configuración de Operython: {error}")
            return False
        return True
    def cerrar_pestana(self, indice):
        vol_sonidos = getattr(self, "volumen_sonidos", 40)
        if vol_sonidos > 0:
            import winsound
            winsound.Beep(550, 40)
        visor = self.tabs.widget(indice)
        if visor:
            self.tabs.removeTab(indice)
            self.destruir_vista_pestana(visor)
        if self.tabs.count() == 0:
            self.crear_nueva_pestana(self.startpage_url)
        self.programar_guardado_pestanas()
    def destruir_vista_pestana(self, visor):
        visor.setAudioMuted(True)
        visor.stop()
        if isinstance(visor, VisorDePestana):
            visor.close_webview2()
        visor.deleteLater()
    def ejecutar_reinicio_completo_sistema(self):
        """Guarda el estado actual, arranca una nueva instancia limpia de Python y cierra la actual"""
        if not self.guardar_todo_en_json():
            QMessageBox.warning(
                self,
                "No se pudo reiniciar",
                "No se guardó la configuración. Revisa los mensajes de error e "
                "inténtalo de nuevo.",
            )
            return
        
        try:
            subprocess.Popen([sys.executable] + sys.argv)
        except OSError as error:
            QMessageBox.warning(
                self, "No se pudo reiniciar", f"No se pudo iniciar Operython: {error}"
            )
            return
        self._reinicio_en_curso = True
        self.close()
 
    def generar_html_startpage(self):
        import base64
        bg_style = "background-color: #07080d;"
        if hasattr(self, 'ruta_fondo_startpage') and self.ruta_fondo_startpage and os.path.exists(self.ruta_fondo_startpage):
            try:
                with open(self.ruta_fondo_startpage, "rb") as img:
                    encoded = base64.b64encode(img.read()).decode('utf-8')
                    ext = os.path.splitext(self.ruta_fondo_startpage)[-1].lower().replace(".", "")
                    if ext: 
                        bg_style = f"background: url(data:image/{ext};base64,{encoded}) no-repeat center center fixed; background-size: cover;"
            except Exception: pass
        sitios_html = ""
        for i, sitio in enumerate(getattr(self, 'startpage_sitios', [])):
            url_limpia = sitio['url'].split("//")[-1].split("/")
            icon_url = f"https://google.com{url_limpia}"
            sitios_html += f"""
            <div class="shortcut" onclick="irASitio('{sitio['url']}')">
                <div class="tile-icon">
                    <img src="{icon_url}" onerror="this.src='https://google.comgoogle.com'">
                    <!-- BOTÓN DE ELIMINAR FLOTANTE ARRIBA A LA DERECHA -->
                    <button class="btn-delete-tile" onclick="eliminarSitio(event, {i})">🗑️</button>
                </div>
                <div class="tile-label">{sitio['nombre']}</div>
            </div>
            """
        idx_google = "selected" if "google.com" in self.buscador_predeterminado else ""
        idx_bing = "selected" if "bing.com" in self.buscador_predeterminado else ""
        idx_ddg = "selected" if "duckduckgo.com" in self.buscador_predeterminado else ""
        idx_brave = "selected" if "brave.com" in self.buscador_predeterminado else ""
        return f"""
        <DOCTYPE html><html><head><meta charset="utf-8"><title>Startpage</title><style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ {bg_style} font-family: 'Segoe UI', sans-serif; height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: white; overflow: hidden; }}
        .overlay {{ position: absolute; top:0; left:0; width:100%; height:100%; background:rgba(7,8,13,0.4); z-index:1; }}
        .wrap {{ position: relative; z-index: 2; text-align: center; width: 100%; max-width: 650px; padding: 20px; }}
        h1 {{ font-size: 38px; font-weight: 800; margin-bottom: 25px; letter-spacing: 2px; text-shadow: 0 4px 10px rgba(0,0,0,0.5); }}
        h1 span {{ color: {self.color_tema}; }}
        .box {{ display: flex; background: rgba(18, 21, 38, 0.85); border: 2px solid #222744; border-radius: 30px; padding: 6px; backdrop-filter: blur(8px); margin-bottom: 40px; }}
        .box:focus-within {{ border-color: {self.color_tema}; }}
        form {{ display: flex; width: 100%; align-items: center; padding-left: 12px; }}
        .engine-select {{ background: rgba(13, 15, 26, 0.9); color: #a3a9c2; border: 1px solid #222744; border-radius: 20px; padding: 6px 12px; font-size: 13px; font-weight: 600; outline: none; cursor: pointer; margin-right: 12px; transition: all 0.2s; }}
        .engine-select:hover {{ color: #ffffff; border-color: {self.color_tema}; }}
        .engine-select option {{ background: #0d0f1a; color: #ffffff; }}
        input {{ flex: 1; background: transparent; border: none; outline: none; color: white; font-size: 16px; padding-left: 4px; }}
        button {{ background: {self.color_tema}; border: none; outline: none; color: white; padding: 10px 22px; border-radius: 20px; font-weight: bold; cursor: pointer; margin-left: 8px; }}
        button:hover {{ background: {self.color_hover}; }}
        .grid {{ display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; width: 100%; }}
        .shortcut {{ display: flex; flex-direction: column; align-items: center; width: 90px; cursor: pointer; transition: transform 0.2s; }}
        .shortcut:hover {{ transform: scale(1.08); }}
        
        /* CONTENEDOR DE LA BALDOSA DE ACCESO RÁPIDO */
        .tile-icon {{ position: relative; width: 56px; height: 56px; background: rgba(22, 25, 46, 0.85); border: 1px solid #222744; border-radius: 12px; display: flex; justify-content: center; align-items: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); backdrop-filter: blur(4px); }}
        .shortcut:hover .tile-icon {{ border-color: {self.color_tema}; }}
        .tile-icon img {{ width: 28px; height: 28px; object-fit: contain; }}
        
        /*  green ESTILOS DEL TACHO DE BASURA FLOTANTE (Oculto por defecto, aparece en Hover) */
        .btn-delete-tile {{
            position: absolute;
            top: -6px;
            right: -6px;
            width: 18px;
            height: 18px;
            background: #ff1e4a;
            border: none;
            border-radius: 50%;
            color: white;
            font-size: 9px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            padding: 0;
            margin: 0;
            opacity: 0;
            transition: opacity 0.15s, transform 0.1s;
            z-index: 10;
        }}
        .btn-delete-tile:hover {{
            background: #ff3c61;
            transform: scale(1.2);
        }}
        /* Muestra el tacho de basura solo cuando pasás el mouse arriba del atajo */
        .shortcut:hover .btn-delete-tile {{
            opacity: 1;
        }}
        
        .tile-label {{ margin-top: 8px; font-size: 12px; font-weight: 600; text-shadow: 0 2px 4px rgba(0,0,0,0.8); max-width: 90px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #e3e6ed; }}
        .btn-add {{ background: rgba(18, 21, 38, 0.5); border: 1px dashed #444b75; border-radius: 12px; font-size: 22px; color: #7d84a6; display: flex; justify-content: center; align-items: center; width: 56px; height: 56px; cursor: pointer; transition: all 0.2s; }}
        .btn-add:hover {{ border-color: {self.color_tema}; color: {self.color_tema}; background: rgba(22, 25, 46, 0.85); }}
        </style>
        <script>
        if (!window.chrome || !window.chrome.webview) {{
            window.chrome = window.chrome || {{}};
            window.chrome.webview = {{
                postMessage: (message) => console.log("__OPERYTHON__" + message)
            }};
        }}
        function agregarSitio() {{
            let nombre = prompt("Nombre del sitio:");
            if (!nombre || !nombre.trim()) return;
            let url = prompt("Dirección URL (ej: youtube.com):");
            if (!url || !url.trim()) return;
            window.chrome.webview.postMessage("OP_ADD:" + nombre.trim() + "|" + url.trim());
        }}
        function irASitio(urlDestino) {{
            window.chrome.webview.postMessage("OP_GOTO:" + urlDestino);
        }}
        
        /* 🟢 INTERCEPTOR DEL TACHO: Frena la redirección y manda la orden de borrar a Python */
        function eliminarSitio(event, index) {{
            event.stopPropagation(); // Evita que el click se propague a la baldosa y te mande a la web
            if (confirm("¿Seguro que querés eliminar este acceso rápido?")) {{
                window.chrome.webview.postMessage("OP_DEL_SHORTCUT:" + index);
            }}
        }}
        
        function actualizarBuscador(usuarioCambio) {{
            let selector = document.getElementById("motor-selector");
            let formulario = document.getElementById("search-form");
            let campoTexto = document.getElementById("search-input");
            let valor = selector.value;
            if (usuarioCambio) {{
                window.chrome.webview.postMessage("OP_SET_ENGINE:" + valor);
            }}
            let viejoLang = document.getElementById("brave-lang");
            if (viejoLang) viejoLang.remove();
            if (valor === "google") {{
                formulario.action = "https://google.com";
                campoTexto.name = "q";
            }} else if (valor === "bing") {{
                formulario.action = "https://bing.com";
                campoTexto.name = "q";
            }} else if (valor === "duckduckgo") {{
                formulario.action = "https://duckduckgo.com";
                campoTexto.name = "q";
            }} else if (valor === "brave") {{
                formulario.action = "https://search.brave.com/?lang=es";
                campoTexto.name = "q";
            }}
        }}
        </script>
        </head><body><div class="overlay"></div><div class="wrap"><h1>OPERYTHON<span>GX</span></h1><div class="box">
        <form id="search-form" action="https://google.com" method="get" onsubmit="actualizarBuscador(false)">
            <select id="motor-selector" class="engine-select" onchange="actualizarBuscador(true)">
                <option value="google" {idx_google}>Google</option>
                <option value="bing" {idx_bing}>Bing</option>
                <option value="duckduckgo" {idx_ddg}>DuckDuckGo</option>
                <option value="brave" {idx_brave}>Brave</option>
            </select>
            <input id="search-input" type="text" name="q" placeholder="Buscar en la web..." autofocus required autocomplete="off">
            <button type="submit">Buscar</button>
        </form>
        </div><div class="grid">{sitios_html}<div class="shortcut" onclick="agregarSitio()"><div class="btn-add">+</div><div class="tile-label">Añadir</div></div></div></div>
        <script>actualizarBuscador(false);</script>
        </body></html>"""
    def crear_nueva_pestana(self, url_texto="https://google.com"):
        url_destino = url_texto.strip()
        es_startpage = url_destino.lower() in {
            "https://operython",
            "https://startpage",
            "https://operython/",
        }
        visor_web = VisorDePestana(
            navegador=self,
            url="about:blank" if es_startpage else url_destino,
            html=self.generar_html_startpage() if es_startpage else None,
        )
        visor_web.id_startpage = es_startpage
        indice = self.tabs.addTab(visor_web, "Cargando...")
        self.tabs.setCurrentIndex(indice)
        QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
        btn_mute_tab = QPushButton("🔊")
        btn_mute_tab.setFixedSize(14, 14)
        btn_mute_tab.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_mute_tab.setStyleSheet("background: transparent; border: none; color: #a3a9c2; font-size: 10px; padding: 0; margin-left: 2px;")
        
        btn_mute_tab.visor_asociado = visor_web
        btn_mute_tab.clicked.connect(lambda: self.conmutar_silencio_pestana_individual(btn_mute_tab))
        
        self.tabs.tabBar().setTabButton(indice, self.tabs.tabBar().ButtonPosition.LeftSide, btn_mute_tab)
        # Recibe las acciones OP_* que la startpage envía mediante console.log.
        def procesar_mensajes_consola_fijo(message):
            if not visor_web.id_startpage:
                return
            if message.startswith("OP_ADD:"):
                datos = message[len("OP_ADD:"):].split("|", 1)
                if len(datos) == 2:
                    nombre, url_sitio = (dato.strip() for dato in datos)
                    if nombre and url_sitio:
                        if not QUrl(url_sitio).scheme():
                            url_sitio = f"https://{url_sitio.lstrip('/')}"
                        if not hasattr(self, 'startpage_sitios'): self.startpage_sitios = []
                        self.startpage_sitios.append({"nombre": nombre, "url": url_sitio})
                        self.guardar_todo_en_json()
                        visor_web.setHtml(self.generar_html_startpage())
            elif message.startswith("OP_GOTO:"):
                url_destino_shortcut = message.replace("OP_GOTO:", "")
                if url_destino_shortcut:
                    visor_web.id_startpage = False
                    visor_web.load(QUrl(url_destino_shortcut))
            elif message.startswith("OP_SET_ENGINE:"):
                motor_elegido = message.replace("OP_SET_ENGINE:", "")
                motores_map = {
                    "google": "https://google.com",
                    "bing": "https://bing.com",
                    "duckduckgo": "https://duckduckgo.com",
                    "brave": "https://brave.com"
                }
                combo_indices = {"google": 0, "bing": 1, "duckduckgo": 2, "brave": 3}
                if motor_elegido in motores_map:
                    self.buscador_predeterminado = motores_map[motor_elegido]
                    if hasattr(self, 'combo_buscar'):
                        self.combo_buscar.blockSignals(True)
                        self.combo_buscar.setCurrentIndex(combo_indices[motor_elegido])
                        self.combo_buscar.blockSignals(False)
                    self.guardar_todo_en_json()
            elif message.startswith("OP_DEL_SHORTCUT:"):
                try:
                    idx_eliminar = int(message.replace("OP_DEL_SHORTCUT:", ""))
                    if 0 <= idx_eliminar < len(self.startpage_sitios):
                        self.startpage_sitios.pop(idx_eliminar)
                        self.guardar_todo_en_json()
                        visor_web.setHtml(self.generar_html_startpage())
                except Exception: pass
        visor_web.consoleMessageReceived.connect(procesar_mensajes_consola_fijo)
        visor_web.urlChanged.connect(lambda qurl: self.actualizar_url(qurl, visor_web))
        visor_web.urlChanged.connect(self.programar_guardado_pestanas)
        visor_web.titleChanged.connect(lambda titulo: self.actualizar_titulo_e_historial(titulo, visor_web))
        visor_web.loadFinished.connect(lambda: self.lbl_toolbar_zoom_valor.setText(f"{int(visor_web.zoomFactor() * 100)}%"))
        visor_web.loadFinished.connect(lambda: self.aplicar_scripts_web(visor_web))
        return visor_web
    def ejecutar_cambio_fondo_startpage(self):
        """Abre un explorador de archivos premium permitiendo elegir imágenes estáticas o GIFs animados"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Seleccionar Imagen o GIF de Fondo", 
            "", 
            "Todos los Archivos Soportados (*.png *.jpg *.jpeg *.webp *.gif);;Imágenes Estáticas (*.png *.jpg *.jpeg *.webp);;GIFs Animados (*.gif)"
        )
        if file_path:
            self.ruta_fondo_startpage = file_path
            self.guardar_todo_en_json()
            
            visor = self.tabs.currentWidget()
            if visor and (visor.url().toString().startswith("data:text/html") or visor.url().toString() in ["https://operython/", "https://operython"]):
                visor.setHtml(self.generar_html_startpage())
    def navegar_a_url(self):
        visor_actual = self.tabs.currentWidget()
        if visor_actual:
            entrada = self.barra_url.text().strip()
            if not entrada:
                return
            
            url_directa = QUrl(entrada)
            parece_dominio = " " not in entrada and "." in entrada
            if url_directa.scheme() or parece_dominio:
                visor_actual.id_startpage = False
                visor_actual.load(url_directa)
                return
            else:
                if "brave.com" in self.buscador_predeterminado:
                    termino_busqueda = entrada.replace(' ', '+')
                    entrada = f"https://brave.com{termino_busqueda}&source=web&lang=es"
                else:
                    entrada = f"{self.buscador_predeterminado}{entrada.replace(' ', '+')}"
            
            visor_actual.id_startpage = False
            visor_actual.load(QUrl(entrada))
    def abrir_archivo_local(self):
        ruta_archivo, _ = QFileDialog.getOpenFileName(
            self,
            "Abrir archivo compatible con el navegador",
            str(RUTA_SISTEMA),
            "Todos los archivos (*)"
        )
        if ruta_archivo:
            visor = self.tabs.currentWidget()
            if not visor:
                visor = self.crear_nueva_pestana(self.startpage_url)
            visor.id_startpage = False
            visor.load(QUrl.fromLocalFile(ruta_archivo))
    def formatear_url(self, url):
        if url.isLocalFile():
            return url.toString(QUrl.ComponentFormattingOption.FullyEncoded)
        return url.toString()
    def cambio_de_pestana(self, indice):
        visor_actual = self.tabs.widget(indice)
        if visor_actual: 
            self.indices_pestanas[self.tablero_actual] = max(0, indice)
            url_str = self.formatear_url(visor_actual.url())
            if url_str.startswith("data:text/html"):
                self.barra_url.setText("https://operython")
            else:
                self.barra_url.setText(url_str)
            self.lbl_toolbar_zoom_valor.setText(f"{int(visor_actual.zoomFactor() * 100)}%")
        self.actualizar_panel_adblock()
        QTimer.singleShot(0, self.reponer_interfaz_sobre_webview)
        self.programar_guardado_pestanas()
    def actualizar_url(self, qurl, visor):
        if self.tabs.currentWidget() == visor: 
            url_str = self.formatear_url(qurl)
            if url_str.startswith("data:text/html"):
                self.barra_url.setText("https://operython")
            else:
                self.barra_url.setText(url_str)
            self.actualizar_panel_adblock()
    def actualizar_titulo_e_historial(self, titulo, visor):
        indice = self.tabs.indexOf(visor)
        if indice >= 0:
            titulo_corto = titulo[:15] + "..." if len(titulo) > 15 else titulo
            self.tabs.setTabText(indice, titulo_corto)
            self.agregar_al_historial_local(titulo, self.formatear_url(visor.url()))
    def closeEvent(self, event):
        """Interceptor de cierre premium que congela el estado exacto de las pestañas en el JSON"""
        self.timer_guardado_pestanas.stop()
        if not self._reinicio_en_curso and not self.guardar_todo_en_json():
            QMessageBox.warning(
                self,
                "No se pudo guardar",
                "Las pestañas siguen abiertas. Revisa los mensajes de error e "
                "intenta cerrarla de nuevo.",
            )
            event.ignore()
            return
        for index in range(self.tabs.count()):
            visor = self.tabs.widget(index)
            if isinstance(visor, VisorDePestana):
                visor.close_webview2()
        for visor in (self.web_chat, self.web_musica):
            visor.close_webview2()
        event.accept()
    def cambiar_volumen_musica_fondo(self, valor):
        """Ajusta el volumen multimedia nativo del reproductor de fondo (0.0 a 1.0)"""
        if hasattr(self, 'audio_output'):
            self.audio_output.setVolume(valor / 100.0)
            self.guardar_todo_en_json()
    def cambiar_volumen_efectos_interfaz(self, valor):
        """Modifica la variable global para los pitidos de abrir/cerrar pestañas"""
        self.volumen_sonidos = valor
        self.guardar_todo_en_json()
    def cambiar_volumen_clicks_general(self, valor):
        """Modifica la intensidad del volumen guardado para el click global de hardware"""
        self.volumen_clicks_general = valor
        self.guardar_todo_en_json()
    def conmutar_silencio_pestana_individual(self, boton_disparado):
        """Maneja el silenciado nativo de hilos de audio independientes en cada pestaña"""
        if boton_disparado and hasattr(boton_disparado, 'visor_asociado'):
            visor = boton_disparado.visor_asociado
            estado_actual_mute = visor.isAudioMuted()
            nuevo_estado_mute = not estado_actual_mute
            
            visor.setAudioMuted(nuevo_estado_mute)
            
            if nuevo_estado_mute:
                boton_disparado.setText("🔇")
                boton_disparado.setStyleSheet("background: transparent; border: none; color: #ff1e4a; font-size: 10px; padding: 0; margin-left: 2px;")
            else:
                boton_disparado.setText("🔊")
                boton_disparado.setStyleSheet("background: transparent; border: none; color: #a3a9c2; font-size: 10px; padding: 0; margin-left: 2px;")
if __name__ == "__main__":
    app = QApplication(sys.argv)
    navegador = NavegadorOperython()
    navegador.show()
    sys.exit(app.exec())
